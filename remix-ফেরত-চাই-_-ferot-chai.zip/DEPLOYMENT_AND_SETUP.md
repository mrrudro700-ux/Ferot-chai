# ফেরত চাই | Ferot Chai - Bangladeshi Refund Assistance Web App

“ভুল লেনদেনের অভিযোগ, সহজে ও নিরাপদে।”

An end-to-end, mobile-first web application for Bangladesh assisting citizens with documentation, tracking, and dispute guidance for mistaken mobile recharges and Mobile Financial Service (MFS: bKash, Nagad, Rocket, Upay) transactions.

---

## 1. Key Platform Features

1. **Brand Identity & Bangladeshi Fintech Design**:
   - Clean white background with emerald green and gold accents.
   - Bengali typography powered by *Hind Siliguri* & *Plus Jakarta Sans*.
   - Original circular return-arrow emblem and bilingual switch (Bangla default / English).
   - Bangladeshi Taka (৳) currency formatting.

2. **Mandatory Statutory Notice**:
   > “ফেরত চাই একটি স্বাধীন অভিযোগ-সহায়তা প্ল্যাটফর্ম। এটি কোনো মোবাইল ফাইন্যান্সিয়াল সার্ভিস প্রতিষ্ঠানের অফিসিয়াল অ্যাপ নয়। টাকা ফেরত পাওয়া সংশ্লিষ্ট প্রতিষ্ঠানের যাচাই, নীতিমালা এবং প্রযোজ্য আইনের ওপর নির্ভরশীল।”

3. **Standard Claim-Processing Service Fee — ৳109**:
   - Transparent disclaimer: *“১০৯ টাকা নির্ধারিত আবেদন-প্রক্রিয়াকরণ সেবার ফি। এটি টাকা ফেরত পাওয়ার নিশ্চয়তা নয়। পেমেন্টের আগে সেবার শর্তাবলি ও রিফান্ড নীতি পড়ুন।”*
   - Clear breakdown of work covered: document drafting, helpline guidance, provider complaint ticket logging, police GD format.

4. **Nagad Send Money Manual Payment Flow**:
   - **Payment Provider**: Nagad
   - **Payment Method**: Send Money only (bold notice: no Cash Out)
   - **Receiving Number**: `01831027877`
   - **One-click Copy**: “নম্বর কপি করুন” button
   - **Instruction Prompt**:
     > “পেমেন্ট করতে আপনার নগদ অ্যাপ খুলুন। Send Money অপশন ব্যবহার করে প্রদর্শিত প্রাপকের নম্বরে নির্ধারিত সার্ভিস ফি পাঠান। লেনদেন সম্পন্ন হলে আপনার Transaction ID দিয়ে পেমেন্ট জমা দিন। পেমেন্ট যাচাই না হওয়া পর্যন্ত আবেদনটি পেমেন্ট-অপেক্ষমাণ অবস্থায় থাকবে।”
   - Zero PIN/OTP/Password requests.
   - Payments are never automatically marked verified; manual admin review is required.

5. **Multi-Step Application Wizard**:
   - Step 1: Applicant information (Name, Contact Number, Email, Preferred contact method).
   - Step 2: Transaction info (Provider, Type, TrxID, Date, Time, Amount, Sender & Recipient numbers, Explanation, File evidence upload with 5MB validation).
   - Step 3: Review & Submit (Summary, Edit options, Consent check, Generates unique reference e.g., `FC-2026-89412`).
   - Privacy protection: Masked phone numbers in public/shared views (`01831***877`).

6. **Real-time Claim & Payment Tracking**:
   - Track via Reference Number + Phone verification check (preventing unauthorized PII exposure).
   - Timeline stepper: Submitted → Under Review → More Information Required → Referred to Provider → Resolved / Rejected.
   - Bangla explanation of current state and next recommended action.
   - Form to submit additional requested documentation directly.

7. **Secure Administrator Management Portal**:
   - Preconfigured Super Admin: `mrrudro700@gmail.com`
   - Instant Demo switcher in navbar (`👤 আবেদনকারী` vs `🛡️ এডমিন`) for instant evaluation.
   - Search by reference, filters by provider, dates, claim status, payment status.
   - Dedicated Payment Verification tab: Compare Nagad TrxIDs, flag fee discrepancies, mark Verified or Rejected with reviewer notes and timestamps.
   - Record Provider Complaint Reference numbers (e.g., bKash / Nagad ticket numbers).
   - Record confirmed refund evidence before marking claims as Resolved.
   - Live settings editor: Nagad receiving number, service fee, and platform announcements.
   - Immutable security audit logs with CSV export.

8. **Official Provider Help & Police GD Template**:
   - Genuine helplines: bKash (16247), Nagad (16167), Rocket (16216), Upay (16419), GP (121), Banglalink (121), Robi (121), BTRC (100).
   - Ready-to-copy Police GD (General Diary) template for filing reports if a recipient refuses to return funds.

---

## 2. Security & Firebase Specifications

- `firebase-blueprint.json`: JSON Schema defining entities (`user`, `claim`, `paymentSubmission`, `appSettings`, `notification`, `auditLog`) and Firestore collection paths.
- `security_spec.md`: Data invariants and the "Dirty Dozen" threat payloads.
- `firestore.rules`: ABAC security rules with strict key enforcement, `isOwner()` / `isAdmin()` checks, default deny, and timestamp validation.
- `storage.rules`: Rules restricting transaction evidence to owners and admins, enforcing max 5MB and image/pdf MIME types.

---

## 3. Testing & Evaluation

1. Open the app in browser.
2. In the navbar, toggle between **👤 আবেদনকারী** (Tanvir Ahmed) and **🛡️ এডমিন** (Moderator Rudro - `mrrudro700@gmail.com`).
3. Click **নতুন আবেদন** to submit a test claim and see the generated reference number (e.g., `FC-2026-XXXXX`).
4. Proceed to **পেমেন্টের তথ্য জমা দিন** to submit a Nagad Transaction ID.
5. Switch to **🛡️ এডমিন**, review the payment in the **পেমেন্ট ভেরিফিকেশন** tab, and click **অনুমোদন (Verify)**.
6. Open **আবেদন ট্র্যাক** to view the live timeline and status updates in real time!
