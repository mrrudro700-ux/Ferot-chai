import React, { useState } from 'react';
import { LanguageProvider } from './context/LanguageContext';
import { AuthProvider } from './context/AuthContext';
import { DataProvider } from './context/DataContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { NewClaimPage } from './pages/NewClaimPage';
import { PaymentSubmissionPage } from './pages/PaymentSubmissionPage';
import { TrackPage } from './pages/TrackPage';
import { DashboardPage } from './pages/DashboardPage';
import { AdminPage } from './pages/AdminPage';
import { GuidancePage } from './pages/GuidancePage';
import { LegalPage } from './pages/LegalPage';
import { AuthPage } from './pages/AuthPage';

function AppContent() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [paymentPreloadedRef, setPaymentPreloadedRef] = useState<string>('');
  const [legalPreloadedSection, setLegalPreloadedSection] = useState<string>('terms');

  const handleOpenPaymentForRef = (ref: string) => {
    setPaymentPreloadedRef(ref);
    setActiveTab('pay-submit');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenLegalSection = (section: string) => {
    setLegalPreloadedSection(section);
    setActiveTab('legal');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderActiveView = () => {
    switch (activeTab) {
      case 'home':
        return (
          <HomePage
            setActiveTab={setActiveTab}
            openPaymentModalForRef={handleOpenPaymentForRef}
          />
        );
      case 'new-claim':
        return (
          <NewClaimPage
            setActiveTab={setActiveTab}
            onClaimCreated={(ref) => {
              setPaymentPreloadedRef(ref);
            }}
          />
        );
      case 'pay-submit':
        return (
          <PaymentSubmissionPage
            initialReference={paymentPreloadedRef}
            setActiveTab={setActiveTab}
          />
        );
      case 'track':
        return (
          <TrackPage
            setActiveTab={setActiveTab}
            openPaymentForRef={handleOpenPaymentForRef}
          />
        );
      case 'dashboard':
        return (
          <DashboardPage
            setActiveTab={setActiveTab}
            openPaymentForRef={handleOpenPaymentForRef}
          />
        );
      case 'admin':
        return <AdminPage setActiveTab={setActiveTab} />;
      case 'guidance':
        return <GuidancePage />;
      case 'fee':
      case 'security':
      case 'contact':
        return (
          <LegalPage
            initialSection={
              activeTab === 'fee'
                ? 'refund'
                : activeTab === 'security'
                ? 'safety'
                : 'contact'
            }
          />
        );
      case 'legal':
        return <LegalPage initialSection={legalPreloadedSection} />;
      case 'login':
        return <AuthPage setActiveTab={setActiveTab} />;
      default:
        return (
          <HomePage
            setActiveTab={setActiveTab}
            openPaymentModalForRef={handleOpenPaymentForRef}
          />
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800">
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="flex-1">{renderActiveView()}</main>
      <Footer setActiveTab={setActiveTab} openLegalTab={handleOpenLegalSection} />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <DataProvider>
          <AppContent />
        </DataProvider>
      </AuthProvider>
    </LanguageProvider>
  );
}
