import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'bn' | 'en';

interface LanguageContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  bn: {
    appName: 'ফেরত চাই',
    appEnglishName: 'Ferot Chai',
    tagline: 'ভুল লেনদেনের অভিযোগ, সহজে ও নিরাপদে।',
    navHome: 'হোম',
    navNewClaim: 'নতুন আবেদন',
    navTrack: 'আবেদন ট্র্যাক',
    navFee: 'সার্ভিস ফি',
    navSecurity: 'নিরাপত্তা',
    navGuidance: 'অফিসিয়াল গাইডলাইন',
    navContact: 'যোগাযোগ',
    navDashboard: 'ড্যাশবোর্ড',
    navAdmin: 'এডমিন প্যানেল',
    login: 'লগইন',
    logout: 'লগআউট',
    register: 'রেজিস্ট্রেশন',
    
    heroTitle: 'ভুল করে টাকা পাঠিয়েছেন?',
    heroSubtitle: 'আপনার ভুল রিচার্জ বা মোবাইল ফাইন্যান্সিয়াল সার্ভিস লেনদেনের অভিযোগ নথিভুক্ত করুন এবং আবেদনের অগ্রগতি দেখুন।',
    btnApply: 'আবেদন করুন',
    btnTrack: 'আবেদন ট্র্যাক করুন',
    
    feeBadge: 'সার্ভিস ফি মাত্র ১০৯ টাকা',
    feeNotice: '১০৯ টাকা নির্ধারিত আবেদন-প্রক্রিয়াকরণ সেবার ফি। এটি টাকা ফেরত পাওয়ার নিশ্চয়তা নয়। পেমেন্টের আগে সেবার শর্তাবলি ও রিফান্ড নীতি পড়ুন।',
    disclaimerHeadline: 'গুরুত্বপূর্ণ সতর্কতা ও ঘোষণা',
    disclaimerBody: 'ফেরত চাই একটি স্বাধীন অভিযোগ-সহায়তা প্ল্যাটফর্ম। এটি কোনো মোবাইল ফাইন্যান্সিয়াল সার্ভিস প্রতিষ্ঠানের অফিসিয়াল অ্যাপ নয়। টাকা ফেরত পাওয়া সংশ্লিষ্ট প্রতিষ্ঠানের যাচাই, নীতিমালা এবং প্রযোজ্য আইনের ওপর নির্ভরশীল।',
    
    nagadInstructions: 'পেমেন্ট করতে আপনার নগদ অ্যাপ খুলুন। Send Money অপশন ব্যবহার করে প্রদর্শিত প্রাপকের নম্বরে নির্ধারিত সার্ভিস ফি পাঠান। লেনদেন সম্পন্ন হলে আপনার Transaction ID দিয়ে পেমেন্ট জমা দিন। পেমেন্ট যাচাই না হওয়া পর্যন্ত আবেদনটি পেমেন্ট-অপেক্ষমাণ অবস্থায় থাকবে।',
    copyNumber: 'নম্বর কপি করুন',
    numberCopied: 'নম্বরটি সফলভাবে কপি হয়েছে!',
    
    statusSubmitted: 'আবেদন জমা হয়েছে',
    statusUnderReview: 'পর্যালোচনা চলছে',
    statusMoreInfo: 'অতিরিক্ত তথ্য প্রয়োজন',
    statusReferred: 'অপারেটরে প্রেরিত',
    statusResolved: 'নিষ্পত্তি হয়েছে',
    statusRejected: 'বাতিল করা হয়েছে',
    
    payAwaiting: 'পেমেন্ট অপেক্ষমাণ',
    paySubmitted: 'পেমেন্ট জমা হয়েছে',
    payUnderReview: 'যাচাই চলছে',
    payVerified: 'যাচাইকৃত (সফল)',
    payRejected: 'পেমেন্ট বাতিল',
    payRefunded: 'রিফান্ডকৃত',
  },
  en: {
    appName: 'Ferot Chai',
    appEnglishName: 'Ferot Chai',
    tagline: 'Mistaken Transaction Assistance, Simple & Secure.',
    navHome: 'Home',
    navNewClaim: 'New Claim',
    navTrack: 'Track Claim',
    navFee: 'Service Fee',
    navSecurity: 'Security',
    navGuidance: 'Official Guidelines',
    navContact: 'Contact',
    navDashboard: 'Dashboard',
    navAdmin: 'Admin Portal',
    login: 'Login',
    logout: 'Logout',
    register: 'Register',
    
    heroTitle: 'Mistakenly Sent Money or Recharge?',
    heroSubtitle: 'Document your mistaken mobile recharge or MFS transaction claim and track the assistance progress in real time.',
    btnApply: 'Submit Claim',
    btnTrack: 'Track Claim',
    
    feeBadge: 'Service Fee Only ৳109',
    feeNotice: '৳109 is a standardized application documentation and processing fee. It does not guarantee recovery. Please read our Terms and Refund Policy prior to payment.',
    disclaimerHeadline: 'Important Disclaimer',
    disclaimerBody: 'Ferot Chai is an independent claim-assistance platform. It is NOT an official app of any Mobile Financial Service provider. Refund resolution depends entirely on the respective provider’s policies, recipient cooperation, and applicable law.',
    
    nagadInstructions: 'Open your Nagad App. Use the Send Money option to transfer the designated service fee to the displayed recipient number. Once completed, submit your Transaction ID. Your claim remains in Awaiting Payment status until manual verification is complete.',
    copyNumber: 'Copy Number',
    numberCopied: 'Recipient number copied to clipboard!',
    
    statusSubmitted: 'Submitted',
    statusUnderReview: 'Under Review',
    statusMoreInfo: 'More Information Required',
    statusReferred: 'Referred to Provider',
    statusResolved: 'Resolved',
    statusRejected: 'Rejected',
    
    payAwaiting: 'Awaiting Payment',
    paySubmitted: 'Payment Submitted',
    payUnderReview: 'Under Verification',
    payVerified: 'Verified',
    payRejected: 'Rejected',
    payRefunded: 'Refunded',
  },
};

const LanguageContext = createContext<LanguageContextType>({
  lang: 'bn',
  setLang: () => {},
  t: (key: string) => key,
});

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [lang, setLangState] = useState<Language>(() => {
    return (localStorage.getItem('ferotchai_lang') as Language) || 'bn';
  });

  const setLang = (newLang: Language) => {
    setLangState(newLang);
    localStorage.setItem('ferotchai_lang', newLang);
  };

  const t = (key: string): string => {
    return translations[lang][key] || translations.bn[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);
