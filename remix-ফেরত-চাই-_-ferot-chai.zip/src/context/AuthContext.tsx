import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UserRole } from '../types';
import { storageService, INITIAL_SEED_USERS } from '../services/storageAdapter';

interface AuthContextType {
  currentUser: UserProfile | null;
  isAdmin: boolean;
  isLoading: boolean;
  login: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  register: (fullName: string, email: string, phone: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  resetPassword: (email: string) => Promise<{ success: boolean; message: string }>;
  switchDemoRole: (role: 'applicant' | 'admin') => void;
  updateProfile: (data: Partial<UserProfile>) => void;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => storageService.getCurrentUser());
  const [isLoading, setIsLoading] = useState(false);

  // Check if current user is admin (either role is admin or email matches reviewer/admin email)
  const isAdmin = currentUser?.role === 'admin' || currentUser?.email === 'mrrudro700@gmail.com';

  const login = async (email: string, _pass: string): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 400));
    setIsLoading(false);

    const users = storageService.getUsers();
    const cleanEmail = email.trim().toLowerCase();
    
    // Check if user exists
    let matched = users.find((u) => u.email.toLowerCase() === cleanEmail);
    if (!matched) {
      // If logging in with the prompt's admin email, automatically create or log in as admin
      if (cleanEmail === 'mrrudro700@gmail.com') {
        matched = INITIAL_SEED_USERS[0];
      } else {
        return { success: false, error: 'এই ইমেইল দিয়ে কোনো অ্যাকাউন্ট পাওয়া যায়নি। অনুগ্রহ করে রেজিস্ট্রেশন করুন।' };
      }
    }

    setCurrentUser(matched);
    storageService.setCurrentUser(matched);
    storageService.addAuditLog({
      actorUid: matched.uid,
      actorEmail: matched.email,
      actorRole: matched.role,
      action: 'USER_LOGIN',
      targetType: 'auth',
      targetId: matched.uid,
      details: `User logged in from web client (${matched.role})`,
    });

    return { success: true };
  };

  const register = async (
    fullName: string,
    email: string,
    phone: string,
    _pass: string
  ): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 400));
    setIsLoading(false);

    const cleanEmail = email.trim().toLowerCase();
    const users = storageService.getUsers();

    if (users.some((u) => u.email.toLowerCase() === cleanEmail)) {
      return { success: false, error: 'এই ইমেইলটি ইতিপূর্বে ব্যবহৃত হয়েছে। অনুগ্রহ করে লগইন করুন।' };
    }

    const isSystemAdmin = cleanEmail === 'mrrudro700@gmail.com';
    const newUser: UserProfile = {
      uid: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      email: cleanEmail,
      fullName: fullName.trim(),
      phone: phone.trim(),
      role: isSystemAdmin ? 'admin' : 'user',
      emailVerified: true,
      createdAt: new Date().toISOString(),
    };

    const updated = [...users, newUser];
    storageService.saveUsers(updated);
    setCurrentUser(newUser);
    storageService.setCurrentUser(newUser);

    storageService.addAuditLog({
      actorUid: newUser.uid,
      actorEmail: newUser.email,
      actorRole: newUser.role,
      action: 'USER_REGISTRATION',
      targetType: 'auth',
      targetId: newUser.uid,
      details: `New account registered: ${newUser.fullName} (${newUser.phone})`,
    });

    return { success: true };
  };

  const logout = () => {
    if (currentUser) {
      storageService.addAuditLog({
        actorUid: currentUser.uid,
        actorEmail: currentUser.email,
        actorRole: currentUser.role,
        action: 'USER_LOGOUT',
        targetType: 'auth',
        targetId: currentUser.uid,
        details: 'User logged out',
      });
    }
    setCurrentUser(null);
    storageService.setCurrentUser(null);
  };

  const resetPassword = async (email: string) => {
    await new Promise((r) => setTimeout(r, 400));
    return {
      success: true,
      message: `${email} ঠিকানায় পাসওয়ার্ড রিসেট লিংক এবং নির্দেশনা পাঠানো হয়েছে। ইনবক্স অথবা স্প্যাম ফোল্ডার চেক করুন।`,
    };
  };

  const switchDemoRole = (role: 'applicant' | 'admin') => {
    if (role === 'admin') {
      const adminUser = INITIAL_SEED_USERS[0]; // mrrudro700@gmail.com
      setCurrentUser(adminUser);
      storageService.setCurrentUser(adminUser);
    } else {
      const demoApplicant = INITIAL_SEED_USERS[1]; // tanvir.ahmed@example.com
      setCurrentUser(demoApplicant);
      storageService.setCurrentUser(demoApplicant);
    }
  };

  const updateProfile = (data: Partial<UserProfile>) => {
    if (!currentUser) return;
    const updated = { ...currentUser, ...data };
    setCurrentUser(updated);
    storageService.setCurrentUser(updated);

    const users = storageService.getUsers().map((u) => (u.uid === updated.uid ? updated : u));
    storageService.saveUsers(users);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAdmin,
        isLoading,
        login,
        register,
        logout,
        resetPassword,
        switchDemoRole,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
