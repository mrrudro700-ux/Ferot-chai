import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Claim,
  PaymentSubmission,
  AppSettings,
  InAppNotification,
  AuditLog,
  ClaimStatus,
  PaymentStatus,
} from '../types';
import {
  storageService,
  DEFAULT_SETTINGS,
} from '../services/storageAdapter';
import { useAuth } from './AuthContext';

interface DataContextType {
  claims: Claim[];
  payments: PaymentSubmission[];
  settings: AppSettings;
  notifications: InAppNotification[];
  auditLogs: AuditLog[];
  unreadNotifsCount: number;
  
  // Claim methods
  createClaim: (claimData: Omit<Claim, 'id' | 'referenceNumber' | 'claimStatus' | 'paymentStatus' | 'statusExplanation' | 'nextRecommendedAction' | 'createdAt' | 'updatedAt'>) => Promise<Claim>;
  getClaimByRef: (ref: string) => Claim | undefined;
  updateClaimStatus: (
    claimId: string,
    newStatus: ClaimStatus,
    explanation: string,
    nextAction: string,
    notes?: string
  ) => void;
  provideAdditionalInfo: (claimId: string, text: string, newEvidence?: any[]) => void;
  requestAdditionalInfo: (claimId: string, promptText: string) => void;
  recordProviderComplaintRef: (claimId: string, ticketNumber: string) => void;
  recordRefundEvidence: (claimId: string, evidenceText: string) => void;

  // Payment methods
  submitPaymentProof: (
    claimReference: string,
    transactionId: string,
    reportedAmount: number,
    paymentDateTime: string,
    evidenceUrl?: string
  ) => Promise<{ success: boolean; error?: string; submission?: PaymentSubmission }>;
  verifyPaymentSubmission: (paymentId: string, status: PaymentStatus, reviewerNotes?: string) => void;

  // Settings
  updateAppSettings: (newSettings: Partial<AppSettings>) => void;

  // Notifications
  markNotifAsRead: (id: string) => void;
  markAllNotifsAsRead: () => void;

  // Refresh
  refreshData: () => void;
}

const DataContext = createContext<DataContextType>({} as DataContextType);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, isAdmin } = useAuth();
  const [claims, setClaims] = useState<Claim[]>(() => storageService.getClaims());
  const [payments, setPayments] = useState<PaymentSubmission[]>(() => storageService.getPayments());
  const [settings, setSettings] = useState<AppSettings>(() => storageService.getSettings());
  const [notifications, setNotifications] = useState<InAppNotification[]>(() => storageService.getNotifications());
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => storageService.getAuditLogs());

  const refreshData = () => {
    setClaims(storageService.getClaims());
    setPayments(storageService.getPayments());
    setSettings(storageService.getSettings());
    setNotifications(storageService.getNotifications(currentUser?.uid));
    setAuditLogs(storageService.getAuditLogs());
  };

  useEffect(() => {
    refreshData();
  }, [currentUser]);

  const userNotifications = notifications.filter(
    (n) => n.recipientUid === currentUser?.uid || n.recipientUid === 'all'
  );
  const unreadNotifsCount = userNotifications.filter((n) => !n.read).length;

  // Generate unique human-friendly application reference: e.g. FC-2026-84912
  const generateReferenceNumber = (): string => {
    const year = new Date().getFullYear();
    const randomNum = Math.floor(10000 + Math.random() * 90000);
    return `FC-${year}-${randomNum}`;
  };

  const createClaim = async (
    claimData: Omit<
      Claim,
      'id' | 'referenceNumber' | 'claimStatus' | 'paymentStatus' | 'statusExplanation' | 'nextRecommendedAction' | 'createdAt' | 'updatedAt'
    >
  ): Promise<Claim> => {
    const ref = generateReferenceNumber();
    const now = new Date().toISOString();

    const newClaim: Claim = {
      ...claimData,
      id: `claim-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      referenceNumber: ref,
      claimStatus: 'Submitted',
      paymentStatus: 'Awaiting Payment',
      statusExplanation: 'আবেদনটি সফলভাবে দাখিল করা হয়েছে। সেবা প্রক্রিয়া সম্পন্ন করতে নির্ধারিত ১০৯ টাকা নগদ সেন্ড মানি ফি প্রদান করুন।',
      nextRecommendedAction: `নগদ অ্যাপে গিয়ে ${settings.receivingNumber} নম্বরে ১০৯ টাকা সেন্ড মানি করে প্রাপ্ত Transaction ID সাবমিট করুন।`,
      createdAt: now,
      updatedAt: now,
    };

    const updated = [newClaim, ...claims];
    storageService.saveClaims(updated);
    setClaims(updated);

    // Audit Log
    storageService.addAuditLog({
      actorUid: currentUser?.uid || 'guest',
      actorEmail: currentUser?.email || 'guest@ferotchai.com',
      actorRole: currentUser?.role || 'user',
      action: 'CLAIM_SUBMITTED',
      targetType: 'claim',
      targetId: newClaim.id,
      details: `New claim filed: ${newClaim.referenceNumber} (${newClaim.serviceProvider}, ৳${newClaim.amountSent})`,
    });

    // Create Notification
    const notifs = storageService.getNotifications();
    const newNotif: InAppNotification = {
      id: `notif-${Date.now()}`,
      recipientUid: newClaim.ownerUid,
      title: 'নতুন আবেদন দাখিল সফল',
      message: `আপনার অভিযোগ (${newClaim.referenceNumber}) নথিভুক্ত হয়েছে। অনুগ্রহ করে ১০৯ টাকা সার্ভিস ফি জমা দিন।`,
      type: 'claim_update',
      read: false,
      claimReference: newClaim.referenceNumber,
      createdAt: now,
    };
    storageService.saveNotifications([newNotif, ...notifs]);
    setNotifications([newNotif, ...notifs]);

    return newClaim;
  };

  const getClaimByRef = (ref: string): Claim | undefined => {
    return claims.find((c) => c.referenceNumber.trim().toUpperCase() === ref.trim().toUpperCase());
  };

  const updateClaimStatus = (
    claimId: string,
    newStatus: ClaimStatus,
    explanation: string,
    nextAction: string,
    notes?: string
  ) => {
    const updated = claims.map((c) => {
      if (c.id === claimId) {
        return {
          ...c,
          claimStatus: newStatus,
          statusExplanation: explanation,
          nextRecommendedAction: nextAction,
          adminInternalNotes: notes || c.adminInternalNotes,
          updatedAt: new Date().toISOString(),
        };
      }
      return c;
    });

    storageService.saveClaims(updated);
    setClaims(updated);

    const targetClaim = claims.find((c) => c.id === claimId);
    if (targetClaim) {
      storageService.addAuditLog({
        actorUid: currentUser?.uid || 'admin',
        actorEmail: currentUser?.email || 'admin@ferotchai.com',
        actorRole: 'admin',
        action: 'CLAIM_STATUS_UPDATED',
        targetType: 'claim',
        targetId: claimId,
        details: `Claim ${targetClaim.referenceNumber} status changed to "${newStatus}"`,
      });

      // Send in-app notification to claim owner
      const notifs = storageService.getNotifications();
      const newNotif: InAppNotification = {
        id: `notif-${Date.now()}`,
        recipientUid: targetClaim.ownerUid,
        title: `আবেদনের অবস্থা আপডেট: ${newStatus}`,
        message: explanation,
        type: 'claim_update',
        read: false,
        claimReference: targetClaim.referenceNumber,
        createdAt: new Date().toISOString(),
      };
      storageService.saveNotifications([newNotif, ...notifs]);
      setNotifications([newNotif, ...notifs]);
    }
  };

  const requestAdditionalInfo = (claimId: string, promptText: string) => {
    const updated = claims.map((c) => {
      if (c.id === claimId) {
        return {
          ...c,
          claimStatus: 'More Information Required' as ClaimStatus,
          moreInfoRequestedPrompt: promptText,
          statusExplanation: `অ্যাডমিন অতিরিক্ত তথ্য চেয়েছেন: "${promptText}"`,
          nextRecommendedAction: 'অনুগ্রহ করে নিচে প্রয়োজনীয় তথ্য বা নথি আপলোড করে জমা দিন।',
          updatedAt: new Date().toISOString(),
        };
      }
      return c;
    });

    storageService.saveClaims(updated);
    setClaims(updated);

    const targetClaim = claims.find((c) => c.id === claimId);
    if (targetClaim) {
      storageService.addAuditLog({
        actorUid: currentUser?.uid || 'admin',
        actorEmail: currentUser?.email || 'admin@ferotchai.com',
        actorRole: 'admin',
        action: 'MORE_INFO_REQUESTED',
        targetType: 'claim',
        targetId: claimId,
        details: `Requested info for ${targetClaim.referenceNumber}: "${promptText}"`,
      });

      const notifs = storageService.getNotifications();
      const newNotif: InAppNotification = {
        id: `notif-${Date.now()}`,
        recipientUid: targetClaim.ownerUid,
        title: 'অতিরিক্ত তথ্য প্রয়োজন',
        message: `আপনার ${targetClaim.referenceNumber} আবেদনের জন্য অতিরিক্ত তথ্য চাওয়া হয়েছে: ${promptText}`,
        type: 'info_requested',
        read: false,
        claimReference: targetClaim.referenceNumber,
        createdAt: new Date().toISOString(),
      };
      storageService.saveNotifications([newNotif, ...notifs]);
      setNotifications([newNotif, ...notifs]);
    }
  };

  const provideAdditionalInfo = (claimId: string, text: string, newEvidence?: any[]) => {
    const updated = claims.map((c) => {
      if (c.id === claimId) {
        return {
          ...c,
          additionalInfoProvided: text,
          evidenceFiles: newEvidence ? [...c.evidenceFiles, ...newEvidence] : c.evidenceFiles,
          claimStatus: 'Under Review' as ClaimStatus,
          statusExplanation: 'ব্যবহারকারী অতিরিক্ত তথ্য প্রদান করেছেন। তথ্যটি অ্যাডমিন টিম পর্যবেক্ষণ করছে।',
          nextRecommendedAction: 'পর্যালোচনা সম্পন্ন হওয়া পর্যন্ত অপেক্ষা করুন।',
          updatedAt: new Date().toISOString(),
        };
      }
      return c;
    });

    storageService.saveClaims(updated);
    setClaims(updated);

    const targetClaim = claims.find((c) => c.id === claimId);
    if (targetClaim) {
      storageService.addAuditLog({
        actorUid: currentUser?.uid || 'user',
        actorEmail: currentUser?.email || 'user@ferotchai.com',
        actorRole: 'user',
        action: 'ADDITIONAL_INFO_SUBMITTED',
        targetType: 'claim',
        targetId: claimId,
        details: `Applicant supplied requested info for ${targetClaim.referenceNumber}`,
      });
    }
  };

  const recordProviderComplaintRef = (claimId: string, ticketNumber: string) => {
    const updated = claims.map((c) => {
      if (c.id === claimId) {
        return {
          ...c,
          providerComplaintRef: ticketNumber,
          claimStatus: 'Referred to Provider' as ClaimStatus,
          statusExplanation: `অফিসিয়াল প্রোভাইডার অভিযোগ নম্বর: ${ticketNumber}। প্রতিষ্ঠানটির সাপোর্ট ডেস্কে অভিযোগ প্রেরণ করা হয়েছে।`,
          updatedAt: new Date().toISOString(),
        };
      }
      return c;
    });

    storageService.saveClaims(updated);
    setClaims(updated);
  };

  const recordRefundEvidence = (claimId: string, evidenceText: string) => {
    const updated = claims.map((c) => {
      if (c.id === claimId) {
        return {
          ...c,
          confirmedRefundEvidence: evidenceText,
          claimStatus: 'Resolved' as ClaimStatus,
          statusExplanation: `টাকা সফলভাবে ফেরত প্রদান করা হয়েছে। রিফান্ড নিশ্চিতকরণ তথ্য: ${evidenceText}`,
          nextRecommendedAction: 'আবেদনটি সফলভাবে সম্পন্ন হয়েছে।',
          updatedAt: new Date().toISOString(),
        };
      }
      return c;
    });

    storageService.saveClaims(updated);
    setClaims(updated);
  };

  const submitPaymentProof = async (
    claimReference: string,
    transactionId: string,
    reportedAmount: number,
    paymentDateTime: string,
    evidenceUrl?: string
  ): Promise<{ success: boolean; error?: string; submission?: PaymentSubmission }> => {
    const targetClaim = getClaimByRef(claimReference);
    if (!targetClaim) {
      return { success: false, error: 'উক্ত রেফারেন্স নম্বরের কোনো আবেদন খুঁজে পাওয়া যায়নি।' };
    }

    // Check duplicate transaction ID
    const existingPayments = storageService.getPayments();
    const cleanTrxId = transactionId.trim().toUpperCase();
    if (existingPayments.some((p) => p.reportedTransactionId.toUpperCase() === cleanTrxId && p.status !== 'Rejected')) {
      return { success: false, error: 'এই ট্রানজ্যাকশন আইডি (Transaction ID) ইতিপূর্বে অন্য একটি পেমেন্টে ব্যবহৃত হয়েছে।' };
    }

    const now = new Date().toISOString();
    const newSubmission: PaymentSubmission = {
      id: `pay-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      claimId: targetClaim.id,
      claimReference: targetClaim.referenceNumber,
      ownerUid: targetClaim.ownerUid,
      paymentProvider: 'Nagad',
      expectedFee: settings.serviceFee,
      reportedAmount,
      reportedTransactionId: cleanTrxId,
      paymentDateTime: paymentDateTime || now,
      evidenceUrl,
      status: 'Payment Submitted',
      submittedAt: now,
    };

    const updatedPayments = [newSubmission, ...existingPayments];
    storageService.savePayments(updatedPayments);
    setPayments(updatedPayments);

    // Update claim payment status
    const updatedClaims = claims.map((c) => {
      if (c.id === targetClaim.id) {
        return {
          ...c,
          paymentStatus: 'Payment Submitted' as PaymentStatus,
          claimStatus: c.claimStatus === 'Submitted' ? ('Under Review' as ClaimStatus) : c.claimStatus,
          statusExplanation: '১০৯ টাকার নগদ পেমেন্ট জমা দেওয়া হয়েছে। অ্যাডমিন টিম ম্যানুয়ালি স্টেটমেন্ট যাচাই করছে।',
          nextRecommendedAction: 'পেমেন্ট যাচাইয়ের পর আপনার আবেদনের পরবর্তী পদক্ষেপ গ্রহণ করা হবে।',
          updatedAt: now,
        };
      }
      return c;
    });
    storageService.saveClaims(updatedClaims);
    setClaims(updatedClaims);

    // Audit log
    storageService.addAuditLog({
      actorUid: currentUser?.uid || targetClaim.ownerUid,
      actorEmail: currentUser?.email || 'applicant@ferotchai.com',
      actorRole: 'user',
      action: 'PAYMENT_SUBMITTED',
      targetType: 'payment',
      targetId: newSubmission.id,
      details: `Payment submitted for ${claimReference}: Nagad TrxID ${cleanTrxId}, Amount ৳${reportedAmount}`,
    });

    return { success: true, submission: newSubmission };
  };

  const verifyPaymentSubmission = (paymentId: string, status: PaymentStatus, reviewerNotes?: string) => {
    const now = new Date().toISOString();
    let affectedClaimId = '';

    const updatedPayments = payments.map((p) => {
      if (p.id === paymentId) {
        affectedClaimId = p.claimId;
        return {
          ...p,
          status,
          reviewerUid: currentUser?.uid || 'admin-rudro',
          reviewerName: currentUser?.fullName || 'এডমিন মডারেটর',
          reviewerNotes: reviewerNotes || p.reviewerNotes,
          verifiedAt: now,
        };
      }
      return p;
    });
    storageService.savePayments(updatedPayments);
    setPayments(updatedPayments);

    if (affectedClaimId) {
      const updatedClaims = claims.map((c) => {
        if (c.id === affectedClaimId) {
          const isVerified = status === 'Verified';
          return {
            ...c,
            paymentStatus: status,
            statusExplanation: isVerified
              ? '১০৯ টাকা সার্ভিস ফি সফলভাবে যাচাই হয়েছে। সংশ্লিষ্ট সার্ভিস প্রোভাইডারের সাথে যোগাযোগ প্রক্রিয়া শুরু হয়েছে।'
              : `পেমেন্ট স্ট্যাটাস: ${status} (${reviewerNotes || 'পুনরায় সঠিক ট্রানজ্যাকশন আইডি প্রদান করুন'})`,
            updatedAt: now,
          };
        }
        return c;
      });
      storageService.saveClaims(updatedClaims);
      setClaims(updatedClaims);

      const targetPayment = payments.find((p) => p.id === paymentId);
      if (targetPayment) {
        // Send Notification
        const notifs = storageService.getNotifications();
        const newNotif: InAppNotification = {
          id: `notif-${Date.now()}`,
          recipientUid: targetPayment.ownerUid,
          title: status === 'Verified' ? 'পেমেন্ট যাচাই সম্পন্ন' : `পেমেন্ট আপডেট: ${status}`,
          message: status === 'Verified'
            ? `আপনার ${targetPayment.claimReference} আবেদনের ১০৯ টাকা সার্ভিস ফি ভেরিফাই করা হয়েছে।`
            : `আপনার ${targetPayment.claimReference} আবেদনের পেমেন্ট সংক্রান্ত তথ্য: ${reviewerNotes || status}`,
          type: 'payment_update',
          read: false,
          claimReference: targetPayment.claimReference,
          createdAt: now,
        };
        storageService.saveNotifications([newNotif, ...notifs]);
        setNotifications([newNotif, ...notifs]);

        storageService.addAuditLog({
          actorUid: currentUser?.uid || 'admin',
          actorEmail: currentUser?.email || 'admin@ferotchai.com',
          actorRole: 'admin',
          action: 'PAYMENT_VERIFIED',
          targetType: 'payment',
          targetId: paymentId,
          details: `Payment for ${targetPayment.claimReference} marked as "${status}". Reviewer note: ${reviewerNotes || 'Verified'}`,
        });
      }
    }
  };

  const updateAppSettings = (newSettings: Partial<AppSettings>) => {
    const updated = { ...settings, ...newSettings };
    storageService.saveSettings(updated);
    setSettings(updated);

    storageService.addAuditLog({
      actorUid: currentUser?.uid || 'admin',
      actorEmail: currentUser?.email || 'admin@ferotchai.com',
      actorRole: 'admin',
      action: 'UPDATE_SETTINGS',
      targetType: 'settings',
      targetId: 'global',
      details: `Settings updated: Fee=৳${updated.serviceFee}, Nagad=${updated.receivingNumber}`,
    });
  };

  const markNotifAsRead = (id: string) => {
    const updated = notifications.map((n) => (n.id === id ? { ...n, read: true } : n));
    storageService.saveNotifications(updated);
    setNotifications(updated);
  };

  const markAllNotifsAsRead = () => {
    const updated = notifications.map((n) => ({ ...n, read: true }));
    storageService.saveNotifications(updated);
    setNotifications(updated);
  };

  return (
    <DataContext.Provider
      value={{
        claims,
        payments,
        settings,
        notifications: userNotifications,
        auditLogs,
        unreadNotifsCount,
        createClaim,
        getClaimByRef,
        updateClaimStatus,
        provideAdditionalInfo,
        requestAdditionalInfo,
        recordProviderComplaintRef,
        recordRefundEvidence,
        submitPaymentProof,
        verifyPaymentSubmission,
        updateAppSettings,
        markNotifAsRead,
        markAllNotifsAsRead,
        refreshData,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => useContext(DataContext);
