import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { useLanguage } from '../context/LanguageContext';
import {
  RotateCcw,
  Bell,
  User,
  Shield,
  Menu,
  X,
  FilePlus,
  Search,
  HelpCircle,
  PhoneCall,
  CheckCircle,
  ExternalLink,
  ChevronDown,
  LogOut,
  Sparkles,
} from 'lucide-react';

interface Props {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenTrackModal?: () => void;
}

export const Navbar: React.FC<Props> = ({ activeTab, setActiveTab }) => {
  const { currentUser, isAdmin, logout, switchDemoRole } = useAuth();
  const { notifications, unreadNotifsCount, markNotifAsRead, markAllNotifsAsRead } = useData();
  const { lang, setLang, t } = useLanguage();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: t('navHome') },
    { id: 'new-claim', label: t('navNewClaim') },
    { id: 'track', label: t('navTrack') },
    { id: 'fee', label: t('navFee') },
    { id: 'security', label: t('navSecurity') },
    { id: 'guidance', label: t('navGuidance') },
    { id: 'contact', label: t('navContact') },
  ];

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top Banner Notice */}
      <div className="bg-emerald-900 text-emerald-100 text-xs py-1.5 px-4 text-center flex items-center justify-center gap-2 font-medium">
        <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
        <span>সার্ভিস ফি মাত্র ১০৯ টাকা • কোনো পিন বা ওটিপি শেয়ার করবেন না • ভুল লেনদেনের সহায়তা প্ল্যাটফর্ম</span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button
            type="button"
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 text-left focus:outline-hidden group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-md shadow-emerald-600/20 group-hover:scale-105 transition-transform">
              <RotateCcw className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-black tracking-tight text-slate-900">
                  ফেরত চাই
                </span>
                <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                  Ferot Chai
                </span>
              </div>
              <p className="text-[10px] text-slate-500 hidden sm:block font-medium">
                ভুল লেনদেনের অভিযোগ সহায়তা
              </p>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                type="button"
                onClick={() => handleNavClick(link.id)}
                className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors ${
                  activeTab === link.id
                    ? 'text-emerald-700 bg-emerald-50 font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Right Action Icons & Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Quick Demo Role Switcher (Applicant vs Admin) */}
            <div className="hidden sm:flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs">
              <button
                type="button"
                onClick={() => switchDemoRole('applicant')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                  !isAdmin
                    ? 'bg-white text-slate-800 shadow-xs font-semibold'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
                title="সাধারণ আবেদনকারীর দৃষ্টিকোণ"
              >
                👤 আবেদনকারী
              </button>
              <button
                type="button"
                onClick={() => switchDemoRole('admin')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-all flex items-center gap-1 ${
                  isAdmin
                    ? 'bg-emerald-600 text-white shadow-xs font-semibold'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
                title="অ্যাডমিন প্যানেল (মডারেটর রুদ্র)"
              >
                <Shield className="w-3 h-3" />
                🛡️ এডমিন
              </button>
            </div>

            {/* In-app Notification Bell */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setNotifDropdownOpen(!notifDropdownOpen)}
                className="relative p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors focus:outline-hidden"
                aria-label="Notifications"
              >
                <Bell className="w-5 h-5" />
                {unreadNotifsCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center animate-bounce">
                    {unreadNotifsCount}
                  </span>
                )}
              </button>

              {/* Notification Dropdown */}
              {notifDropdownOpen && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-slate-200 py-3 z-50">
                  <div className="px-4 pb-2 border-b border-slate-100 flex items-center justify-between">
                    <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                      <Bell className="w-4 h-4 text-emerald-600" />
                      নোটিফিকেশন
                    </h4>
                    {unreadNotifsCount > 0 && (
                      <button
                        type="button"
                        onClick={markAllNotifsAsRead}
                        className="text-xs text-emerald-600 hover:text-emerald-700 font-medium"
                      >
                        সব পড়া হয়েছে
                      </button>
                    )}
                  </div>
                  <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                    {notifications.length === 0 ? (
                      <div className="p-6 text-center text-xs text-slate-400">
                        কোনো নতুন নোটিফিকেশন নেই
                      </div>
                    ) : (
                      notifications.slice(0, 6).map((notif) => (
                        <div
                          key={notif.id}
                          onClick={() => {
                            markNotifAsRead(notif.id);
                            if (notif.claimReference) {
                              setActiveTab('dashboard');
                              setNotifDropdownOpen(false);
                            }
                          }}
                          className={`p-3 text-left hover:bg-slate-50 cursor-pointer transition-colors ${
                            !notif.read ? 'bg-emerald-50/40' : ''
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <p className="text-xs font-bold text-slate-900">
                              {notif.title}
                            </p>
                            {!notif.read && (
                              <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0 mt-1"></span>
                            )}
                          </div>
                          <p className="text-xs text-slate-600 mt-1 line-clamp-2">
                            {notif.message}
                          </p>
                          {notif.claimReference && (
                            <span className="inline-block mt-1 font-mono text-[10px] text-emerald-700 bg-emerald-100/60 px-1.5 py-0.5 rounded">
                              {notif.claimReference}
                            </span>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* User Profile / Dashboard Button */}
            {currentUser ? (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors focus:outline-hidden"
                >
                  <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 font-bold text-xs flex items-center justify-center">
                    {currentUser.fullName.charAt(0)}
                  </div>
                  <span className="hidden sm:inline-block text-xs font-bold text-slate-800 max-w-[100px] truncate">
                    {currentUser.fullName}
                  </span>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {userDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50">
                    <div className="px-4 py-2 border-b border-slate-100">
                      <p className="text-xs font-bold text-slate-900 truncate">
                        {currentUser.fullName}
                      </p>
                      <p className="text-[11px] text-slate-500 truncate">
                        {currentUser.email}
                      </p>
                      <span className="inline-block mt-1 text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                        {currentUser.role === 'admin' ? '🛡️ Administrator' : 'আবেদনকারী'}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setActiveTab('dashboard');
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <User className="w-4 h-4 text-emerald-600" />
                      আমার ড্যাশবোর্ড
                    </button>

                    {isAdmin && (
                      <button
                        type="button"
                        onClick={() => {
                          setActiveTab('admin');
                          setUserDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-xs font-bold text-emerald-700 hover:bg-emerald-50 flex items-center gap-2"
                      >
                        <Shield className="w-4 h-4 text-emerald-600" />
                        অ্যাডমিন ম্যানেজমেন্ট
                      </button>
                    )}

                    <div className="border-t border-slate-100 my-1"></div>

                    <button
                      type="button"
                      onClick={() => {
                        logout();
                        setUserDropdownOpen(false);
                        setActiveTab('home');
                      }}
                      className="w-full text-left px-4 py-2 text-xs font-medium text-rose-600 hover:bg-rose-50 flex items-center gap-2"
                    >
                      <LogOut className="w-4 h-4" />
                      লগআউট
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                type="button"
                onClick={() => handleNavClick('login')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors shadow-xs"
              >
                <User className="w-3.5 h-3.5" />
                লগইন
              </button>
            )}

            {/* Mobile Menu Toggle Button */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-2 pb-6 space-y-2 shadow-lg animate-in slide-in-from-top-2">
          {/* Quick Demo Switcher on Mobile */}
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-100 text-xs mb-3">
            <span className="font-medium text-slate-600">রোল পরিবর্তন করুন:</span>
            <div className="flex gap-1">
              <button
                type="button"
                onClick={() => {
                  switchDemoRole('applicant');
                  setMobileMenuOpen(false);
                }}
                className={`px-2 py-1 rounded text-xs font-medium ${
                  !isAdmin ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                আবেদনকারী
              </button>
              <button
                type="button"
                onClick={() => {
                  switchDemoRole('admin');
                  setMobileMenuOpen(false);
                }}
                className={`px-2 py-1 rounded text-xs font-medium ${
                  isAdmin ? 'bg-emerald-600 text-white' : 'text-slate-600'
                }`}
              >
                এডমিন
              </button>
            </div>
          </div>

          {navLinks.map((link) => (
            <button
              key={link.id}
              type="button"
              onClick={() => handleNavClick(link.id)}
              className={`w-full text-left px-3 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
                activeTab === link.id
                  ? 'text-emerald-700 bg-emerald-50 font-bold'
                  : 'text-slate-700 hover:bg-slate-100'
              }`}
            >
              {link.label}
            </button>
          ))}

          {currentUser && (
            <button
              type="button"
              onClick={() => handleNavClick('dashboard')}
              className="w-full text-left px-3 py-2.5 rounded-xl text-sm font-bold text-emerald-700 bg-emerald-50/60"
            >
              আমার ড্যাশবোর্ড ({currentUser.fullName})
            </button>
          )}

          {isAdmin && (
            <button
              type="button"
              onClick={() => handleNavClick('admin')}
              className="w-full text-left px-3 py-2.5 rounded-xl text-sm font-bold text-purple-700 bg-purple-50"
            >
              🛡️ অ্যাডমিন কনসোল
            </button>
          )}
        </div>
      )}
    </header>
  );
};
