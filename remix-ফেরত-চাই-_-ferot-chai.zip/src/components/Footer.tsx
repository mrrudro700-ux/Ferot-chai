import React from 'react';
import { RotateCcw, ShieldCheck, Phone, Mail, MapPin, AlertCircle, ExternalLink } from 'lucide-react';

interface Props {
  setActiveTab: (tab: string) => void;
  openLegalTab?: (tab: string) => void;
}

export const Footer: React.FC<Props> = ({ setActiveTab, openLegalTab }) => {
  const handleLegalClick = (legalSection: string) => {
    setActiveTab('legal');
    if (openLegalTab) {
      openLegalTab(legalSection);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-900 text-slate-300 pt-14 pb-10 border-t border-slate-800 text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 pb-12 border-b border-slate-800">
          
          {/* Col 1: Brand & Identity */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-900 flex items-center justify-center font-black shadow-md">
                <RotateCcw className="w-5 h-5 stroke-[2.5]" />
              </div>
              <div>
                <span className="text-xl font-black text-white tracking-tight">ফেরত চাই</span>
                <span className="ml-2 text-xs font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800/60">
                  Ferot Chai
                </span>
              </div>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed">
              “ভুল লেনদেনের অভিযোগ, সহজে ও নিরাপদে।” <br />
              ভুল রিচার্জ ও এমএফএস লেনদেনের অভিযোগ সংক্রান্ত তথ্য নথিভুক্তকরণ, পরামর্শ ও ট্র্যাকিং প্ল্যাটফর্ম।
            </p>
            <div className="pt-1 text-xs text-emerald-400 font-semibold flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" />
              সার্ভিস ফি মাত্র ১০৯ টাকা (নগদ সেন্ড মানি)
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div>
            <h4 className="text-white font-bold text-sm mb-3">গুরুত্বপূর্ণ লিংক</h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button
                  type="button"
                  onClick={() => { setActiveTab('new-claim'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-emerald-400 transition-colors"
                >
                  নতুন অভিযোগ দাখিল
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => { setActiveTab('track'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-emerald-400 transition-colors"
                >
                  আবেদনের অগ্রগতি ট্র্যাক
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => { setActiveTab('fee'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-emerald-400 transition-colors"
                >
                  ১০৯ টাকা সার্ভিস ফি ব্যাখ্যা
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => { setActiveTab('guidance'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-emerald-400 transition-colors"
                >
                  অফিসিয়াল হেল্পলাইন ও জিডি গাইড
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => { setActiveTab('security'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-emerald-400 transition-colors"
                >
                  নিরাপত্তা ও গোপনীয়তা নির্দেশিকা
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Legal & Policies */}
          <div>
            <h4 className="text-white font-bold text-sm mb-3">শর্তাবলি ও নীতিমালা</h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button
                  type="button"
                  onClick={() => handleLegalClick('terms')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  সেবার সাধারণ শর্তাবলি (Terms of Service)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleLegalClick('privacy')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  গোপনীয়তা নীতি (Privacy Policy)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleLegalClick('refund')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  রিফান্ড ও ফি নীতি (Refund Policy)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleLegalClick('safety')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  প্রতারণা প্রতিরোধ ও নিরাপত্তা নীতি
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleLegalClick('contact')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  যোগাযোগ ও অভিযোগ বক্স
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Official Helplines Directory */}
          <div>
            <h4 className="text-white font-bold text-sm mb-3">জরুরি অফিশিয়াল হেল্পলাইন</h4>
            <p className="text-[11px] text-slate-400 mb-2">
              সরাসরি প্রোভাইডারের হটলাইনে কল করে তাৎক্ষণিক সহায়তা চাইতে পারেন:
            </p>
            <div className="space-y-1.5 text-xs">
              <div className="flex items-center justify-between bg-slate-800/80 p-2 rounded-lg">
                <span className="font-medium text-slate-200">বিকাশ (bKash)</span>
                <a href="tel:16247" className="font-mono text-emerald-400 font-bold hover:underline">16247</a>
              </div>
              <div className="flex items-center justify-between bg-slate-800/80 p-2 rounded-lg">
                <span className="font-medium text-slate-200">নগদ (Nagad)</span>
                <a href="tel:16167" className="font-mono text-amber-400 font-bold hover:underline">16167</a>
              </div>
              <div className="flex items-center justify-between bg-slate-800/80 p-2 rounded-lg">
                <span className="font-medium text-slate-200">রকেট (Rocket)</span>
                <a href="tel:16216" className="font-mono text-purple-400 font-bold hover:underline">16216</a>
              </div>
              <div className="flex items-center justify-between bg-slate-800/80 p-2 rounded-lg">
                <span className="font-medium text-slate-200">জাতীয় জরুরি সেবা</span>
                <a href="tel:999" className="font-mono text-rose-400 font-bold hover:underline">999</a>
              </div>
            </div>
          </div>
        </div>

        {/* Disclaimer Card (MANDATORY REQUIREMENT) */}
        <div className="mt-8 p-4 sm:p-5 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-slate-400 leading-relaxed">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-slate-200 mb-1">
                ফেরত চাই (Ferot Chai) প্ল্যাটফর্মের সংবিধিবদ্ধ নোটিশ:
              </p>
              <p className="text-slate-400">
                “ফেরত চাই একটি স্বাধীন অভিযোগ-সহায়তা প্ল্যাটফর্ম। এটি কোনো মোবাইল ফাইন্যান্সিয়াল সার্ভিস প্রতিষ্ঠানের অফিসিয়াল অ্যাপ নয়। টাকা ফেরত পাওয়া সংশ্লিষ্ট প্রতিষ্ঠানের যাচাই, নীতিমালা এবং প্রযোজ্য আইনের ওপর নির্ভরশীল।”
              </p>
              <p className="text-[11px] text-slate-500 mt-2">
                নির্ধারিত ১০৯ টাকা সার্ভিস ফি আবেদন যাচাইকরণ, অভিযোগ ডকুমেন্ট ড্রাফটিং ও ট্র্যাকিং সেবার জন্য প্রযোজ্য। এটি কোনো লেনদেন প্রত্যাহারের নিশ্চয়তা প্রদান করে না।
              </p>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© {new Date().getFullYear()} ফেরত চাই | Ferot Chai (Bangladesh). সর্বস্বত্ব সংরক্ষিত।</p>
          <div className="flex items-center gap-4">
            <span>বাংলাদেশি ফিনটেক স্ট্যান্ডার্ড এনক্রিপশন</span>
            <span>•</span>
            <span>শূন্য-প্রতারণা নিশ্চয়তা</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
