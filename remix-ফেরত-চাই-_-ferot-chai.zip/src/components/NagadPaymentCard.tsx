import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { Copy, Check, ShieldAlert, ArrowRight, Smartphone, AlertCircle, Info } from 'lucide-react';
import { formatTaka } from '../services/storageAdapter';

interface Props {
  claimReference?: string;
  onProceedToSubmit?: () => void;
  compact?: boolean;
}

export const NagadPaymentCard: React.FC<Props> = ({ claimReference, onProceedToSubmit, compact = false }) => {
  const { settings } = useData();
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(settings.receivingNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="bg-gradient-to-br from-white to-amber-50/50 rounded-2xl border-2 border-amber-300/80 shadow-md p-5 md:p-6 relative overflow-hidden">
      {/* Decorative top accent */}
      <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500"></div>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-amber-200/60">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center text-white font-bold text-xl shadow-sm">
            নগদ
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase tracking-wider font-semibold px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                Send Money Only
              </span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                সার্ভিস ফি: {formatTaka(settings.serviceFee)}
              </span>
            </div>
            <h3 className="text-lg md:text-xl font-bold text-slate-800 mt-1">
              নগদ সেন্ড মানি পেমেন্ট নির্দেশনা
            </h3>
          </div>
        </div>

        {claimReference && (
          <div className="bg-white/80 px-3 py-1.5 rounded-lg border border-amber-200 text-xs text-slate-600 self-start md:self-auto">
            আবেদন রেফারেন্স: <strong className="text-slate-900 font-mono">{claimReference}</strong>
          </div>
        )}
      </div>

      {/* Receiving number highlight */}
      <div className="mt-5 p-4 rounded-xl bg-white border border-amber-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500 mb-0.5">নগদ প্রাপক নম্বর (Send Money Destination)</p>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-wider font-mono">
              {settings.receivingNumber}
            </span>
            <span className="text-xs font-semibold text-rose-600 bg-rose-50 px-2 py-0.5 rounded">
              শুধুমাত্র সেন্ড মানি
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={handleCopy}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm transition-all shadow-sm ${
            copied
              ? 'bg-emerald-600 text-white'
              : 'bg-amber-500 hover:bg-amber-600 active:scale-95 text-white'
          }`}
        >
          {copied ? (
            <>
              <Check className="w-4 h-4" />
              কপি হয়েছে!
            </>
          ) : (
            <>
              <Copy className="w-4 h-4" />
              নম্বর কপি করুন
            </>
          )}
        </button>
      </div>

      {/* Required Exact Bangla Instruction Prompt */}
      <div className="mt-4 p-4 rounded-xl bg-amber-50 border border-amber-200/80 text-slate-700 text-sm leading-relaxed">
        <p className="font-semibold text-amber-900 flex items-center gap-1.5 mb-1.5">
          <Smartphone className="w-4 h-4 text-amber-700" />
          পেমেন্ট করার নিয়ম:
        </p>
        <p className="text-slate-800 font-medium">
          “পেমেন্ট করতে আপনার নগদ অ্যাপ খুলুন। <span className="text-amber-800 font-bold underline">Send Money</span> অপশন ব্যবহার করে প্রদর্শিত প্রাপকের নম্বরে নির্ধারিত সার্ভিস ফি পাঠান। লেনদেন সম্পন্ন হলে আপনার <span className="font-bold">Transaction ID</span> দিয়ে পেমেন্ট জমা দিন। পেমেন্ট যাচাই না হওয়া পর্যন্ত আবেদনটি পেমেন্ট-অপেক্ষমাণ অবস্থায় থাকবে।”
        </p>
      </div>

      {/* Strict Anti-Fraud Security Notice */}
      <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs text-slate-600">
        <div className="flex items-start gap-2 bg-rose-50/70 p-2.5 rounded-lg border border-rose-200/60 text-rose-800">
          <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          <span>
            <strong>সতর্কতা:</strong> কোনো Cash Out করবেন না। ফেরত চাই কর্তৃপক্ষ কখনোই আপনার পিন (PIN), ওটিপি (OTP) বা পাসওয়ার্ড চাইবে না।
          </span>
        </div>
        <div className="flex items-start gap-2 bg-blue-50/70 p-2.5 rounded-lg border border-blue-200/60 text-blue-800">
          <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
          <span>
            <strong>ম্যানুয়াল ভেরিফিকেশন:</strong> ট্রানজ্যাকশন আইডি ও স্টেটমেন্ট ম্যানুয়ালি যাচাই করার পরই পেমেন্ট অনুমোদিত হবে।
          </span>
        </div>
      </div>

      {onProceedToSubmit && (
        <div className="mt-5 pt-3 border-t border-amber-200/60 flex justify-end">
          <button
            type="button"
            onClick={onProceedToSubmit}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl font-bold text-white bg-slate-900 hover:bg-slate-800 shadow-md transition-all text-sm"
          >
            পেমেন্টের তথ্য (TrxID) জমা দিন
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
