import React from 'react';
import { ClaimStatus, PaymentStatus } from '../types';
import { Clock, CheckCircle2, AlertTriangle, ArrowRightCircle, XCircle, RotateCcw } from 'lucide-react';

interface Props {
  type: 'claim' | 'payment';
  status: ClaimStatus | PaymentStatus;
  size?: 'sm' | 'md' | 'lg';
}

export const StatusBadge: React.FC<Props> = ({ type, status, size = 'md' }) => {
  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 gap-1',
    md: 'text-xs md:text-sm px-2.5 py-1 gap-1.5',
    lg: 'text-sm md:text-base px-3 py-1.5 gap-2',
  }[size];

  // CLAIM STATUSES
  if (type === 'claim') {
    switch (status as ClaimStatus) {
      case 'Submitted':
        return (
          <span className={`inline-flex items-center font-medium rounded-full bg-blue-50 text-blue-700 border border-blue-200 ${sizeClasses}`}>
            <Clock className="w-3.5 h-3.5 text-blue-500" />
            আবেদন জমা হয়েছে (Submitted)
          </span>
        );
      case 'Under Review':
        return (
          <span className={`inline-flex items-center font-medium rounded-full bg-amber-50 text-amber-700 border border-amber-200 ${sizeClasses}`}>
            <Clock className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
            পর্যালোচনা চলছে (Under Review)
          </span>
        );
      case 'More Information Required':
        return (
          <span className={`inline-flex items-center font-medium rounded-full bg-orange-50 text-orange-700 border border-orange-200 ${sizeClasses}`}>
            <AlertTriangle className="w-3.5 h-3.5 text-orange-500" />
            অতিরিক্ত তথ্য প্রয়োজন (More Info)
          </span>
        );
      case 'Referred to Provider':
        return (
          <span className={`inline-flex items-center font-medium rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 ${sizeClasses}`}>
            <ArrowRightCircle className="w-3.5 h-3.5 text-indigo-500" />
            অপারেটরে প্রেরিত (Referred)
          </span>
        );
      case 'Resolved':
        return (
          <span className={`inline-flex items-center font-medium rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 ${sizeClasses}`}>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            নিষ্পত্তি হয়েছে (Resolved)
          </span>
        );
      case 'Rejected':
        return (
          <span className={`inline-flex items-center font-medium rounded-full bg-rose-50 text-rose-700 border border-rose-200 ${sizeClasses}`}>
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            বাতিল করা হয়েছে (Rejected)
          </span>
        );
      default:
        return null;
    }
  }

  // PAYMENT STATUSES
  switch (status as PaymentStatus) {
    case 'Awaiting Payment':
      return (
        <span className={`inline-flex items-center font-medium rounded-full bg-slate-100 text-slate-700 border border-slate-200 ${sizeClasses}`}>
          <Clock className="w-3.5 h-3.5 text-slate-500" />
          পেমেন্ট বাকি (Awaiting)
        </span>
      );
    case 'Payment Submitted':
      return (
        <span className={`inline-flex items-center font-medium rounded-full bg-amber-50 text-amber-700 border border-amber-200 ${sizeClasses}`}>
          <Clock className="w-3.5 h-3.5 text-amber-500 animate-spin" />
          পেমেন্ট জমা হয়েছে (Submitted)
        </span>
      );
    case 'Under Verification':
      return (
        <span className={`inline-flex items-center font-medium rounded-full bg-blue-50 text-blue-700 border border-blue-200 ${sizeClasses}`}>
          <Clock className="w-3.5 h-3.5 text-blue-500 animate-pulse" />
          যাচাই চলছে (Under Verification)
        </span>
      );
    case 'Verified':
      return (
        <span className={`inline-flex items-center font-medium rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 ${sizeClasses}`}>
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
          পেমেন্ট সফল (Verified)
        </span>
      );
    case 'Rejected':
      return (
        <span className={`inline-flex items-center font-medium rounded-full bg-rose-50 text-rose-700 border border-rose-200 ${sizeClasses}`}>
          <XCircle className="w-3.5 h-3.5 text-rose-600" />
          পেমেন্ট বাতিল (Rejected)
        </span>
      );
    case 'Refunded':
      return (
        <span className={`inline-flex items-center font-medium rounded-full bg-purple-50 text-purple-700 border border-purple-200 ${sizeClasses}`}>
          <RotateCcw className="w-3.5 h-3.5 text-purple-600" />
          ফি ফেরত (Refunded)
        </span>
      );
    default:
      return null;
  }
};
