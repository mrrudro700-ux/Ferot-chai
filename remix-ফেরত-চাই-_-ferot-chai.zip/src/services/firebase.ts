/**
 * Firebase Client Initialization & Error Handling Module
 */
import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { getFirestore, Firestore } from 'firebase/firestore';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null,
  authInstance?: Auth
) {
  const currentAuth = authInstance || auth;
  const user = currentAuth?.currentUser;

  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: user?.uid,
      email: user?.email,
      emailVerified: user?.emailVerified,
      isAnonymous: user?.isAnonymous,
      tenantId: user?.tenantId,
    },
    operationType,
    path,
  };

  console.error('Firestore Error:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Fallback configuration for demonstration when external keys are not yet bound
const fallbackFirebaseConfig = {
  apiKey: "DEMO_KEY_FEROT_CHAI",
  authDomain: "ferot-chai-demo.firebaseapp.com",
  projectId: "ferot-chai-demo",
  storageBucket: "ferot-chai-demo.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:demo123456"
};

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;
let isFirebaseLive = false;

try {
  // Check if standard firebase-applet-config exists or window config
  const existingApps = getApps();
  if (existingApps.length > 0) {
    app = existingApps[0];
  } else {
    app = initializeApp(fallbackFirebaseConfig);
  }
  auth = getAuth(app);
  db = getFirestore(app);
} catch (e) {
  console.warn('Firebase initialized in fallback mode:', e);
}

export { app, auth, db, isFirebaseLive };
