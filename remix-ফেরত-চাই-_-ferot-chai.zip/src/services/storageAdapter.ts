import { Claim, PaymentSubmission, AppSettings, InAppNotification, AuditLog, UserProfile } from '../types';

const STORAGE_KEYS = {
  CLAIMS: 'ferotchai_claims_v1',
  PAYMENTS: 'ferotchai_payments_v1',
  SETTINGS: 'ferotchai_settings_v1',
  NOTIFICATIONS: 'ferotchai_notifications_v1',
  AUDIT_LOGS: 'ferotchai_audit_logs_v1',
  USERS: 'ferotchai_users_v1',
  CURRENT_USER: 'ferotchai_current_user_v1',
};

export const DEFAULT_SETTINGS: AppSettings = {
  receivingNumber: '01831027877',
  serviceFee: 109,
  paymentProvider: 'Nagad',
  isAcceptingPayments: true,
  serviceNotice: 'নগদ সেন্ড মানির মাধ্যমে ১০৯ টাকা সার্ভিস ফি প্রদান করুন। পেমেন্ট ম্যানুয়ালি যাচাই করা হবে।',
};

export const INITIAL_SEED_USERS: UserProfile[] = [
  {
    uid: 'admin-rudro',
    email: 'mrrudro700@gmail.com',
    fullName: 'মডারেটর রুদ্র (Admin)',
    phone: '01700000000',
    role: 'admin',
    emailVerified: true,
    createdAt: '2026-01-10T10:00:00.000Z',
  },
  {
    uid: 'user-demo-1',
    email: 'tanvir.ahmed@example.com',
    fullName: 'তানভীর আহমেদ',
    phone: '01819234567',
    role: 'user',
    emailVerified: true,
    createdAt: '2026-02-15T11:20:00.000Z',
  },
];

export const INITIAL_SEED_CLAIMS: Claim[] = [
  {
    id: 'claim-1',
    referenceNumber: 'FC-2026-89412',
    ownerUid: 'user-demo-1',
    applicantName: 'তানভীর আহমেদ',
    applicantPhone: '01819234567',
    applicantEmail: 'tanvir.ahmed@example.com',
    preferredContact: 'phone',
    transactionType: 'Send Money',
    serviceProvider: 'bKash',
    transactionId: 'BL9A2X4490',
    transactionDate: '2026-10-21',
    transactionTime: '14:35',
    amountSent: 3500,
    senderPhone: '01819234567',
    recipientPhone: '01712987654',
    mistakeExplanation: 'বাবার চিকিৎসার জন্য টাকা পাঠানোর সময় একটি ডিজিট ভুল হওয়ায় অপরিচিত নম্বরে ৩,৫০০ টাকা চলে যায়। প্রাপককে অনুরোধ করা হলেও ফোন রিসিভ করছেন না।',
    evidenceFiles: [
      {
        name: 'bkash_statement_sms.png',
        url: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80',
        size: 245000,
        type: 'image/png',
        uploadedAt: '2026-10-21T14:40:00.000Z',
      },
    ],
    claimStatus: 'Referred to Provider',
    paymentStatus: 'Verified',
    statusExplanation: 'বিকাশ কাস্টমার কেয়ারে আনুষ্ঠানিক অভিযোগ (টিকেট #BK-2026-9041) নথিভুক্ত করা হয়েছে। বিকাশ হেল্পলাইন প্রতিনিধি প্রাপকের সাথে সমঝোতার অনুরোধ পাঠিয়েছেন।',
    nextRecommendedAction: 'বিকাশ থেকে যোগাযোগ করার জন্য অপেক্ষা করুন অথবা নিকটস্থ বিকাশ সেবা কেন্দ্রে যোগাযোগ করুন।',
    providerComplaintRef: 'BK-2026-9041',
    adminInternalNotes: 'পেমেন্ট ১০৯ টাকা যাচাই সম্পন্ন। বিকাশ অভিযোগ ফরম পূরণ করে অফিশিয়াল মেইলে ফরোয়ার্ড করা হয়েছে।',
    createdAt: '2026-10-21T14:45:00.000Z',
    updatedAt: '2026-10-22T10:15:00.000Z',
  },
  {
    id: 'claim-2',
    referenceNumber: 'FC-2026-78105',
    ownerUid: 'user-demo-1',
    applicantName: 'তানভীর আহমেদ',
    applicantPhone: '01819234567',
    applicantEmail: 'tanvir.ahmed@example.com',
    preferredContact: 'whatsapp',
    transactionType: 'ভুল রিচার্জ',
    serviceProvider: 'Mobile Recharge',
    transactionId: 'RC8192301',
    transactionDate: '2026-10-22',
    transactionTime: '09:15',
    amountSent: 500,
    senderPhone: '01819234567',
    recipientPhone: '01987654321',
    mistakeExplanation: 'দোকান থেকে ৫০০ টাকা গ্রামীণফোন নাম্বারে রিচার্জ করার সময় অপারেটর ভুল করে অন্য নম্বরে ফ্ল্যাক্সিলোড করে ফেলেন।',
    evidenceFiles: [],
    claimStatus: 'Under Review',
    paymentStatus: 'Payment Submitted',
    statusExplanation: 'আবেদন এবং ১০৯ টাকার নগদ পেমেন্ট জমা হয়েছে। এডমিন প্যানেল ট্রানজ্যাকশন আইডি ও তথ্য যাচাই করছে।',
    nextRecommendedAction: 'পেমেন্ট ভেরিফিকেশনের জন্য কিছু সময় অপেক্ষা করুন। ভেরিফাই হলে পরবর্তী সহায়তা নির্দেশনা পাঠানো হবে।',
    createdAt: '2026-10-22T09:30:00.000Z',
    updatedAt: '2026-10-22T11:00:00.000Z',
  },
  {
    id: 'claim-3',
    referenceNumber: 'FC-2026-62044',
    ownerUid: 'user-demo-1',
    applicantName: 'তানভীর আহমেদ',
    applicantPhone: '01819234567',
    applicantEmail: 'tanvir.ahmed@example.com',
    preferredContact: 'phone',
    transactionType: 'Send Money',
    serviceProvider: 'Nagad',
    transactionId: 'NG77123490',
    transactionDate: '2026-10-18',
    transactionTime: '17:20',
    amountSent: 1200,
    senderPhone: '01819234567',
    recipientPhone: '01655443322',
    mistakeExplanation: 'নগদ অ্যাকাউন্টে ভুলবশত ১,২০০ টাকা চলে গিয়েছিল। প্রাপকের সাথে যোগাযোগ করে ভুল নিশ্চিত করার পর টাকা ফেরত সম্পন্ন হয়েছে।',
    evidenceFiles: [],
    claimStatus: 'Resolved',
    paymentStatus: 'Verified',
    statusExplanation: 'অভিযোগের ভিত্তিতে প্রাপকের সাথে ভদ্রভাবে যোগাযোগ করে ভুল বোঝাবুঝি নিরসন হয়েছে এবং পুরো ১,২০০ টাকা আবেদনকারীর একাউন্টে ফেরত দেওয়া হয়েছে।',
    nextRecommendedAction: 'আবেদনটি সফলভাবে সম্পন্ন হয়েছে। আপনার একাউন্ট ব্যালেন্স চেক করে সন্তুষ্টি নিশ্চিত করুন।',
    confirmedRefundEvidence: 'নগদ রিফান্ড ট্রানজ্যাকশন আইডি: NG-REF-992144 (১,২০০ টাকা ফেরত নিশ্চিত)',
    adminInternalNotes: 'প্রাপকের সাথে সমঝোতা সফল। ১,২০০ টাকা আবেদনকারীর নম্বরে পুনরায় ফেরত পাঠানো নিশ্চিত করা হয়েছে।',
    createdAt: '2026-10-18T17:30:00.000Z',
    updatedAt: '2026-10-19T14:00:00.000Z',
  },
  {
    id: 'claim-4',
    referenceNumber: 'FC-2026-55198',
    ownerUid: 'user-demo-1',
    applicantName: 'তানভীর আহমেদ',
    applicantPhone: '01819234567',
    applicantEmail: 'tanvir.ahmed@example.com',
    preferredContact: 'phone',
    transactionType: 'Send Money',
    serviceProvider: 'Rocket',
    transactionDate: '2026-10-23',
    transactionTime: '12:00',
    amountSent: 4500,
    senderPhone: '01819234567',
    recipientPhone: '01511223344',
    mistakeExplanation: 'রকেটের ১২ ডিজিট নম্বরের শেষের চেক ডিজিট ভুল হওয়ায় অন্য গ্রাহকের একাউন্টে চলে যায়।',
    evidenceFiles: [],
    claimStatus: 'Submitted',
    paymentStatus: 'Awaiting Payment',
    statusExplanation: 'আপনার আবেদনটি প্রাথমিক ড্রাফট আকারে গ্রহণ করা হয়েছে। সেবা প্রক্রিয়া শুরু করতে নির্ধারিত ১০৯ টাকা সার্ভিস ফি প্রদান করুন।',
    nextRecommendedAction: 'নগদ Send Money দিয়ে 01831027877 নম্বরে ১০৯ টাকা পাঠিয়ে ট্রানজ্যাকশন আইডি সাবমিট করুন।',
    createdAt: '2026-10-23T12:05:00.000Z',
    updatedAt: '2026-10-23T12:05:00.000Z',
  },
];

export const INITIAL_SEED_PAYMENTS: PaymentSubmission[] = [
  {
    id: 'pay-1',
    claimId: 'claim-1',
    claimReference: 'FC-2026-89412',
    ownerUid: 'user-demo-1',
    paymentProvider: 'Nagad',
    expectedFee: 109,
    reportedAmount: 109,
    reportedTransactionId: '9G7K2L89X1',
    paymentDateTime: '2026-10-21T15:00',
    status: 'Verified',
    reviewerUid: 'admin-rudro',
    reviewerName: 'মডারেটর রুদ্র',
    reviewerNotes: 'নগদ স্টেটমেন্ট চেক করে ১০৯ টাকা প্রাপ্তি নিশ্চিত করা হয়েছে।',
    verifiedAt: '2026-10-21T15:30:00.000Z',
    submittedAt: '2026-10-21T15:02:00.000Z',
  },
  {
    id: 'pay-2',
    claimId: 'claim-2',
    claimReference: 'FC-2026-78105',
    ownerUid: 'user-demo-1',
    paymentProvider: 'Nagad',
    expectedFee: 109,
    reportedAmount: 109,
    reportedTransactionId: '9N4T8V22Q9',
    paymentDateTime: '2026-10-22T09:45',
    status: 'Payment Submitted',
    submittedAt: '2026-10-22T09:50:00.000Z',
  },
  {
    id: 'pay-3',
    claimId: 'claim-3',
    claimReference: 'FC-2026-62044',
    ownerUid: 'user-demo-1',
    paymentProvider: 'Nagad',
    expectedFee: 109,
    reportedAmount: 109,
    reportedTransactionId: '8X1M9Q55K3',
    paymentDateTime: '2026-10-18T18:00',
    status: 'Verified',
    reviewerUid: 'admin-rudro',
    reviewerName: 'মডারেটর রুদ্র',
    reviewerNotes: 'পেমেন্ট ১০৯ টাকা গৃহীত।',
    verifiedAt: '2026-10-18T18:15:00.000Z',
    submittedAt: '2026-10-18T18:05:00.000Z',
  },
];

export const INITIAL_NOTIFICATIONS: InAppNotification[] = [
  {
    id: 'notif-1',
    recipientUid: 'user-demo-1',
    title: 'আবেদন গৃহীত হয়েছে',
    message: 'আপনার আবেদন FC-2026-89412 সফলভাবে তৈরি হয়েছে। নগদ ১০৯ টাকা সার্ভিস ফি জমা দিন।',
    type: 'claim_update',
    read: true,
    claimReference: 'FC-2026-89412',
    createdAt: '2026-10-21T14:45:00.000Z',
  },
  {
    id: 'notif-2',
    recipientUid: 'user-demo-1',
    title: 'পেমেন্ট ভেরিফাই হয়েছে',
    message: 'FC-2026-89412 আবেদনের জন্য ১০৯ টাকা পেমেন্ট নিশ্চিত করা হয়েছে। অভিযোগ প্রসেস শুরু হয়েছে।',
    type: 'payment_update',
    read: false,
    claimReference: 'FC-2026-89412',
    createdAt: '2026-10-21T15:30:00.000Z',
  },
];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log-1',
    actorUid: 'system',
    actorEmail: 'system@ferotchai.com',
    actorRole: 'admin',
    action: 'SYSTEM_BOOTSTRAP',
    targetType: 'settings',
    targetId: 'global',
    details: 'Initial system bootstrap and fee configuration established (৳109, Nagad: 01831027877)',
    timestamp: '2026-01-01T00:00:00.000Z',
  },
  {
    id: 'log-2',
    actorUid: 'admin-rudro',
    actorEmail: 'mrrudro700@gmail.com',
    actorRole: 'admin',
    action: 'VERIFY_PAYMENT',
    targetType: 'payment',
    targetId: 'pay-1',
    details: 'Admin verified ৳109 payment for FC-2026-89412 (Nagad TrxID: 9G7K2L89X1)',
    timestamp: '2026-10-21T15:30:00.000Z',
  },
  {
    id: 'log-3',
    actorUid: 'admin-rudro',
    actorEmail: 'mrrudro700@gmail.com',
    actorRole: 'admin',
    action: 'UPDATE_CLAIM_STATUS',
    targetType: 'claim',
    targetId: 'claim-1',
    details: 'Status transitioned to "Referred to Provider" with ticket #BK-2026-9041',
    timestamp: '2026-10-22T10:15:00.000Z',
  },
];

// Helper to mask phone numbers for privacy protection
export function maskPhoneNumber(phone?: string): string {
  if (!phone) return '—';
  const clean = phone.replace(/\s+/g, '');
  if (clean.length < 8) return clean;
  // e.g. 01831027877 -> 01831***877
  return `${clean.slice(0, 5)}***${clean.slice(-3)}`;
}

// Convert English numbers to Bengali numerals
export function toBengaliNumber(num: number | string): string {
  const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return String(num).replace(/[0-9]/g, (digit) => bengaliDigits[parseInt(digit, 10)]);
}

// Format Taka currency in Bengali style
export function formatTaka(amount: number): string {
  return `৳${amount.toLocaleString('en-IN')}`;
}

// Format Bengali date
export function formatBanglaDate(dateString: string): string {
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return d.toLocaleDateString('bn-BD', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateString;
  }
}

// Storage service methods
export const storageService = {
  getClaims(): Claim[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CLAIMS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.CLAIMS, JSON.stringify(INITIAL_SEED_CLAIMS));
        return INITIAL_SEED_CLAIMS;
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_SEED_CLAIMS;
    }
  },

  saveClaims(claims: Claim[]) {
    localStorage.setItem(STORAGE_KEYS.CLAIMS, JSON.stringify(claims));
  },

  getClaimByRef(ref: string): Claim | undefined {
    const cleanRef = ref.trim().toUpperCase();
    return this.getClaims().find((c) => c.referenceNumber.toUpperCase() === cleanRef);
  },

  getClaimsByUser(ownerUid: string): Claim[] {
    return this.getClaims().filter((c) => c.ownerUid === ownerUid);
  },

  getPayments(): PaymentSubmission[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PAYMENTS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(INITIAL_SEED_PAYMENTS));
        return INITIAL_SEED_PAYMENTS;
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_SEED_PAYMENTS;
    }
  },

  savePayments(payments: PaymentSubmission[]) {
    localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(payments));
  },

  getSettings(): AppSettings {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(DEFAULT_SETTINGS));
        return DEFAULT_SETTINGS;
      }
      return JSON.parse(data);
    } catch {
      return DEFAULT_SETTINGS;
    }
  },

  saveSettings(settings: AppSettings) {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  },

  getNotifications(uid?: string): InAppNotification[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
      const list: InAppNotification[] = data ? JSON.parse(data) : INITIAL_NOTIFICATIONS;
      if (uid) {
        return list.filter((n) => n.recipientUid === uid || n.recipientUid === 'all');
      }
      return list;
    } catch {
      return INITIAL_NOTIFICATIONS;
    }
  },

  saveNotifications(notifs: InAppNotification[]) {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifs));
  },

  getAuditLogs(): AuditLog[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(INITIAL_AUDIT_LOGS));
        return INITIAL_AUDIT_LOGS;
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_AUDIT_LOGS;
    }
  },

  addAuditLog(log: Omit<AuditLog, 'id' | 'timestamp'>) {
    const list = this.getAuditLogs();
    const newLog: AuditLog = {
      ...log,
      id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      timestamp: new Date().toISOString(),
    };
    list.unshift(newLog);
    // keep max 500 logs
    const trimmed = list.slice(0, 500);
    localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(trimmed));
    return newLog;
  },

  getUsers(): UserProfile[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.USERS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_SEED_USERS));
        return INITIAL_SEED_USERS;
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_SEED_USERS;
    }
  },

  saveUsers(users: UserProfile[]) {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  },

  getCurrentUser(): UserProfile | null {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
      if (!data) {
        // Default to demo user tanvir
        return INITIAL_SEED_USERS[1];
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_SEED_USERS[1];
    }
  },

  setCurrentUser(user: UserProfile | null) {
    if (user) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
  },
};
