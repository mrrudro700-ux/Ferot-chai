import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useData } from '../context/DataContext';
import { NagadPaymentCard } from '../components/NagadPaymentCard';
import {
  RotateCcw,
  ShieldCheck,
  Search,
  FileText,
  Clock,
  AlertTriangle,
  ArrowRight,
  PhoneCall,
  CheckCircle2,
  Lock,
  ChevronRight,
  HelpCircle,
  Sparkles,
  Smartphone,
  ExternalLink,
  Info,
} from 'lucide-react';
import { formatTaka } from '../services/storageAdapter';

interface Props {
  setActiveTab: (tab: string) => void;
  openPaymentModalForRef?: (ref: string) => void;
}

export const HomePage: React.FC<Props> = ({ setActiveTab, openPaymentModalForRef }) => {
  const { t } = useLanguage();
  const { settings, claims } = useData();
  const [quickTrackRef, setQuickTrackRef] = useState('');

  const supportedServices = [
    {
      id: 'bkash',
      name: 'bKash (বিকাশ)',
      color: 'from-pink-600 to-rose-600',
      badge: 'MFS',
      helpline: '16247',
      desc: 'ভুল নম্বরে সেন্ড মানি বা ভুল পেমেন্টের আনুষ্ঠানিক অভিযোগ সহায়তা।',
      iconText: 'bK',
    },
    {
      id: 'nagad',
      name: 'Nagad (নগদ)',
      color: 'from-amber-500 to-orange-600',
      badge: 'MFS',
      helpline: '16167',
      desc: 'ভুল সেন্ট মানি লেনদেনের ট্র্যাকিং ও কাস্টমার কেয়ার গাইডলাইন।',
      iconText: 'নগদ',
    },
    {
      id: 'rocket',
      name: 'Rocket (রকেট)',
      color: 'from-purple-600 to-indigo-700',
      badge: 'MFS',
      helpline: '16216',
      desc: '১২ ডিজিট একাউন্ট নম্বরের ভুল লেনদেন রিকভারি সহায়তা।',
      iconText: 'DBBL',
    },
    {
      id: 'upay',
      name: 'Upay (উপায়)',
      color: 'from-blue-600 to-cyan-700',
      badge: 'MFS',
      helpline: '16419',
      desc: 'ইউসিবি উপায় ওয়ালেটে ভুল ট্রান্সফার সংক্রান্ত অভিযোগ গাইড।',
      iconText: 'upay',
    },
    {
      id: 'recharge',
      name: 'Mobile Recharge (মোবাইল রিচার্জ)',
      color: 'from-emerald-600 to-teal-700',
      badge: 'অপারেটর',
      helpline: '121',
      desc: 'গ্রামীনফোন, রবি, এয়ারটেল, বাংলালিংক, টেলিটকে ভুল রিচার্জ।',
      iconText: 'Flexi',
    },
    {
      id: 'other',
      name: 'Other Services (অন্যান্য সেবা)',
      color: 'from-slate-700 to-slate-900',
      badge: 'ব্যাংক ও ওয়ালেট',
      helpline: '16xxx',
      desc: 'ট্যাপ, সেলফিন, আইব্যাংকিং বা অন্যান্য ডিজিটাল ওয়ালেট লেনদেন।',
      iconText: 'Other',
    },
  ];

  const handleQuickTrackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (quickTrackRef.trim()) {
      setActiveTab('track');
    }
  };

  return (
    <div className="space-y-16 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-white to-slate-50 pt-12 pb-16 md:pt-20 md:pb-24 border-b border-emerald-100/60">
        {/* Subtle grid background */}
        <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:24px_24px] opacity-[0.12] pointer-events-none"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          {/* Trust Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100/90 border border-emerald-300 text-emerald-800 text-xs sm:text-sm font-bold mb-6 shadow-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <span>বাংলাদেশি নাগরিকদের জন্য ভুল লেনদেন অভিযোগ সহায়তা পোর্টাল</span>
          </div>

          {/* Hero Title */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-tight max-w-4xl mx-auto">
            “ভুল করে টাকা পাঠিয়েছেন?”
          </h1>

          {/* Hero Subtitle */}
          <p className="mt-5 text-base sm:text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed font-medium">
            “আপনার ভুল রিচার্জ বা মোবাইল ফাইন্যান্সিয়াল সার্ভিস লেনদেনের অভিযোগ নথিভুক্ত করুন এবং আবেদনের অগ্রগতি দেখুন।”
          </p>

          {/* Call to Actions */}
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto">
            <button
              type="button"
              onClick={() => setActiveTab('new-claim')}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 rounded-xl text-base font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-95 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
            >
              <RotateCcw className="w-5 h-5 stroke-[2.5]" />
              আবেদন করুন
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('track')}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-4 rounded-xl text-base font-bold text-slate-800 bg-white hover:bg-slate-50 border-2 border-slate-200 active:scale-95 shadow-sm transition-all cursor-pointer"
            >
              <Search className="w-5 h-5 text-slate-600" />
              আবেদন ট্র্যাক করুন
            </button>
          </div>

          {/* Quick Track Search Input */}
          <div className="mt-8 max-w-md mx-auto bg-white p-2 rounded-2xl border border-slate-200 shadow-md">
            <form onSubmit={handleQuickTrackSubmit} className="flex items-center gap-2">
              <input
                type="text"
                placeholder="রেফারেন্স নম্বর (যেমন: FC-2026-89412)"
                value={quickTrackRef}
                onChange={(e) => setQuickTrackRef(e.target.value)}
                className="flex-1 px-3 py-2 text-sm text-slate-800 placeholder-slate-400 bg-transparent focus:outline-hidden font-mono"
              />
              <button
                type="submit"
                onClick={() => setActiveTab('track')}
                className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition-colors shrink-0"
              >
                ট্র্যাক
              </button>
            </form>
          </div>

          {/* Real stats row */}
          <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto pt-8 border-t border-slate-200/80 text-left">
            <div className="bg-white/80 backdrop-blur-xs p-4 rounded-xl border border-slate-200/80 shadow-xs">
              <p className="text-2xl font-black text-slate-900">৳১০৯</p>
              <p className="text-xs text-slate-500 font-medium">নির্ধারিত প্রসেসিং ফি</p>
            </div>
            <div className="bg-white/80 backdrop-blur-xs p-4 rounded-xl border border-slate-200/80 shadow-xs">
              <p className="text-2xl font-black text-emerald-600">১০০%</p>
              <p className="text-xs text-slate-500 font-medium">পিন ও ওটিপি গোপনীয়তা</p>
            </div>
            <div className="bg-white/80 backdrop-blur-xs p-4 rounded-xl border border-slate-200/80 shadow-xs">
              <p className="text-2xl font-black text-blue-600">২৪/৭</p>
              <p className="text-xs text-slate-500 font-medium">অভিযোগ দাখিল ও ট্র্যাকিং</p>
            </div>
            <div className="bg-white/80 backdrop-blur-xs p-4 rounded-xl border border-slate-200/80 shadow-xs">
              <p className="text-2xl font-black text-purple-600">৪টি ধাপে</p>
              <p className="text-xs text-slate-500 font-medium">যাচাই ও অফিসিয়াল গাইড</p>
            </div>
          </div>
        </div>
      </section>

      {/* Mandatory Official Disclaimer Notice Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-2xl bg-amber-50 border-2 border-amber-300 p-5 sm:p-6 shadow-sm">
          <div className="flex flex-col sm:flex-row items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-amber-200 text-amber-900 flex items-center justify-center shrink-0 font-bold">
              <AlertTriangle className="w-6 h-6 text-amber-800" />
            </div>
            <div className="space-y-1.5">
              <h2 className="text-base sm:text-lg font-bold text-amber-950">
                জরুরি সংবিধিবদ্ধ ঘোষণা (Mandatory Disclosure)
              </h2>
              <p className="text-sm sm:text-base text-amber-900 font-medium leading-relaxed">
                “ফেরত চাই একটি স্বাধীন অভিযোগ-সহায়তা প্ল্যাটফর্ম। এটি কোনো মোবাইল ফাইন্যান্সিয়াল সার্ভিস প্রতিষ্ঠানের অফিসিয়াল অ্যাপ নয়। টাকা ফেরত পাওয়া সংশ্লিষ্ট প্রতিষ্ঠানের যাচাই, নীতিমালা এবং প্রযোজ্য আইনের ওপর নির্ভরশীল।”
              </p>
              <p className="text-xs text-amber-800 pt-1">
                ফেরত চাই কোনো স্বয়ংক্রিয় রিভার্সাল করে না এবং কোনো ব্যক্তি বা এজেন্টের ব্যক্তিগত অ্যাকাউন্টে হস্তক্ষেপের ক্ষমতা রাখে না।
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Supported Services Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            সমর্থিত সেবাসমূহ
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">
            যেসব ভুল লেনদেনের অভিযোগ আমরা গ্রহণ করি
          </h2>
          <p className="text-sm text-slate-600 mt-2">
            বাংলাদেশে বহুল ব্যবহৃত সকল এমএফএস এবং সেলুলার অপারেটর রিচার্জের জন্য সহায়তা প্রদান করা হয়।
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {supportedServices.map((srv) => (
            <div
              key={srv.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition-all hover:-translate-y-0.5 group"
            >
              <div className="flex items-center justify-between mb-4">
                <div
                  className={`w-12 h-12 rounded-xl bg-gradient-to-tr ${srv.color} text-white flex items-center justify-center font-bold text-sm shadow-sm`}
                >
                  {srv.iconText}
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                    {srv.badge}
                  </span>
                  <a
                    href={`tel:${srv.helpline}`}
                    className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 hover:bg-emerald-100"
                    title={`কল করুন ${srv.helpline}`}
                  >
                    <PhoneCall className="w-3 h-3" />
                    {srv.helpline}
                  </a>
                </div>
              </div>

              <h3 className="text-lg font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
                {srv.name}
              </h3>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                {srv.desc}
              </p>

              <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setActiveTab('new-claim')}
                  className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 group-hover:gap-1.5 transition-all"
                >
                  অভিযোগ দাখিল করুন
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('guidance')}
                  className="text-xs text-slate-500 hover:text-slate-800"
                >
                  গাইড দেখুন
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Service Fee Section — Only ৳109 (MANDATORY REQUIREMENT) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-slate-900 to-emerald-950 text-white rounded-3xl p-6 sm:p-10 lg:p-12 shadow-xl relative overflow-hidden">
          <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none"></div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-4">
              <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
                <Sparkles className="w-3.5 h-3.5" />
                স্বচ্ছ ও সাশ্রয়ী সেবা মূল্য
              </div>

              <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                “সার্ভিস ফি মাত্র ১০৯ টাকা।”
              </h2>

              <p className="text-emerald-200 text-sm sm:text-base font-medium leading-relaxed">
                “১০৯ টাকা নির্ধারিত আবেদন-প্রক্রিয়াকরণ সেবার ফি। এটি টাকা ফেরত পাওয়ার নিশ্চয়তা নয়। পেমেন্টের আগে সেবার শর্তাবলি ও রিফান্ড নীতি পড়ুন।”
              </p>

              {/* Service fee breakdown */}
              <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-300">
                <div className="flex items-start gap-2 bg-white/5 p-3 rounded-xl border border-white/10">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>লেনদেনের তথ্য ও প্রমাণপত্র নিয়মানুযায়ী যাচাইকরণ।</span>
                </div>
                <div className="flex items-start gap-2 bg-white/5 p-3 rounded-xl border border-white/10">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>সংশ্লিষ্ট এমএফএস প্রোভাইডারের ফরম্যাট অনুযায়ী আবেদন ড্রাফটিং।</span>
                </div>
                <div className="flex items-start gap-2 bg-white/5 p-3 rounded-xl border border-white/10">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>থানা জিডি (GD) খসড়া ও হেল্পলাইন যোগাযোগের ধারাবাহিক দিকনির্দেশনা।</span>
                </div>
                <div className="flex items-start gap-2 bg-white/5 p-3 rounded-xl border border-white/10">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>অনলাইনে সার্বক্ষণিক আবেদনের অগ্রগতি ট্র্যাকিং সুবিধা।</span>
                </div>
              </div>

              {/* Policy Links */}
              <div className="pt-3 flex flex-wrap items-center gap-4 text-xs text-emerald-300">
                <button
                  type="button"
                  onClick={() => setActiveTab('legal')}
                  className="hover:underline flex items-center gap-1"
                >
                  সেবার শর্তাবলি (Terms)
                  <ExternalLink className="w-3 h-3" />
                </button>
                <span>•</span>
                <button
                  type="button"
                  onClick={() => setActiveTab('legal')}
                  className="hover:underline flex items-center gap-1"
                >
                  রিফান্ড নীতি (Refund Policy)
                  <ExternalLink className="w-3 h-3" />
                </button>
                <span>•</span>
                <button
                  type="button"
                  onClick={() => setActiveTab('legal')}
                  className="hover:underline flex items-center gap-1"
                >
                  গোপনীয়তা নীতি (Privacy Policy)
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            </div>

            {/* Right: Embedded Nagad Instruction Card */}
            <div className="lg:col-span-5 text-slate-800">
              <NagadPaymentCard
                onProceedToSubmit={() => setActiveTab('pay-submit')}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Emergency First-15-Minutes Checklist */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center font-bold">
              <Clock className="w-5 h-5 text-rose-600" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900">
                ভুল লেনদেনের প্রথম ১৫ মিনিটের জরুরি করণীয়
              </h3>
              <p className="text-xs text-slate-500">
                দ্রুত পদক্ষেপ নিলে টাকা উদ্ধারের সম্ভাবনা বহুগুণ বৃদ্ধি পায়
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
              <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center justify-center mb-3">
                ১
              </div>
              <h4 className="font-bold text-slate-900 text-sm mb-1">
                স্ক্রিনশট ও ট্রানজ্যাকশন আইডি সংরক্ষণ
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                লেনদেন সম্পন্ন হওয়ার পর অ্যাপের মেসেজ বা নিশ্চিতকরণ এসএমএসটির স্ক্রিনশট নিন এবং Transaction ID আলাদা নোট করে রাখুন।
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
              <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center justify-center mb-3">
                ২
              </div>
              <h4 className="font-bold text-slate-900 text-sm mb-1">
                প্রাপকের সাথে আক্রমণাত্মক আচরণ না করা
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                প্রাপক নম্বরে ফোন দিলে শান্ত ও মার্জিত ভাষায় বলুন যে ভুলবশত টাকাটি গেছে। কোনো হুমকি বা ভয় দেখাবেন না।
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
              <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center justify-center mb-3">
                ৩
              </div>
              <h4 className="font-bold text-slate-900 text-sm mb-1">
                অফিসিয়াল হেল্পলাইন ও ফেরত চাই-এ অভিযোগ
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                তাত্ক্ষণিকভাবে বিকাশ (16247) বা নগদ (16167) হেল্পলাইনে ফোন করে লেনদেন হোল্ড করার অনুরোধ করুন এবং এখানে অভিযোগ ফর্ম পূরণ করুন।
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Trust & Zero-Fraud Guarantee */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-emerald-50/80 border border-emerald-200 rounded-3xl p-6 sm:p-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                <Lock className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 text-sm">কোনো গোপন পিন নয়</h4>
                <p className="text-xs text-slate-600 mt-0.5">
                  আমরা কখনোই আপনার নগদ/বিকাশ একাউন্টের গোপন পিন বা ওটিপি চাই না।
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 text-sm">তথ্য মাস্কিং ও প্রাইভেসী</h4>
                <p className="text-xs text-slate-600 mt-0.5">
                  সার্বজনীন বা ট্র্যাকিং ভিউতে ফোন নম্বর গোপন রাখা হয় (উদা: 01831***877)।
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 text-sm">হিউম্যান ভেরিফিকেশন</h4>
                <p className="text-xs text-slate-600 mt-0.5">
                  প্রত্যেকটি পেমেন্ট ও অভিযোগ দক্ষ পর্যালোচক দ্বারা ম্যানুয়ালি যাচাই করা হয়।
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
