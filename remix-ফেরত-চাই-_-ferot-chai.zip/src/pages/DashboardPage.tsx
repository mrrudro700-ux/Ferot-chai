import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { StatusBadge } from '../components/StatusBadge';
import { Claim } from '../types';
import {
  User,
  PlusCircle,
  Search,
  CreditCard,
  HelpCircle,
  FileText,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Shield,
  Eye,
  ExternalLink,
  RotateCcw,
  X,
  Phone,
} from 'lucide-react';
import {
  formatBanglaDate,
  formatTaka,
  maskPhoneNumber,
} from '../services/storageAdapter';

interface Props {
  setActiveTab: (tab: string) => void;
  openPaymentForRef?: (ref: string) => void;
}

export const DashboardPage: React.FC<Props> = ({ setActiveTab, openPaymentForRef }) => {
  const { currentUser, isAdmin } = useAuth();
  const { claims } = useData();

  // If user is logged in, show their own applications (or all if admin reviewing, with filter)
  const userClaims = currentUser
    ? claims.filter((c) => c.ownerUid === currentUser.uid || isAdmin)
    : [];

  const [selectedClaim, setSelectedClaim] = useState<Claim | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Stats
  const totalCount = userClaims.length;
  const pendingCount = userClaims.filter((c) => c.claimStatus === 'Submitted').length;
  const underReviewCount = userClaims.filter((c) => c.claimStatus === 'Under Review' || c.claimStatus === 'Referred to Provider').length;
  const resolvedCount = userClaims.filter((c) => c.claimStatus === 'Resolved').length;

  const filteredClaims = userClaims.filter((c) => {
    if (filterStatus === 'all') return true;
    if (filterStatus === 'pending') return c.claimStatus === 'Submitted';
    if (filterStatus === 'review') return c.claimStatus === 'Under Review' || c.claimStatus === 'Referred to Provider';
    if (filterStatus === 'resolved') return c.claimStatus === 'Resolved';
    if (filterStatus === 'pay_awaiting') return c.paymentStatus === 'Awaiting Payment';
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      {/* Top Profile & Welcome Header */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center font-black text-2xl shadow-md">
            {currentUser?.fullName?.charAt(0) || 'U'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-slate-900">
                স্বাগতম, {currentUser?.fullName || 'সম্মানিত গ্রাহক'}
              </h1>
              {isAdmin && (
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-purple-100 text-purple-800 border border-purple-200">
                  🛡️ Admin Access
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-1">
              মোবাইল: <strong className="font-mono text-slate-800">{currentUser?.phone || '018XXXXXXXX'}</strong> • ইমেইল: {currentUser?.email || '—'}
            </p>
          </div>
        </div>

        {/* Action Buttons Row (Mandatory Requirement) */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          <button
            type="button"
            onClick={() => setActiveTab('new-claim')}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            নতুন আবেদন
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('track')}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold text-xs sm:text-sm transition-all"
          >
            <Search className="w-4 h-4 text-slate-500" />
            আবেদন ট্র্যাক করুন
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('guidance')}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold text-xs sm:text-sm transition-all"
          >
            <HelpCircle className="w-4 h-4 text-slate-500" />
            সহায়তা নিন
          </button>
        </div>
      </div>

      {/* Metrics Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div
          onClick={() => setFilterStatus('all')}
          className={`p-5 rounded-2xl border cursor-pointer transition-all ${
            filterStatus === 'all' ? 'bg-slate-900 text-white border-slate-900 shadow-md' : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className={`text-xs font-bold uppercase tracking-wider ${filterStatus === 'all' ? 'text-slate-400' : 'text-slate-500'}`}>
              মোট আবেদন
            </span>
            <FileText className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-3xl font-black mt-2">{totalCount}</p>
          <p className={`text-[11px] mt-1 ${filterStatus === 'all' ? 'text-slate-400' : 'text-slate-400'}`}>সর্বমোট নথিভুক্ত অভিযোগ</p>
        </div>

        <div
          onClick={() => setFilterStatus('pending')}
          className={`p-5 rounded-2xl border cursor-pointer transition-all ${
            filterStatus === 'pending' ? 'bg-blue-600 text-white border-blue-600 shadow-md' : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className={`text-xs font-bold uppercase tracking-wider ${filterStatus === 'pending' ? 'text-blue-100' : 'text-slate-500'}`}>
              পেন্ডিং আবেদন
            </span>
            <Clock className="w-4 h-4 text-blue-400" />
          </div>
          <p className="text-3xl font-black mt-2">{pendingCount}</p>
          <p className={`text-[11px] mt-1 ${filterStatus === 'pending' ? 'text-blue-100' : 'text-slate-400'}`}>পেমেন্ট ও প্রাথমিক ড্রাফট</p>
        </div>

        <div
          onClick={() => setFilterStatus('review')}
          className={`p-5 rounded-2xl border cursor-pointer transition-all ${
            filterStatus === 'review' ? 'bg-amber-600 text-white border-amber-600 shadow-md' : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className={`text-xs font-bold uppercase tracking-wider ${filterStatus === 'review' ? 'text-amber-100' : 'text-slate-500'}`}>
              পর্যালোচনাধীন
            </span>
            <RotateCcw className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-3xl font-black mt-2">{underReviewCount}</p>
          <p className={`text-[11px] mt-1 ${filterStatus === 'review' ? 'text-amber-100' : 'text-slate-400'}`}>অপারেটরে বা কেয়ারে প্রসেসিং</p>
        </div>

        <div
          onClick={() => setFilterStatus('resolved')}
          className={`p-5 rounded-2xl border cursor-pointer transition-all ${
            filterStatus === 'resolved' ? 'bg-emerald-600 text-white border-emerald-600 shadow-md' : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className={`text-xs font-bold uppercase tracking-wider ${filterStatus === 'resolved' ? 'text-emerald-100' : 'text-slate-500'}`}>
              নিষ্পত্তিকৃত
            </span>
            <CheckCircle2 className="w-4 h-4 text-emerald-300" />
          </div>
          <p className="text-3xl font-black mt-2">{resolvedCount}</p>
          <p className={`text-[11px] mt-1 ${filterStatus === 'resolved' ? 'text-emerald-100' : 'text-slate-400'}`}>সফলভাবে সম্পন্ন আবেদন</p>
        </div>
      </div>

      {/* Applications List */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              আপনার আবেদনের তালিকা (Applications)
            </h2>
            <p className="text-xs text-slate-500">
              নিচে আপনার নথিভুক্ত অভিযোগসমূহ ও সর্বশেষ স্ট্যাটাস প্রদর্শিত হচ্ছে।
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">ফিল্টার:</span>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="text-xs font-semibold px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-700 focus:outline-hidden"
            >
              <option value="all">সকল আবেদন ({totalCount})</option>
              <option value="pending">পেন্ডিং ({pendingCount})</option>
              <option value="review">পর্যালোচনাধীন ({underReviewCount})</option>
              <option value="resolved">নিষ্পত্তিকৃত ({resolvedCount})</option>
              <option value="pay_awaiting">পেমেন্ট অপেক্ষমাণ</option>
            </select>
          </div>
        </div>

        {filteredClaims.length === 0 ? (
          <div className="p-12 text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
              <FileText className="w-7 h-7" />
            </div>
            <p className="text-sm font-bold text-slate-700">কোনো আবেদন পাওয়া যায়নি</p>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              আপনি এখনো কোনো অভিযোগ দাখিল করেননি অথবা নির্বাচিত ফিল্টারে কোনো আবেদন নেই।
            </p>
            <button
              type="button"
              onClick={() => setActiveTab('new-claim')}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-xs hover:bg-emerald-700 transition-colors"
            >
              নতুন আবেদন দাখিল করুন
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredClaims.map((claim) => (
              <div
                key={claim.id}
                className="p-5 sm:p-6 hover:bg-slate-50/80 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-2 flex-1">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <span className="font-mono text-sm font-black text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                      {claim.referenceNumber}
                    </span>
                    <span className="text-xs font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                      {claim.serviceProvider}
                    </span>
                    <span className="text-xs font-mono font-bold text-slate-800">
                      {formatTaka(claim.amountSent)}
                    </span>
                    <span className="text-xs text-slate-400">•</span>
                    <span className="text-xs text-slate-500">
                      তারিখ: {claim.transactionDate}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 line-clamp-1">
                    <strong className="text-slate-800">ভুলের কারণ:</strong> {claim.mistakeExplanation}
                  </p>

                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <StatusBadge type="claim" status={claim.claimStatus} size="sm" />
                    <StatusBadge type="payment" status={claim.paymentStatus} size="sm" />

                    {claim.claimStatus === 'More Information Required' && (
                      <span className="text-[11px] font-bold text-orange-700 bg-orange-100 px-2 py-0.5 rounded animate-pulse">
                        ⚠️ অতিরিক্ত তথ্য প্রয়োজন
                      </span>
                    )}
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="flex flex-wrap items-center gap-2 self-start md:self-auto shrink-0">
                  {claim.paymentStatus === 'Awaiting Payment' && (
                    <button
                      type="button"
                      onClick={() => {
                        if (openPaymentForRef) openPaymentForRef(claim.referenceNumber);
                        setActiveTab('pay-submit');
                      }}
                      className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-xs transition-colors flex items-center gap-1"
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      পেমেন্টের তথ্য জমা দিন
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => setSelectedClaim(claim)}
                    className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors flex items-center gap-1"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    বিস্তারিত দেখুন
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* DETAIL MODAL DRAWER */}
      {selectedClaim && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 shadow-2xl relative space-y-6">
            <button
              type="button"
              onClick={() => setSelectedClaim(null)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-slate-900 hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-400 uppercase">অভিযোগ বিস্তারিত</span>
                <span className="font-mono font-black text-slate-900 text-base bg-slate-100 px-2 py-0.5 rounded">
                  {selectedClaim.referenceNumber}
                </span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mt-1">
                {selectedClaim.serviceProvider} - {selectedClaim.transactionType}
              </h3>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <StatusBadge type="claim" status={selectedClaim.claimStatus} />
              <StatusBadge type="payment" status={selectedClaim.paymentStatus} />
            </div>

            {/* Explanation & Action */}
            <div className="space-y-3">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <p className="font-bold text-slate-500 mb-1">বর্তমান অগ্রগতি:</p>
                <p className="text-slate-900 font-medium leading-relaxed">{selectedClaim.statusExplanation}</p>
              </div>

              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950">
                <p className="font-bold text-emerald-800 mb-1">পরবর্তী করণীয়:</p>
                <p className="font-medium leading-relaxed">{selectedClaim.nextRecommendedAction}</p>
              </div>
            </div>

            {/* Transaction Data */}
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 text-xs space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-slate-400">টাকার পরিমাণ:</span>{' '}
                  <strong className="text-emerald-700 font-mono text-sm">{formatTaka(selectedClaim.amountSent)}</strong>
                </div>
                <div>
                  <span className="text-slate-400">TrxID:</span>{' '}
                  <strong className="font-mono text-slate-900">{selectedClaim.transactionId || 'তথ্য নেই'}</strong>
                </div>
                <div>
                  <span className="text-slate-400">প্রেরক নম্বর:</span>{' '}
                  <span className="font-mono text-slate-800">{maskPhoneNumber(selectedClaim.senderPhone)}</span>
                </div>
                <div>
                  <span className="text-slate-400">প্রাপক নম্বর:</span>{' '}
                  <span className="font-mono text-rose-600 font-bold">{maskPhoneNumber(selectedClaim.recipientPhone)}</span>
                </div>
                <div>
                  <span className="text-slate-400">তারিখ:</span>{' '}
                  <span className="text-slate-800">{selectedClaim.transactionDate} ({selectedClaim.transactionTime})</span>
                </div>
                {selectedClaim.providerComplaintRef && (
                  <div>
                    <span className="text-slate-400">প্রোভাইডার টিকিট:</span>{' '}
                    <strong className="font-mono text-indigo-700">{selectedClaim.providerComplaintRef}</strong>
                  </div>
                )}
              </div>
              <div className="pt-2 border-t border-slate-200">
                <span className="text-slate-400">ভুলের কারণ:</span>
                <p className="text-slate-800 italic mt-0.5">{selectedClaim.mistakeExplanation}</p>
              </div>
            </div>

            {selectedClaim.confirmedRefundEvidence && (
              <div className="p-4 rounded-xl bg-emerald-100 border border-emerald-300 text-xs text-emerald-950">
                <p className="font-bold mb-1">রিফান্ড প্রমাণপত্র:</p>
                <p className="font-mono font-medium">{selectedClaim.confirmedRefundEvidence}</p>
              </div>
            )}

            {/* Actions */}
            <div className="pt-2 flex flex-wrap items-center justify-end gap-3">
              {selectedClaim.paymentStatus === 'Awaiting Payment' && (
                <button
                  type="button"
                  onClick={() => {
                    setSelectedClaim(null);
                    if (openPaymentForRef) openPaymentForRef(selectedClaim.referenceNumber);
                    setActiveTab('pay-submit');
                  }}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs"
                >
                  ১০৯ টাকা পেমেন্ট জমা দিন
                </button>
              )}
              <button
                type="button"
                onClick={() => setSelectedClaim(null)}
                className="px-5 py-2.5 rounded-xl bg-slate-900 text-white font-bold text-xs"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
