import React, { useState } from 'react';
import {
  ShieldCheck,
  FileText,
  Lock,
  RotateCcw,
  AlertTriangle,
  Mail,
  Send,
  CheckCircle2,
  Phone,
  HelpCircle,
} from 'lucide-react';
import { formatTaka } from '../services/storageAdapter';

interface Props {
  initialSection?: string;
}

export const LegalPage: React.FC<Props> = ({ initialSection = 'terms' }) => {
  const [activeSection, setActiveSection] = useState(initialSection);
  const [complaintForm, setComplaintForm] = useState({ name: '', phone: '', message: '' });
  const [complaintSubmitted, setComplaintSubmitted] = useState(false);

  const handleComplaintSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!complaintForm.name || !complaintForm.message) return;
    setComplaintSubmitted(true);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      {/* Header */}
      <div className="text-center">
        <span className="text-xs font-bold text-slate-600 bg-slate-100 px-3 py-1 rounded-full border border-slate-200">
          আইনি স্বচ্ছতা ও নীতি
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">
          শর্তাবলি, রিফান্ড ও গোপনীয়তা নীতিমালা
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          ফেরত চাই প্ল্যাটফর্ম ব্যবহারের সংবিধিবদ্ধ শর্ত ও নিরাপত্তা নির্দেশিকা।
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-3 overflow-x-auto text-xs sm:text-sm font-bold">
        {[
          { id: 'terms', label: 'সেবার শর্তাবলি (Terms)' },
          { id: 'privacy', label: 'গোপনীয়তা নীতি (Privacy)' },
          { id: 'refund', label: 'রিফান্ড ও ফি নীতি (Refund)' },
          { id: 'safety', label: 'নিরাপত্তা ও প্রতারণা প্রতিরোধ' },
          { id: 'contact', label: 'যোগাযোগ ও অভিযোগ বক্স' },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveSection(tab.id)}
            className={`px-4 py-2 rounded-xl transition-all whitespace-nowrap ${
              activeSection === tab.id
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* SECTION 1: TERMS OF SERVICE */}
      {activeSection === 'terms' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6 text-sm text-slate-700 leading-relaxed">
          <div className="border-b border-slate-100 pb-3">
            <h2 className="text-xl font-bold text-slate-900">সেবার সাধারণ শর্তাবলি (Terms of Service)</h2>
            <p className="text-xs text-slate-400">সর্বশেষ সংস্করণ: অক্টোবর ২০২৬</p>
          </div>

          <div className="space-y-4">
            <h3 className="font-bold text-slate-900 text-base">১. স্বাধীন অভিযোগ-সহায়তা প্ল্যাটফর্মের প্রকৃতি</h3>
            <p>
              “ফেরত চাই (Ferot Chai)” একটি স্বাধীন প্রযুক্তি প্ল্যাটফর্ম যা ভুল মোবাইল রিচার্জ ও এমএফএস লেনদেনের শিকার হওয়া গ্রাহকদের অভিযোগ নথিভুক্তকরণ, আনুষ্ঠানিক চিঠি ড্রাফটিং ও ট্র্যাকিং সহায়তা দিয়ে থাকে। এটি কোনো ব্যাংক, মোবাইল ফিনান্সিয়াল সার্ভিস (যেমন বিকাশ, নগদ, রকেট, উপায়) অথবা মোবাইল নেটওয়ার্ক অপারেটরের অফিশিয়াল সার্ভিস নয়।
            </p>

            <h3 className="font-bold text-slate-900 text-base">২. রিফান্ডের কোনো নিশ্চয়তা নেই (No Guarantee of Recovery)</h3>
            <p className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-950 font-medium">
              টাকা ফেরত পাওয়া সম্পূর্ণভাবে সংশ্লিষ্ট এমএফএস বা টেলিকম প্রতিষ্ঠানের আনুষ্ঠানিক তদন্ত, প্রমাণ যাচাই, প্রাপকের সততা ও সম্মতি এবং বাংলাদেশ সরকারের প্রচলিত আইন ও বাংলাদেশ ব্যাংকের নির্দেশনার ওপর নির্ভরশীল। ফেরত চাই কোনো লেনদেন স্বয়ংক্রিয়ভাবে বাতিল বা নিশ্চিত রিফান্ডের নিশ্চয়তা প্রদান করে না।
            </p>

            <h3 className="font-bold text-slate-900 text-base">৩. সত্য তথ্য প্রদানের বাধ্যবাধকতা</h3>
            <p>
              আবেদনকারীকে শুধুমাত্র তার নিজের ভুল লেনদেনের বিষয়ে সত্য ও নির্ভুল তথ্য প্রদান করতে হবে। কোনো অসৎ উদ্দেশ্য, অন্যের বিরুদ্ধে মিথ্যা অভিযোগ বা হয়রানির উদ্দেশ্যে অভিযোগ দাখিল করা প্রচলিত আইসিটি আইনের অধীনে শাস্তিযোগ্য অপরাধ।
            </p>

            <h3 className="font-bold text-slate-900 text-base">৪. কোনো গোপন ক্রেডেনশিয়াল নয়</h3>
            <p>
              ব্যবহারকারীকে কঠোরভাবে নির্দেশ দেওয়া হচ্ছে যে তারা কখনোই তাদের বিকাশ/নগদ একাউন্টের গোপন পিন (PIN), ওটিপি (OTP) বা ইন্টারনেট ব্যাংকিং পাসওয়ার্ড কাউকে জানাবেন না।
            </p>
          </div>
        </div>
      )}

      {/* SECTION 2: PRIVACY POLICY */}
      {activeSection === 'privacy' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6 text-sm text-slate-700 leading-relaxed">
          <div className="border-b border-slate-100 pb-3">
            <h2 className="text-xl font-bold text-slate-900">গোপনীয়তা ও ডেটা সুরক্ষা নীতি (Privacy Policy)</h2>
            <p className="text-xs text-slate-400">ব্যক্তিগত তথ্যের সর্বোচ্চ সুরক্ষায় আমরা প্রতিশ্রুতিবদ্ধ</p>
          </div>

          <div className="space-y-4">
            <h3 className="font-bold text-slate-900 text-base">১. আমরা কী তথ্য সংগ্রহ করি</h3>
            <p>
              আবেদন দাখিলের সময় আমরা আবেদনকারীর নাম, যোগাযোগের মোবাইল নম্বর, ইমেইল (ঐচ্ছিক), ভুল লেনদেনের ট্রানজ্যাকশন আইডি, প্রাপক নম্বর ও বিবরণ সংগ্রহ করি।
            </p>

            <h3 className="font-bold text-slate-900 text-base">২. তথ্য মাস্কিং ও সার্বজনীন সুরক্ষা</h3>
            <p>
              যেকোনো পাবলিক বা শেয়ারযোগ্য ট্র্যাকিং ভিউতে উভয় পক্ষের মোবাইল নম্বর মাস্ক (উদা: 01831***877) করা থাকে। শুধুমাত্র আবেদনকারী নিজে ও অনুমোদিত অ্যাডমিন ভেরিফায়াররা নির্দিষ্ট তদন্তের জন্য পূর্ণ তথ্য দেখতে পান।
            </p>

            <h3 className="font-bold text-slate-900 text-base">৩. তথ্য মুছে ফেলা বা সংশোধনের অধিকার (Data Deletion)</h3>
            <p>
              ব্যবহারকারী যে কোনো সময় তাদের ব্যক্তিগত তথ্য মুছে ফেলার বা সংশোধনের অনুরোধ পাঠাতে পারেন। প্রযোজ্য সরকারি রেকর্ড রাখার আইনি বাধ্যবাধকতা ছাড়া আমরা কোনো অপ্রয়োজনীয় তথ্য স্থায়ীভাবে সংরক্ষণ করি না। তথ্য মুছতে আমাদের সাথে সরাসরি যোগাযোগ করুন।
            </p>
          </div>
        </div>
      )}

      {/* SECTION 3: REFUND & SERVICE FEE POLICY */}
      {activeSection === 'refund' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6 text-sm text-slate-700 leading-relaxed">
          <div className="border-b border-slate-100 pb-3">
            <h2 className="text-xl font-bold text-slate-900">সার্ভিস ফি ও রিফান্ড নীতি (Service Fee & Refund Policy)</h2>
            <p className="text-xs text-slate-400">১০৯ টাকা সার্ভিস ফি সংক্রান্ত পূর্ণাঙ্গ ব্যাখ্যা</p>
          </div>

          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-950 font-medium">
            “১০৯ টাকা নির্ধারিত আবেদন-প্রক্রিয়াকরণ সেবার ফি। এটি টাকা ফেরত পাওয়ার নিশ্চয়তা নয়। পেমেন্টের আগে সেবার শর্তাবলি ও রিফান্ড নীতি পড়ুন।”
          </div>

          <div className="space-y-4">
            <h3 className="font-bold text-slate-900 text-base">১০৯ টাকা ফি কী কী সেবার অন্তর্ভুক্ত:</h3>
            <ul className="list-disc list-inside space-y-1.5 pl-1">
              <li>আবেদনকারীর প্রদত্ত ট্রানজ্যাকশন ও স্টেটমেন্ট যাচাইকরণ।</li>
              <li>সংশ্লিষ্ট প্রোভাইডারের নীতি অনুযায়ী স্ট্যান্ডার্ড অভিযোগ ড্রাফট তৈরি।</li>
              <li>থানা জিডি (GD) খসড়া ও আইনি পরামর্শ নির্দেশনা প্রদান।</li>
              <li>সার্বক্ষণিক অনলাইন ট্র্যাকিং ও প্রোভাইডার টিকেট নম্বর সংযোজন।</li>
            </ul>

            <h3 className="font-bold text-slate-900 text-base">১০৯ টাকা ফি কখন রিফান্ডযোগ্য:</h3>
            <p>
              যদি কোনো গ্রাহক ভুলবশত একই রেফারেন্সে দুইবার ১০৯ টাকা ফি পরিশোধ করে ফেলেন (ডুপ্লিকেট পেমেন্ট), অথবা আবেদন পর্যালোচনার আগেই কারিগরি ত্রুটির কারণে আমাদের সিস্টেম অভিযোগ প্রসেস করতে ব্যর্থ হয়, তবে গ্রাহকের দাবির ভিত্তিতে ৭ কার্যদিবসের মধ্যে অতিরিক্ত ফি রিফান্ড করা হবে। সেবা ড্রাফটিং শুরু হওয়ার পর সার্ভিস ফি অপরিবর্তনযোগ্য।
            </p>
          </div>
        </div>
      )}

      {/* SECTION 4: SAFETY GUIDELINES */}
      {activeSection === 'safety' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6 text-sm text-slate-700 leading-relaxed">
          <div className="border-b border-slate-100 pb-3">
            <h2 className="text-xl font-bold text-slate-900">নিরাপত্তা ও প্রতারণা প্রতিরোধ নির্দেশিকা</h2>
            <p className="text-xs text-slate-400">সাইবার অপরাধ থেকে নিজেকে সুরক্ষিত রাখুন</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 space-y-1.5">
              <h4 className="font-bold text-base flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-rose-600" />
                যা কখনো করবেন না:
              </h4>
              <ul className="list-disc list-inside space-y-1 text-xs">
                <li>বিকাশ/নগদ পিন (PIN) কাউকে বলবেন না।</li>
                <li>ফোনে আসা কোনো ওটিপি (OTP) কোড শেয়ার করবেন না।</li>
                <li>কখনো ‘ক্যাশ আউট’ (Cash Out) করবেন না।</li>
                <li>অপরিচিত লিংকে একাউন্ট পাসওয়ার্ড দেবেন না।</li>
              </ul>
            </div>

            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 space-y-1.5">
              <h4 className="font-bold text-base flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                যা সবসময় করবেন:
              </h4>
              <ul className="list-disc list-inside space-y-1 text-xs">
                <li>লেনদেনের পরপরই ট্রানজ্যাকশন আইডি ও এসএমএস সংরক্ষণ করুন।</li>
                <li>শুধুমাত্র অফিশিয়াল হেল্পলাইনে (১৬২৪৭ বা ১৬১৬৭) কল করুন।</li>
                <li>প্রাপকের সাথে শান্ত ভাষায় কথা বলুন।</li>
                <li>প্রয়োজনে নিকটস্থ থানায় জিডি করুন।</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 5: CONTACT & COMPLAINT BOX */}
      {activeSection === 'contact' && (
        <div className="max-w-2xl bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6">
          <div className="border-b border-slate-100 pb-3">
            <h2 className="text-xl font-bold text-slate-900">যোগাযোগ ও ফিডব্যাক বক্স</h2>
            <p className="text-xs text-slate-500">আপনার মতামত বা সহায়তার জন্য আমাদের লিখুন।</p>
          </div>

          {complaintSubmitted ? (
            <div className="p-6 rounded-2xl bg-emerald-50 border border-emerald-200 text-center space-y-2">
              <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
              <h3 className="font-bold text-slate-900">আপনার বার্তা সফলভাবে গৃহীত হয়েছে!</h3>
              <p className="text-xs text-slate-600">আমাদের সাপোর্ট টিম দ্রুত আপনার সাথে যোগাযোগ করবে।</p>
            </div>
          ) : (
            <form onSubmit={handleComplaintSubmit} className="space-y-4 text-xs sm:text-sm">
              <div>
                <label className="block font-bold text-slate-700 mb-1">আপনার নাম</label>
                <input
                  type="text"
                  placeholder="আপনার নাম লিখুন"
                  value={complaintForm.name}
                  onChange={(e) => setComplaintForm({ ...complaintForm, name: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-slate-800 focus:outline-hidden"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">মোবাইল নম্বর</label>
                <input
                  type="tel"
                  placeholder="01XXXXXXXXX"
                  value={complaintForm.phone}
                  onChange={(e) => setComplaintForm({ ...complaintForm, phone: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-mono text-slate-800 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">বার্তা বা অভিযোগ</label>
                <textarea
                  rows={4}
                  placeholder="আপনার জিজ্ঞাসা বা অভিযোগের বিস্তারিত লিখুন..."
                  value={complaintForm.message}
                  onChange={(e) => setComplaintForm({ ...complaintForm, message: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-slate-800 focus:outline-hidden"
                  required
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm transition-colors cursor-pointer"
              >
                বার্তা পাঠান
              </button>
            </form>
          )}
        </div>
      )}
    </div>
  );
};
