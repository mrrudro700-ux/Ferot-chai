import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  RotateCcw,
  Lock,
  Mail,
  User,
  Phone,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

interface Props {
  setActiveTab: (tab: string) => void;
}

export const AuthPage: React.FC<Props> = ({ setActiveTab }) => {
  const { login, register, resetPassword, switchDemoRole, currentUser } = useAuth();

  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>('login');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setIsLoading(true);

    if (mode === 'login') {
      if (!email.trim() || !password.trim()) {
        setErrorMsg('ইমেইল ও পাসওয়ার্ড প্রদান করুন');
        setIsLoading(false);
        return;
      }
      const res = await login(email, password);
      setIsLoading(false);
      if (res.success) {
        setActiveTab('dashboard');
      } else {
        setErrorMsg(res.error || 'লগইন ব্যর্থ হয়েছে');
      }
    } else if (mode === 'register') {
      if (!fullName.trim() || !email.trim() || !phone.trim() || !password.trim()) {
        setErrorMsg('সকল প্রয়োজনীয় ঘর পূরণ করুন');
        setIsLoading(false);
        return;
      }
      if (password.length < 6) {
        setErrorMsg('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে');
        setIsLoading(false);
        return;
      }
      const res = await register(fullName, email, phone, password);
      setIsLoading(false);
      if (res.success) {
        setActiveTab('dashboard');
      } else {
        setErrorMsg(res.error || 'রেজিস্ট্রেশন ব্যর্থ হয়েছে');
      }
    } else {
      // Forgot password
      if (!email.trim()) {
        setErrorMsg('আপনার ইমেইল ঠিকানা প্রদান করুন');
        setIsLoading(false);
        return;
      }
      const res = await resetPassword(email);
      setIsLoading(false);
      setSuccessMsg(res.message);
    }
  };

  const handleQuickDemoApplicant = () => {
    switchDemoRole('applicant');
    setActiveTab('dashboard');
  };

  const handleQuickDemoAdmin = () => {
    switchDemoRole('admin');
    setActiveTab('admin');
  };

  return (
    <div className="max-w-md mx-auto px-4 py-12 space-y-6">
      {/* Brand Icon */}
      <div className="text-center space-y-2">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center mx-auto shadow-md">
          <RotateCcw className="w-6 h-6 stroke-[2.5]" />
        </div>
        <h1 className="text-2xl font-black text-slate-900">
          {mode === 'login'
            ? 'ফেরত চাই অ্যাকাউন্টে লগইন'
            : mode === 'register'
            ? 'নতুন অ্যাকাউন্ট রেজিস্ট্রেশন'
            : 'পাসওয়ার্ড পুনরুদ্ধার'}
        </h1>
        <p className="text-xs text-slate-500">
          আপনার আবেদনসমূহ সুরক্ষিতভাবে পরিচালনা করুন
        </p>
      </div>

      {/* Main Card */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-md p-6 sm:p-8 space-y-5">
        {/* Quick Demo Login Bar for Evaluators */}
        <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-2">
          <p className="font-bold text-slate-700 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            দ্রুত ডেমো লগইন (এক ক্লিকে পরীক্ষা করুন):
          </p>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={handleQuickDemoApplicant}
              className="px-2.5 py-1.5 bg-white border border-slate-300 rounded-xl text-slate-800 font-semibold hover:bg-slate-100 text-[11px] truncate shadow-2xs"
            >
              👤 আবেদনকারী (তানভীর)
            </button>
            <button
              type="button"
              onClick={handleQuickDemoAdmin}
              className="px-2.5 py-1.5 bg-emerald-600 rounded-xl text-white font-bold hover:bg-emerald-700 text-[11px] truncate shadow-2xs"
            >
              🛡️ এডমিন (মডারেটর রুদ্র)
            </button>
          </div>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            {errorMsg}
          </div>
        )}

        {successMsg && (
          <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-medium flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            {successMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
          {mode === 'register' && (
            <div>
              <label className="block font-bold text-slate-700 mb-1">পূর্ণ নাম</label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="আপনার নাম"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-slate-800 focus:outline-hidden"
                  required
                />
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>
          )}

          <div>
            <label className="block font-bold text-slate-700 mb-1">ইমেইল ঠিকানা</label>
            <div className="relative">
              <input
                type="email"
                placeholder="your.email@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-slate-800 focus:outline-hidden"
                required
              />
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          {mode === 'register' && (
            <div>
              <label className="block font-bold text-slate-700 mb-1">মোবাইল নম্বর</label>
              <div className="relative">
                <input
                  type="tel"
                  placeholder="01XXXXXXXXX"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 font-mono text-slate-800 focus:outline-hidden"
                  required
                />
                <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>
          )}

          {mode !== 'forgot' && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block font-bold text-slate-700">পাসওয়ার্ড</label>
                {mode === 'login' && (
                  <button
                    type="button"
                    onClick={() => { setMode('forgot'); setErrorMsg(''); setSuccessMsg(''); }}
                    className="text-[11px] text-emerald-700 hover:underline font-semibold"
                  >
                    পাসওয়ার্ড ভুলে গেছেন?
                  </button>
                )}
              </div>
              <div className="relative">
                <input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-slate-800 focus:outline-hidden"
                  required
                />
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
          >
            {isLoading ? (
              <RotateCcw className="w-4 h-4 animate-spin" />
            ) : mode === 'login' ? (
              'লগইন করুন'
            ) : mode === 'register' ? (
              'রেজিস্ট্রেশন সম্পন্ন করুন'
            ) : (
              'রিসেট লিংক পাঠান'
            )}
          </button>
        </form>

        {/* Toggle Mode */}
        <div className="pt-2 text-center text-xs text-slate-500 border-t border-slate-100">
          {mode === 'login' ? (
            <p>
              অ্যাকাউন্ট নেই?{' '}
              <button
                type="button"
                onClick={() => { setMode('register'); setErrorMsg(''); }}
                className="text-emerald-700 font-bold hover:underline"
              >
                নতুন অ্যাকাউন্ট তৈরি করুন
              </button>
            </p>
          ) : (
            <p>
              ইতিপূর্বে অ্যাকাউন্ট আছে?{' '}
              <button
                type="button"
                onClick={() => { setMode('login'); setErrorMsg(''); }}
                className="text-emerald-700 font-bold hover:underline"
              >
                লগইন করুন
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
