import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { StatusBadge } from '../components/StatusBadge';
import { ClaimStatus, Claim } from '../types';
import {
  Search,
  ShieldCheck,
  Clock,
  ArrowRight,
  AlertTriangle,
  CheckCircle2,
  Lock,
  Phone,
  FileText,
  RotateCcw,
  Send,
  Upload,
} from 'lucide-react';
import {
  formatBanglaDate,
  formatTaka,
  maskPhoneNumber,
} from '../services/storageAdapter';

interface Props {
  setActiveTab: (tab: string) => void;
  openPaymentForRef?: (ref: string) => void;
}

export const TrackPage: React.FC<Props> = ({ setActiveTab, openPaymentForRef }) => {
  const { getClaimByRef, provideAdditionalInfo } = useData();
  const { currentUser, isAdmin } = useAuth();

  const [refInput, setRefInput] = useState('');
  const [phoneVerificationInput, setPhoneVerificationInput] = useState('');
  const [matchedClaim, setMatchedClaim] = useState<Claim | null>(null);
  const [isSearched, setIsSearched] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Additional info state
  const [additionalText, setAdditionalText] = useState('');
  const [additionalInfoSuccess, setAdditionalInfoSuccess] = useState(false);

  const handleTrackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setIsSearched(true);
    setAdditionalInfoSuccess(false);

    if (!refInput.trim()) {
      setErrorMsg('আবেদন রেফারেন্স নম্বর প্রদান করুন');
      setMatchedClaim(null);
      return;
    }

    const claim = getClaimByRef(refInput.trim());
    if (!claim) {
      setErrorMsg('প্রদত্ত রেফারেন্স নম্বরের কোনো আবেদন খুঁজে পাওয়া যায়নি। নম্বরটি যাচাই করুন।');
      setMatchedClaim(null);
      return;
    }

    // Security Check: If not logged-in owner or admin, verify phone number to prevent unauthorized PII exposure
    const isOwner = currentUser && currentUser.uid === claim.ownerUid;
    if (!isOwner && !isAdmin) {
      if (!phoneVerificationInput.trim()) {
        setErrorMsg('নিরাপত্তার স্বার্থে আবেদনকারীর মোবাইল নম্বরের শেষ ৪টি ডিজিট অথবা পূর্ণ নম্বর প্রদান করুন।');
        setMatchedClaim(null);
        return;
      }
      const cleanInput = phoneVerificationInput.replace(/\s+/g, '');
      const cleanPhone = claim.applicantPhone.replace(/\s+/g, '');
      const isPhoneMatch =
        cleanPhone === cleanInput ||
        cleanPhone.endsWith(cleanInput) ||
        cleanInput.length >= 4 && cleanPhone.slice(-4) === cleanInput.slice(-4);

      if (!isPhoneMatch) {
        setErrorMsg('রেফারেন্স এবং মোবাইল নম্বরের তথ্য মেলেনি। সঠিক তথ্য দিয়ে চেষ্টা করুন।');
        setMatchedClaim(null);
        return;
      }
    }

    setMatchedClaim(claim);
  };

  const handleProvideMoreInfo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!matchedClaim || !additionalText.trim()) return;

    provideAdditionalInfo(matchedClaim.id, additionalText.trim());
    setAdditionalInfoSuccess(true);
    setAdditionalText('');
    // refresh matched claim
    const updated = getClaimByRef(matchedClaim.referenceNumber);
    if (updated) setMatchedClaim(updated);
  };

  const statusSteps: { status: ClaimStatus; label: string; desc: string }[] = [
    { status: 'Submitted', label: 'আবেদন দাখিল', desc: 'প্রাথমিক অভিযোগ নথিভুক্ত ও পেমেন্ট যাচাই প্রক্রিয়া' },
    { status: 'Under Review', label: 'পর্যালোচনা', desc: 'লেনদেন বিবরণী ও প্রমাণের সত্যতা নিশ্চিতকরণ' },
    { status: 'Referred to Provider', label: 'অপারেটরে অভিযোগ', desc: 'বিকাশ/নগদ কাস্টমার কেয়ারে অফিসিয়াল কেস প্রেরণ' },
    { status: 'Resolved', label: 'নিষ্পত্তি', desc: 'টাকা ফেরত নিশ্চিতকরণ অথবা চূড়ান্ত সিদ্ধান্ত' },
  ];

  const getStepState = (stepStatus: ClaimStatus, currentStatus: ClaimStatus) => {
    const order: ClaimStatus[] = ['Submitted', 'Under Review', 'Referred to Provider', 'Resolved'];
    const currentIndex = order.indexOf(currentStatus);
    const stepIndex = order.indexOf(stepStatus);

    if (currentStatus === 'Rejected') {
      return stepStatus === 'Submitted' ? 'completed' : 'rejected';
    }
    if (stepIndex < currentIndex) return 'completed';
    if (stepIndex === currentIndex) return 'current';
    return 'upcoming';
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 sm:py-12 space-y-8">
      {/* Title */}
      <div className="text-center">
        <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300">
          রিয়েল-টাইম ট্র্যাকিং
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">
          আবেদনের অবস্থা ও অগ্রগতি ট্র্যাক করুন
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-lg mx-auto">
          আপনার রেফারেন্স নম্বর দিয়ে অভিযোগের অগ্রগতি, প্রোভাইডারের মন্তব্য এবং পরবর্তী করণীয় দেখুন।
        </p>
      </div>

      {/* Search & Verification Box */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-md p-6 sm:p-8">
        <form onSubmit={handleTrackSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                আবেদন রেফারেন্স নম্বর (Application Reference) <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                placeholder="যেমন: FC-2026-89412"
                value={refInput}
                onChange={(e) => setRefInput(e.target.value.toUpperCase())}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-mono uppercase text-sm font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                নিরাপত্তা ভেরিফিকেশন (মোবাইল নম্বর বা শেষ ৪ ডিজিট)
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="01XXXXXXXXX অথবা শেষ ৪ ডিজিট"
                  value={phoneVerificationInput}
                  onChange={(e) => setPhoneVerificationInput(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-300 font-mono text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                />
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                ব্যক্তিগত তথ্যের সুরক্ষায় মোবাইল ভেরিফিকেশন আবশ্যক
              </p>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="w-full sm:w-auto px-7 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Search className="w-4 h-4" />
              অগ্রগতি ট্র্যাক করুন
            </button>
          </div>
        </form>

        {errorMsg && (
          <div className="mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            {errorMsg}
          </div>
        )}
      </div>

      {/* TRACKING DETAILS CARD */}
      {matchedClaim && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl p-6 sm:p-8 space-y-8 animate-in fade-in-50">
          
          {/* Header row */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  আবেদন রেফারেন্স
                </span>
                <span className="font-mono text-lg font-black text-slate-900 bg-slate-100 px-2.5 py-0.5 rounded-lg border border-slate-200">
                  {matchedClaim.referenceNumber}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                দাখিলের সময়: {formatBanglaDate(matchedClaim.createdAt)} • শেষ আপডেট: {formatBanglaDate(matchedClaim.updatedAt)}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <StatusBadge type="claim" status={matchedClaim.claimStatus} size="md" />
              <StatusBadge type="payment" status={matchedClaim.paymentStatus} size="md" />
            </div>
          </div>

          {/* Stepper Progress */}
          <div>
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">
              অগ্রগতি ট্র্যাকার
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              {statusSteps.map((step, idx) => {
                const state = getStepState(step.status, matchedClaim.claimStatus);
                return (
                  <div
                    key={step.status}
                    className={`p-3.5 rounded-2xl border transition-all ${
                      state === 'completed'
                        ? 'bg-emerald-50/60 border-emerald-300 text-emerald-950'
                        : state === 'current'
                        ? 'bg-blue-50/80 border-blue-400 text-blue-950 ring-2 ring-blue-500/20 shadow-xs'
                        : state === 'rejected'
                        ? 'bg-rose-50 border-rose-300 text-rose-950 opacity-60'
                        : 'bg-slate-50 border-slate-200 text-slate-500 opacity-60'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-bold">ধাপ {idx + 1}</span>
                      {state === 'completed' ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      ) : state === 'current' ? (
                        <Clock className="w-4 h-4 text-blue-600 animate-pulse" />
                      ) : null}
                    </div>
                    <h4 className="font-bold text-sm">{step.label}</h4>
                    <p className="text-[11px] mt-1 leading-snug">{step.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Current Status Explanation & Next Recommended Action (MANDATORY REQUIREMENT) */}
          <div className="space-y-4">
            <div className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                বর্তমান অবস্থা ও ব্যাখ্যা (Current Status)
              </h4>
              <p className="text-sm sm:text-base font-semibold text-slate-900 leading-relaxed">
                {matchedClaim.statusExplanation}
              </p>
            </div>

            <div className="p-4 sm:p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-1.5">
              <h4 className="text-xs font-bold text-emerald-800 uppercase tracking-wider flex items-center gap-1.5">
                <ArrowRight className="w-4 h-4 text-emerald-600" />
                পরবর্তী সুপারিশকৃত করণীয় (Next Recommended Action)
              </h4>
              <p className="text-sm font-medium text-emerald-950 leading-relaxed">
                {matchedClaim.nextRecommendedAction}
              </p>
            </div>
          </div>

          {/* Masked Transaction Details (Privacy Protection) */}
          <div className="bg-slate-50 rounded-2xl p-4 sm:p-5 border border-slate-200">
            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
              লেনদেনের তথ্য (সুরক্ষিত রূপ)
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <span className="text-slate-400">প্রোভাইডার:</span>
                <p className="font-bold text-slate-900 mt-0.5">{matchedClaim.serviceProvider}</p>
              </div>
              <div>
                <span className="text-slate-400">লেনদেনের ধরন:</span>
                <p className="font-bold text-slate-900 mt-0.5">{matchedClaim.transactionType}</p>
              </div>
              <div>
                <span className="text-slate-400">টাকার পরিমাণ:</span>
                <p className="font-bold text-emerald-700 font-mono text-sm mt-0.5">
                  {formatTaka(matchedClaim.amountSent)}
                </p>
              </div>
              <div>
                <span className="text-slate-400">TrxID:</span>
                <p className="font-mono font-bold text-slate-900 mt-0.5">
                  {matchedClaim.transactionId || 'তথ্য নেই'}
                </p>
              </div>
              <div>
                <span className="text-slate-400">প্রেরক নম্বর:</span>
                <p className="font-mono font-bold text-slate-700 mt-0.5">
                  {maskPhoneNumber(matchedClaim.senderPhone)}
                </p>
              </div>
              <div>
                <span className="text-slate-400">প্রাপক নম্বর:</span>
                <p className="font-mono font-bold text-rose-600 mt-0.5">
                  {maskPhoneNumber(matchedClaim.recipientPhone)}
                </p>
              </div>
              <div>
                <span className="text-slate-400">তারিখ:</span>
                <p className="text-slate-800 font-medium mt-0.5">
                  {matchedClaim.transactionDate} ({matchedClaim.transactionTime})
                </p>
              </div>
              {matchedClaim.providerComplaintRef && (
                <div>
                  <span className="text-slate-400">অফিসিয়াল কেস নং:</span>
                  <p className="font-mono font-bold text-indigo-700 mt-0.5">
                    {matchedClaim.providerComplaintRef}
                  </p>
                </div>
              )}
            </div>

            {matchedClaim.confirmedRefundEvidence && (
              <div className="mt-3 pt-3 border-t border-slate-200 text-xs bg-emerald-100/60 p-3 rounded-xl border border-emerald-300">
                <span className="font-bold text-emerald-900 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                  রিফান্ড নিশ্চিতকরণ প্রমাণ (Verified Evidence):
                </span>
                <p className="text-emerald-950 font-mono mt-1 font-semibold">
                  {matchedClaim.confirmedRefundEvidence}
                </p>
              </div>
            )}
          </div>

          {/* If Awaiting Payment -> Direct Pay Button */}
          {matchedClaim.paymentStatus === 'Awaiting Payment' && (
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-300 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-xs sm:text-sm text-amber-900 font-medium">
                এই আবেদনের জন্য নির্ধারিত <strong>৳১০৯</strong> নগদ সার্ভিস ফি এখনও পরিশোধ করা হয়নি।
              </div>
              <button
                type="button"
                onClick={() => {
                  if (openPaymentForRef) openPaymentForRef(matchedClaim.referenceNumber);
                  setActiveTab('pay-submit');
                }}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs sm:text-sm shadow-sm transition-all shrink-0"
              >
                ১০৯ টাকা পেমেন্ট জমা দিন
              </button>
            </div>
          )}

          {/* If More Information Required -> Action Form */}
          {matchedClaim.claimStatus === 'More Information Required' && (
            <div className="p-5 rounded-2xl bg-orange-50 border border-orange-300 space-y-3">
              <div className="flex items-center gap-2 text-orange-900 font-bold text-sm">
                <AlertTriangle className="w-4 h-4 text-orange-600" />
                অ্যাডমিন অতিরিক্ত তথ্য বা নথি চেয়েছেন:
              </div>
              <p className="text-xs text-orange-950 font-medium bg-white/70 p-3 rounded-xl border border-orange-200">
                {matchedClaim.moreInfoRequestedPrompt || 'অনুগ্রহ করে লেনদেনের স্পষ্ট প্রমাণপত্র ও সঠিক বিবরণ জমা দিন।'}
              </p>

              {additionalInfoSuccess ? (
                <div className="p-3 rounded-xl bg-emerald-100 text-emerald-900 text-xs font-bold">
                  ✓ আপনার অতিরিক্ত তথ্য সফলভাবে জমা দেওয়া হয়েছে। এডমিন তা পর্যবেক্ষণ করছে।
                </div>
              ) : (
                <form onSubmit={handleProvideMoreInfo} className="space-y-3 pt-2">
                  <textarea
                    rows={2}
                    placeholder="চাওয়া তথ্যের উত্তর বা প্রয়োজনীয় বিস্তারিত লিখুন..."
                    value={additionalText}
                    onChange={(e) => setAdditionalText(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-hidden bg-white text-slate-800"
                    required
                  ></textarea>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    তথ্য জমা দিন
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
