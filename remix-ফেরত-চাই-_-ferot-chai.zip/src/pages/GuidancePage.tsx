import React, { useState } from 'react';
import {
  PhoneCall,
  ExternalLink,
  ShieldCheck,
  FileText,
  AlertTriangle,
  Building,
  CheckCircle2,
  Copy,
  Check,
  Smartphone,
  Info,
} from 'lucide-react';

export const GuidancePage: React.FC = () => {
  const [copiedGd, setCopiedGd] = useState(false);

  const providerGuides = [
    {
      id: 'bkash',
      name: 'bKash (বিকাশ) হেল্পলাইন ও অফিসিয়াল নিয়ম',
      helpline: '16247',
      website: 'https://www.bkash.com',
      color: 'border-pink-500 bg-pink-50/40',
      badgeColor: 'bg-pink-100 text-pink-800',
      steps: [
        'ভুল লেনদেনের পরপরই বিকাশ হেল্পলাইন ১৬২৪৭-এ আপনার রেজিস্টার্ড সিম থেকে কল করুন।',
        'কল সেন্টারের প্রতিনিধিকে আপনার ট্রানজ্যাকশন আইডি (TrxID), প্রেরক ও ভুল প্রাপক নম্বর এবং টাকার পরিমাণ জানান।',
        'বিকাশ কাস্টমার কেয়ার প্রাপকের একাউন্টে একটি তদন্ত নোটিশ পাঠাবে।',
        'প্রাপক যদি টাকা ফেরত দিতে অস্বীকার করেন, তবে বিকাশ কাস্টমার কেয়ার থানা জিডি (GD) করার পরামর্শ দেবে।',
        'নিকটস্থ বিকাশ গ্রাহক সেবা কেন্দ্রে লিখিত অভিযোগ ও জিডি কপি জমা দিলে অফিসিয়াল প্রক্রিয়ায় রিভার্সাল বিবেচনা করা হয়।',
      ],
    },
    {
      id: 'nagad',
      name: 'Nagad (নগদ) হেল্পলাইন ও অফিসিয়াল নিয়ম',
      helpline: '16167',
      website: 'https://nagad.com.bd',
      color: 'border-amber-500 bg-amber-50/40',
      badgeColor: 'bg-amber-100 text-amber-800',
      steps: [
        'নগদ গ্রাহক সেবা ১৬১৬৭-এ তাৎক্ষণিক কল দিয়ে ভুল সেন্ট মানির বিষয়টি জানান।',
        'নগদ প্রতিনিধি আপনার লেনদেনের সত্যতা এবং ভুলের বিবরণ রেকর্ড করে কমপ্লেইন টিকিট ইস্যু করবেন।',
        'নগদ থেকে প্রাপক নম্বরে যোগাযোগ করে ভুল স্বীকার এবং রিফান্ড কনফার্ম করার অনুরোধ জানানো হয়।',
        'উভয় পক্ষের সম্মতি পেলে নগদ সাপোর্ট সেন্টারের মাধ্যমে টাকা অ্যাডজাস্টমেন্ট সম্পন্ন হয়।',
      ],
    },
    {
      id: 'rocket',
      name: 'Dutch-Bangla Rocket (রকেট) গাইড',
      helpline: '16216',
      website: 'https://www.dutchbanglabank.com/rocket',
      color: 'border-purple-500 bg-purple-50/40',
      badgeColor: 'bg-purple-100 text-purple-800',
      steps: [
        'রকেট হেল্পলাইন ১৬২১৬ বা ডাচ্-বাংলা ব্যাংকের যেকোনো শাখায় যোগাযোগ করুন।',
        'রকেটের ১২ ডিজিট অ্যাকাউন্ট নম্বরের শেষ চেক ডিজিট ভুলের ক্ষেত্রে দ্রুত অভিযোগ নথিভুক্ত করুন।',
        'শাখা ব্যবস্থাপক বা রকেট হেল্পডেস্ক আবেদনকারী ও প্রাপকের স্টেটমেন্ট পরীক্ষা করে নিষ্পত্তির ব্যবস্থা নেয়।',
      ],
    },
    {
      id: 'upay',
      name: 'Upay (উপায় - UCB Fintech) গাইড',
      helpline: '16419',
      website: 'https://www.upaybd.com',
      color: 'border-blue-500 bg-blue-50/40',
      badgeColor: 'bg-blue-100 text-blue-800',
      steps: [
        'উপায় হটলাইন ১৬৪১৯ নম্বরে ২৪/৭ সরাসরি কথা বলে লেনদেন তথ্য দিন।',
        'উপায়ের সাপোর্ট ইমেইলে (support@upaybd.com) ট্রানজ্যাকশন এসএমএসের স্ক্রিনশটসহ মেইল করুন।',
      ],
    },
    {
      id: 'recharge',
      name: 'মোবাইল রিচার্জ (গ্রামীনফোন, বাংলালিংক, রবি, টেলিটক)',
      helpline: '121',
      website: 'https://btrc.gov.bd',
      color: 'border-emerald-500 bg-emerald-50/40',
      badgeColor: 'bg-emerald-100 text-emerald-800',
      steps: [
        'যে সিমের মাধ্যমে রিচার্জ করেছেন সেই সিম থেকে ১২১ নম্বরে কল করুন।',
        'যদি ফ্ল্যাক্সিলোড দোকান থেকে ভুল করা হয়ে থাকে, দোকানদারের সাথে অবিলম্বে কথা বলুন। দোকানদারের স্পেশাল রিটেইলার রিভার্সাল সুবিধা থাকতে পারে যা সাধারণত ৩০ মিনিটের মধ্যে কার্যকর করা সম্ভব।',
        'বিটিআরসি (BTRC) হেল্পলাইন: ১০০ (অমীমাংসিত টেলিযোগাযোগ সংক্রান্ত অভিযোগের ক্ষেত্রে)।',
      ],
    },
  ];

  const gdSampleText = `বরাবর,
ভারপ্রাপ্ত কর্মকর্তা (OC)
[আপনার থানার নাম] থানা, [আপনার জেলা]

বিষয়: ভুল মোবাইল ফাইন্যান্সিয়াল সার্ভিস (MFS) লেনদেন সংক্রান্ত সাধারণ ডায়েরি (GD) করার আবেদন।

জনাব,
বিনীত নিবেদন এই যে, আমি নিম্ন স্বাক্ষরকারী [আপনার নাম], পিতা: [পিতার নাম], মোবাইল নম্বর: [আপনার নম্বর], ঠিকানা: [আপনার বর্তমান ঠিকানা]। 

গত [তারিখ] তারিখ আনুমানিক [সময়] ঘটিকায় আমার ব্যক্তিগত [বিকাশ/নগদ/রকেট] অ্যাকাউন্ট ([আপনার নম্বর]) থেকে পারিবারিক প্রয়োজনে টাকা পাঠানোর সময় ভুলবশত একটি ডিজিট পরিবর্তন হয়ে অপরিচিত নম্বর [ভুল প্রাপকের নম্বর]-এ সর্বমোট [টাকার পরিমাণ] টাকা চলে যায়। (লেনদেন রেফারেন্স / TrxID: [ট্রানজ্যাকশন আইডি])।

উক্ত ভুল লেনদেনের পর আমি প্রাপকের নম্বরে ভদ্রভাবে যোগাযোগের চেষ্টা করলে তিনি টাকা ফেরত দিতে অস্বীকৃতি জানান / ফোন রিসিভ করছেন না। এমতাবস্থায় [বিকাশ/নগদ] কাস্টমার কেয়ারে অভিযোগ করার জন্য বিষয়টি ভবিষ্যতের নিরাপত্তার স্বার্থে থানায় সাধারণ ডায়েরিভুক্ত (GD) করা আবশ্যক।

অতএব, মহোদয়ের নিকট বিনীত প্রার্থনা, উক্ত ঘটনাটি আপনার থানার সাধারণ ডায়েরিতে অন্তর্ভুক্ত করে আমাকে একটি অনুলিপি প্রদান করতে মর্জি হয়।

বিনীত,
[আপনার স্বাক্ষর]
নাম: [আপনার নাম]
মোবাইল: [আপনার মোবাইল নম্বর]
জাতীয় পরিচয়পত্র (NID): [আপনার এনআইডি নম্বর]`;

  const handleCopyGd = () => {
    navigator.clipboard.writeText(gdSampleText);
    setCopiedGd(true);
    setTimeout(() => setCopiedGd(false), 2500);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
      {/* Page Header */}
      <div className="text-center max-w-2xl mx-auto">
        <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300">
          প্রামাণ্য গাইডলাইন
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">
          অফিসিয়াল প্রোভাইডার নির্দেশিকা ও থানা জিডি খসড়া
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-1">
          ভুল লেনদেন নিষ্পত্তির জন্য সংশ্লিষ্ট প্রতিষ্ঠানের আনুষ্ঠানিক হেল্পলাইন এবং আইনি প্রক্রিয়ার সম্পূর্ণ রূপরেখা।
        </p>
      </div>

      {/* Strict Anti-Impersonation Notice */}
      <div className="p-4 rounded-2xl bg-amber-50 border border-amber-300 text-xs sm:text-sm text-amber-950 flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
        <div>
          <p className="font-bold">গুরুত্বপূর্ণ সতর্কতা ও আইনি বাধ্যবাধকতা:</p>
          <p className="mt-0.5 leading-relaxed">
            ফেরত চাই কোনো ব্যাংক বা এমএফএস প্রতিষ্ঠানের প্রতিনিধি নয়। আমরা গ্রাহকদের সঠিক তথ্য দিয়ে তাদের আবেদন প্রস্তুতকরণে সহায়তা করি। কোনো ব্যক্তি বা সংস্থাকে ভয় দেখানো, হুমকি দেওয়া বা প্রতারণামূলকভাবে একাউন্টে হস্তক্ষেপ করা আইনত দণ্ডনীয় অপরাধ।
          </p>
        </div>
      </div>

      {/* Provider Guides Accordion / Cards */}
      <div className="space-y-6">
        <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <Building className="w-5 h-5 text-emerald-600" />
          এমএফএস ও মোবাইল অপারেটর সহায়িকা
        </h2>

        <div className="grid grid-cols-1 gap-5">
          {providerGuides.map((guide) => (
            <div
              key={guide.id}
              className={`rounded-2xl border-2 p-5 sm:p-6 bg-white shadow-xs ${guide.color}`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200/80">
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900">
                    {guide.name}
                  </h3>
                </div>
                <div className="flex items-center gap-2">
                  <a
                    href={`tel:${guide.helpline}`}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-mono font-bold text-xs bg-slate-900 text-white hover:bg-slate-800 transition-colors"
                  >
                    <PhoneCall className="w-3.5 h-3.5 text-emerald-400" />
                    কল: {guide.helpline}
                  </a>
                  <a
                    href={guide.website}
                    target="_blank"
                    rel="noreferrer"
                    className="p-1.5 rounded-xl border border-slate-300 hover:bg-white text-slate-600"
                    title="অফিসিয়াল ওয়েবসাইট"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>

              <div className="mt-4 space-y-2 text-xs sm:text-sm text-slate-700">
                <p className="font-bold text-slate-800">অফিসিয়াল পদক্ষেপসমূহ:</p>
                <ol className="list-decimal list-inside space-y-1.5 leading-relaxed pl-1">
                  {guide.steps.map((st, i) => (
                    <li key={i}>{st}</li>
                  ))}
                </ol>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Police GD (General Diary) Template */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-md p-6 sm:p-8 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <span className="text-xs font-bold text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded-full border border-purple-200">
              আইনি খসড়া ফরম্যাট
            </span>
            <h3 className="text-lg font-bold text-slate-900 mt-1">
              ভুল লেনদেনের জন্য থানা সাধারণ ডায়েরি (GD) আবেদন ফরম
            </h3>
            <p className="text-xs text-slate-500">
              প্রাপক টাকা ফেরত দিতে অস্বীকার করলে বা যোগাযোগ বন্ধ করে দিলে থানায় এই ফরম্যাটে জিডি করতে পারেন।
            </p>
          </div>

          <button
            type="button"
            onClick={handleCopyGd}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              copiedGd
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-900 hover:bg-slate-800 text-white'
            }`}
          >
            {copiedGd ? (
              <>
                <Check className="w-4 h-4" />
                কপি সম্পন্ন!
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                জিডি ফরম কপি করুন
              </>
            )}
          </button>
        </div>

        {/* GD Preformatted text */}
        <div className="bg-slate-50 p-4 sm:p-5 rounded-2xl border border-slate-200 text-xs sm:text-sm font-sans text-slate-800 leading-relaxed whitespace-pre-line select-all">
          {gdSampleText}
        </div>

        <p className="text-[11px] text-slate-500">
          * বন্ধনীযুক্ত অংশগুলো (যেমন: [আপনার নাম], [তারিখ], ইত্যাদি) আপনার প্রকৃত তথ্য দিয়ে প্রতিস্থাপন করুন।
        </p>
      </div>
    </div>
  );
};
