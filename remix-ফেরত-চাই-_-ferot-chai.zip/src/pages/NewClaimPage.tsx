import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { Provider, TransactionType, EvidenceFile } from '../types';
import confetti from 'canvas-confetti';
import {
  RotateCcw,
  User,
  CreditCard,
  CheckCircle2,
  AlertCircle,
  Upload,
  ArrowRight,
  ArrowLeft,
  ShieldAlert,
  FileCheck,
  Smartphone,
  Calendar,
  Clock,
  ExternalLink,
  X,
} from 'lucide-react';
import { formatTaka } from '../services/storageAdapter';

interface Props {
  setActiveTab: (tab: string) => void;
  onClaimCreated?: (reference: string) => void;
}

export const NewClaimPage: React.FC<Props> = ({ setActiveTab, onClaimCreated }) => {
  const { currentUser } = useAuth();
  const { createClaim, settings } = useData();

  const [currentStep, setCurrentStep] = useState<1 | 2 | 3>(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [createdReference, setCreatedReference] = useState<string | null>(null);

  // Form State - Step 1: Applicant Info
  const [fullName, setFullName] = useState(currentUser?.fullName || '');
  const [contactNumber, setContactNumber] = useState(currentUser?.phone || '');
  const [emailAddress, setEmailAddress] = useState(currentUser?.email || '');
  const [preferredContact, setPreferredContact] = useState<'phone' | 'email' | 'whatsapp'>('phone');

  // Form State - Step 2: Transaction Info
  const [transactionType, setTransactionType] = useState<TransactionType>('Send Money');
  const [serviceProvider, setServiceProvider] = useState<Provider>('bKash');
  const [transactionId, setTransactionId] = useState('');
  const [transactionDate, setTransactionDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [transactionTime, setTransactionTime] = useState('14:00');
  const [amountSent, setAmountSent] = useState<string>('');
  const [senderPhone, setSenderPhone] = useState(currentUser?.phone || '');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [mistakeExplanation, setMistakeExplanation] = useState('');
  const [evidenceFiles, setEvidenceFiles] = useState<EvidenceFile[]>([]);
  const [uploadError, setUploadError] = useState('');

  // Form State - Step 3: Consent
  const [hasAgreedConsent, setHasAgreedConsent] = useState(false);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Validation
  const validateStep1 = () => {
    const errs: Record<string, string> = {};
    if (!fullName.trim()) errs.fullName = 'আপনার পূর্ণ নাম আবশ্যক';
    if (!contactNumber.trim()) {
      errs.contactNumber = 'যোগাযোগের মোবাইল নম্বর প্রদান করুন';
    } else if (!/^01[3-9]\d{8}$/.test(contactNumber.replace(/\s+/g, ''))) {
      errs.contactNumber = 'সঠিক ১১ ডিজিটের বাংলাদেশি মোবাইল নম্বর প্রদান করুন (উদা: 01831027877)';
    }
    setFormErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const validateStep2 = () => {
    const errs: Record<string, string> = {};
    const amt = parseFloat(amountSent);
    if (isNaN(amt) || amt <= 0) {
      errs.amountSent = 'সঠিক টাকার পরিমাণ উল্লেখ করুন';
    } else if (amt > 200000) {
      errs.amountSent = 'টাকার পরিমাণ সর্বোচ্চ ২,০০,০০০ টাকার মধ্যে হতে হবে';
    }

    if (!senderPhone.trim()) {
      errs.senderPhone = 'প্রেরকের (আপনার) মোবাইল নম্বর দিন';
    } else if (!/^01[3-9]\d{8}$/.test(senderPhone.replace(/\s+/g, ''))) {
      errs.senderPhone = 'সঠিক ১১ ডিজিট বাংলাদেশি নম্বর প্রদান করুন';
    }

    if (!recipientPhone.trim()) {
      errs.recipientPhone = 'প্রাপকের (যে নম্বরে ভুল করে গেছে) মোবাইল নম্বর দিন';
    } else if (!/^01[3-9]\d{8}$/.test(recipientPhone.replace(/\s+/g, ''))) {
      errs.recipientPhone = 'সঠিক ১১ ডিজিট বাংলাদেশি নম্বর প্রদান করুন';
    } else if (senderPhone.trim() === recipientPhone.trim()) {
      errs.recipientPhone = 'প্রেরক ও প্রাপক নম্বর একই হতে পারে না';
    }

    if (!mistakeExplanation.trim() || mistakeExplanation.trim().length < 15) {
      errs.mistakeExplanation = 'কীভাবে ভুলটি হয়েছে তার বিস্তারিত বিবরণ কমপক্ষে ১৫ অক্ষরে লিখুন';
    }

    setFormErrors(errs);
    return Object.keys(errs).length === 0;
  };

  // Mock file uploader with security validation
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUploadError('');
    if (!e.target.files || e.target.files.length === 0) return;

    const file = e.target.files[0];
    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setUploadError('ফাইলের সাইজ সর্বোচ্চ ৫ মেগাবাইট (5 MB) হতে পারবে');
      return;
    }
    // Check file type
    if (!file.type.startsWith('image/') && file.type !== 'application/pdf') {
      setUploadError('শুধুমাত্র ছবি (JPG, PNG) অথবা PDF ফাইল আপলোড করা যাবে');
      return;
    }

    // Create safe data url preview
    const reader = new FileReader();
    reader.onload = () => {
      const newFile: EvidenceFile = {
        name: file.name,
        url: reader.result as string,
        size: file.size,
        type: file.type,
        uploadedAt: new Date().toISOString(),
      };
      setEvidenceFiles((prev) => [...prev, newFile]);
    };
    reader.readAsDataURL(file);
  };

  const removeFile = (index: number) => {
    setEvidenceFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleFinalSubmit = async () => {
    if (!hasAgreedConsent) {
      setFormErrors({ consent: 'আবেদন দাখিলের জন্য শর্তাবলি ও তথ্যের সত্যতা নিশ্চিতকরণ আবশ্যক' });
      return;
    }

    setIsSubmitting(true);
    try {
      const claim = await createClaim({
        ownerUid: currentUser?.uid || `guest_${Date.now()}`,
        applicantName: fullName.trim(),
        applicantPhone: contactNumber.trim(),
        applicantEmail: emailAddress.trim() || undefined,
        preferredContact,
        transactionType,
        serviceProvider,
        transactionId: transactionId.trim().toUpperCase() || undefined,
        transactionDate,
        transactionTime,
        amountSent: parseFloat(amountSent),
        senderPhone: senderPhone.trim(),
        recipientPhone: recipientPhone.trim(),
        mistakeExplanation: mistakeExplanation.trim(),
        evidenceFiles,
      });

      setCreatedReference(claim.referenceNumber);
      if (onClaimCreated) {
        onClaimCreated(claim.referenceNumber);
      }

      // Trigger celebration confetti
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {
        // fallback
      }
    } catch (e) {
      setFormErrors({ submit: 'আবেদন জমা দিতে সমস্যা হয়েছে। আবার চেষ্টা করুন।' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // SUCCESS VIEW AFTER SUBMISSION
  if (createdReference) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-12">
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl p-6 sm:p-10 text-center space-y-6">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
              অভিযোগ দাখিল সফল
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              আপনার অভিযোগ সফলভাবে নথিভুক্ত হয়েছে
            </h2>
            <p className="text-sm text-slate-600 max-w-lg mx-auto">
              নিচের রেফারেন্স নম্বরটি সংরক্ষণ করুন। এই নম্বর এবং আপনার মোবাইল নম্বর দিয়ে যে কোনো সময় আবেদনের অগ্রগতি ট্র্যাক করতে পারবেন।
            </p>
          </div>

          {/* Reference Badge Card */}
          <div className="bg-emerald-50/70 border-2 border-dashed border-emerald-300 rounded-2xl p-5 max-w-md mx-auto">
            <p className="text-xs font-medium text-emerald-800">আপনার অনন্য আবেদন রেফারেন্স নম্বর:</p>
            <p className="text-3xl sm:text-4xl font-mono font-black text-emerald-950 tracking-wider mt-1 select-all">
              {createdReference}
            </p>
            <p className="text-[11px] text-emerald-700 mt-2">
              স্ট্যাটাস: <strong className="text-amber-700">পেমেন্ট অপেক্ষমাণ (Awaiting ৳109)</strong>
            </p>
          </div>

          {/* Service Fee Notice */}
          <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-left text-xs sm:text-sm text-amber-900 leading-relaxed max-w-lg mx-auto">
            <p className="font-bold flex items-center gap-1.5 mb-1">
              <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
              পরবর্তী গুরুত্বপূর্ণ ধাপ (Next Step):
            </p>
            <p>
              আবেদনটি প্রসেসিং শুরু করতে নির্ধারিত <strong>৳১০৯</strong> নগদ সেন্ড মানি করুন। নিচে বাটন চেপে এখনই ট্রানজ্যাকশন আইডি সাবমিট করতে পারেন।
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => setActiveTab('pay-submit')}
              className="w-full sm:w-auto px-7 py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2"
            >
              ১০৯ টাকা পেমেন্ট তথ্য জমা দিন
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('dashboard')}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm transition-all"
            >
              ড্যাশবোর্ডে দেখুন
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-8 sm:py-12">
      {/* Header */}
      <div className="text-center mb-8">
        <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
          ৩টি সহজ ধাপে আবেদন
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">
          ভুল লেনদেনের অভিযোগ সহায়তা ফরম
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          সঠিক তথ্য প্রদান করুন যাতে প্রোভাইডারের কাছে প্রাতিষ্ঠানিক অভিযোগ তৈরি করা যায়।
        </p>
      </div>

      {/* Stepper Wizard Indicator */}
      <div className="mb-8">
        <div className="flex items-center justify-between relative">
          <div className="absolute top-1/2 left-0 right-0 h-1 bg-slate-200 -translate-y-1/2 z-0"></div>
          <div
            className="absolute top-1/2 left-0 h-1 bg-emerald-500 -translate-y-1/2 z-0 transition-all duration-300"
            style={{ width: currentStep === 1 ? '15%' : currentStep === 2 ? '50%' : '100%' }}
          ></div>

          {/* Step 1 Pill */}
          <div className="relative z-10 flex flex-col items-center">
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shadow-sm transition-all ${
                currentStep >= 1
                  ? 'bg-emerald-600 text-white'
                  : 'bg-white text-slate-400 border border-slate-300'
              }`}
            >
              ১
            </div>
            <span className="text-xs font-bold text-slate-700 mt-1.5 hidden sm:block">আবেদনকারী</span>
          </div>

          {/* Step 2 Pill */}
          <div className="relative z-10 flex flex-col items-center">
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shadow-sm transition-all ${
                currentStep >= 2
                  ? 'bg-emerald-600 text-white'
                  : 'bg-white text-slate-400 border border-slate-300'
              }`}
            >
              ২
            </div>
            <span className="text-xs font-bold text-slate-700 mt-1.5 hidden sm:block">লেনদেন ও প্রমাণ</span>
          </div>

          {/* Step 3 Pill */}
          <div className="relative z-10 flex flex-col items-center">
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shadow-sm transition-all ${
                currentStep === 3
                  ? 'bg-emerald-600 text-white'
                  : 'bg-white text-slate-400 border border-slate-300'
              }`}
            >
              ৩
            </div>
            <span className="text-xs font-bold text-slate-700 mt-1.5 hidden sm:block">যাচাই ও দাখিল</span>
          </div>
        </div>
      </div>

      {/* Main Form Box */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-md p-6 sm:p-8">
        
        {/* STEP 1: APPLICANT INFORMATION */}
        {currentStep === 1 && (
          <div className="space-y-5 animate-in fade-in-50">
            <div className="border-b border-slate-100 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <User className="w-5 h-5 text-emerald-600" />
                ধাপ ১: আবেদনকারীর তথ্য (Applicant Info)
              </h2>
              <p className="text-xs text-slate-500">আপনার সাথে যোগাযোগের তথ্য সঠিকভাবে প্রদান করুন।</p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                পূর্ণ নাম (Full Name) <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                placeholder="আপনার নাম (যেমন: তানভীর আহমেদ)"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className={`w-full px-4 py-2.5 rounded-xl border text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 ${
                  formErrors.fullName ? 'border-rose-400 bg-rose-50/30' : 'border-slate-300'
                }`}
              />
              {formErrors.fullName && <p className="text-xs text-rose-500 mt-1">{formErrors.fullName}</p>}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                যোগাযোগের মোবাইল নম্বর (Contact Number) <span className="text-rose-500">*</span>
              </label>
              <input
                type="tel"
                placeholder="01XXXXXXXXX (যেমন: 01831027877)"
                value={contactNumber}
                onChange={(e) => setContactNumber(e.target.value)}
                className={`w-full px-4 py-2.5 rounded-xl border text-sm text-slate-800 font-mono focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 ${
                  formErrors.contactNumber ? 'border-rose-400 bg-rose-50/30' : 'border-slate-300'
                }`}
              />
              {formErrors.contactNumber && <p className="text-xs text-rose-500 mt-1">{formErrors.contactNumber}</p>}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ইমেইল ঠিকানা (ঐচ্ছিক / Optional Email)
              </label>
              <input
                type="email"
                placeholder="your.email@example.com"
                value={emailAddress}
                onChange={(e) => setEmailAddress(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-2">
                যোগাযোগের পছন্দের মাধ্যম (Preferred Contact Method)
              </label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: 'phone', label: 'ফোন কল' },
                  { id: 'whatsapp', label: 'WhatsApp' },
                  { id: 'email', label: 'ইমেইল' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setPreferredContact(item.id as any)}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all ${
                      preferredContact === item.id
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-800'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Next Button */}
            <div className="pt-4 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  if (validateStep1()) setCurrentStep(2);
                }}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md transition-all cursor-pointer"
              >
                পরবর্তী ধাপ (লেনদেনের তথ্য)
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: TRANSACTION INFORMATION */}
        {currentStep === 2 && (
          <div className="space-y-5 animate-in fade-in-50">
            <div className="border-b border-slate-100 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-emerald-600" />
                ধাপ ২: লেনদেনের তথ্য ও প্রমাণপত্র (Transaction Details)
              </h2>
              <p className="text-xs text-slate-500">ভুল লেনদেনের সুনির্দিষ্ট তথ্য সঠিকভাবে উল্লেখ করুন।</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  সার্ভিস প্রোভাইডার (Provider) <span className="text-rose-500">*</span>
                </label>
                <select
                  value={serviceProvider}
                  onChange={(e) => setServiceProvider(e.target.value as Provider)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-800 bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                >
                  <option value="bKash">bKash (বিকাশ)</option>
                  <option value="Nagad">Nagad (নগদ)</option>
                  <option value="Rocket">Rocket (রকেট)</option>
                  <option value="Upay">Upay (উপায়)</option>
                  <option value="Mobile Recharge">Mobile Recharge (মোবাইল রিচার্জ)</option>
                  <option value="Other">অন্যান্য (Other)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  লেনদেনের ধরন (Transaction Type) <span className="text-rose-500">*</span>
                </label>
                <select
                  value={transactionType}
                  onChange={(e) => setTransactionType(e.target.value as TransactionType)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-800 bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                >
                  <option value="Send Money">Send Money (সেন্ড মানি)</option>
                  <option value="ভুল রিচার্জ">ভুল রিচার্জ (Mobile Recharge)</option>
                  <option value="Cash Out">Cash Out (ক্যাশ আউট)</option>
                  <option value="Other">অন্যান্য (Other)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  টাকার পরিমাণ (Amount in BDT) <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400">৳</span>
                  <input
                    type="number"
                    placeholder="যেমন: ৩,৫০০"
                    value={amountSent}
                    onChange={(e) => setAmountSent(e.target.value)}
                    className={`w-full pl-8 pr-4 py-2.5 rounded-xl border text-sm text-slate-800 font-mono font-bold focus:outline-hidden ${
                      formErrors.amountSent ? 'border-rose-400 bg-rose-50/30' : 'border-slate-300'
                    }`}
                  />
                </div>
                {formErrors.amountSent && <p className="text-xs text-rose-500 mt-1">{formErrors.amountSent}</p>}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ট্রানজ্যাকশন আইডি (Transaction ID - যদি থাকে)
                </label>
                <input
                  type="text"
                  placeholder="যেমন: BL9A2X4490"
                  value={transactionId}
                  onChange={(e) => setTransactionId(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-800 font-mono uppercase focus:outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  লেনদেনের তারিখ (Date) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  value={transactionDate}
                  onChange={(e) => setTransactionDate(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-800 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  আনুমানিক সময় (Approx. Time)
                </label>
                <input
                  type="time"
                  value={transactionTime}
                  onChange={(e) => setTransactionTime(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-800 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  প্রেরকের মোবাইল নম্বর (আপনার নম্বর) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="tel"
                  placeholder="01XXXXXXXXX"
                  value={senderPhone}
                  onChange={(e) => setSenderPhone(e.target.value)}
                  className={`w-full px-4 py-2.5 rounded-xl border text-sm text-slate-800 font-mono focus:outline-hidden ${
                    formErrors.senderPhone ? 'border-rose-400 bg-rose-50/30' : 'border-slate-300'
                  }`}
                />
                {formErrors.senderPhone && <p className="text-xs text-rose-500 mt-1">{formErrors.senderPhone}</p>}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  প্রাপকের মোবাইল নম্বর (যে নম্বরে ভুল করে গেছে) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="tel"
                  placeholder="01XXXXXXXXX"
                  value={recipientPhone}
                  onChange={(e) => setRecipientPhone(e.target.value)}
                  className={`w-full px-4 py-2.5 rounded-xl border text-sm text-slate-800 font-mono focus:outline-hidden ${
                    formErrors.recipientPhone ? 'border-rose-400 bg-rose-50/30' : 'border-slate-300'
                  }`}
                />
                {formErrors.recipientPhone && <p className="text-xs text-rose-500 mt-1">{formErrors.recipientPhone}</p>}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ভুলের বিস্তারিত বিবরণ (Explanation of Mistake) <span className="text-rose-500">*</span>
              </label>
              <textarea
                rows={3}
                placeholder="কীভাবে ভুলটি ঘটল (যেমন: একটি ডিজিট টাইপ করতে ভুল হয়েছিল বা নম্বর সেভ করার ক্ষেত্রে ভুল ছিল) এবং প্রাপকের সাথে যোগাযোগের চেষ্টা করেছেন কি না লিখুন..."
                value={mistakeExplanation}
                onChange={(e) => setMistakeExplanation(e.target.value)}
                className={`w-full px-4 py-2.5 rounded-xl border text-sm text-slate-800 focus:outline-hidden ${
                  formErrors.mistakeExplanation ? 'border-rose-400 bg-rose-50/30' : 'border-slate-300'
                }`}
              ></textarea>
              {formErrors.mistakeExplanation && <p className="text-xs text-rose-500 mt-1">{formErrors.mistakeExplanation}</p>}
            </div>

            {/* Evidence File Upload (Optional) */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                লেনদেনের প্রমাণপত্র বা এসএমএস স্ক্রিনশট (ঐচ্ছিক / Evidence Upload)
              </label>
              <div className="border-2 border-dashed border-slate-300 rounded-2xl p-4 text-center hover:bg-slate-50 transition-colors">
                <input
                  type="file"
                  id="evidence-upload"
                  accept="image/png,image/jpeg,image/webp,application/pdf"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <label htmlFor="evidence-upload" className="cursor-pointer block">
                  <Upload className="w-6 h-6 text-slate-400 mx-auto mb-1" />
                  <p className="text-xs font-semibold text-slate-700">
                    ছবি বা PDF ফাইল নির্বাচন করুন
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    সর্বোচ্চ ৫ মেগাবাইট (JPG, PNG, PDF)
                  </p>
                </label>
              </div>

              {uploadError && <p className="text-xs text-rose-500 mt-1">{uploadError}</p>}

              {/* Uploaded Files List */}
              {evidenceFiles.length > 0 && (
                <div className="mt-3 space-y-2">
                  {evidenceFiles.map((f, i) => (
                    <div key={i} className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                      <div className="flex items-center gap-2 truncate">
                        <FileCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span className="font-medium text-slate-800 truncate">{f.name}</span>
                        <span className="text-slate-400 text-[10px]">({Math.round(f.size / 1024)} KB)</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeFile(i)}
                        className="text-rose-500 hover:text-rose-700 p-1"
                        title="ফাইল মুছে ফেলুন"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Stepper Navigation */}
            <div className="pt-4 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setCurrentStep(1)}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-slate-600 hover:text-slate-900 font-bold text-sm"
              >
                <ArrowLeft className="w-4 h-4" />
                পূর্ববর্তী ধাপ
              </button>

              <button
                type="button"
                onClick={() => {
                  if (validateStep2()) setCurrentStep(3);
                }}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md transition-all cursor-pointer"
              >
                পরবর্তী ধাপ (যাচাই ও রিভিউ)
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: REVIEW & SUBMIT */}
        {currentStep === 3 && (
          <div className="space-y-6 animate-in fade-in-50">
            <div className="border-b border-slate-100 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                ধাপ ৩: তথ্য যাচাই ও চূড়ান্ত দাখিল (Review & Submit)
              </h2>
              <p className="text-xs text-slate-500">
                দাখিল করার পূর্বে আপনার দেওয়া তথ্যগুলো ভালো করে মিলিয়ে নিন। প্রয়োজনে সংশোধন করুন।
              </p>
            </div>

            {/* Summary Cards */}
            <div className="space-y-4">
              {/* Applicant Card */}
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">আবেদনকারীর তথ্য</h4>
                  <button
                    type="button"
                    onClick={() => setCurrentStep(1)}
                    className="text-xs font-bold text-emerald-700 hover:underline"
                  >
                    সংশোধন
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-slate-500">নাম:</span> <strong className="text-slate-900">{fullName}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500">মোবাইল:</span> <strong className="font-mono text-slate-900">{contactNumber}</strong>
                  </div>
                  {emailAddress && (
                    <div>
                      <span className="text-slate-500">ইমেইল:</span> <span className="text-slate-800">{emailAddress}</span>
                    </div>
                  )}
                  <div>
                    <span className="text-slate-500">পছন্দের মাধ্যম:</span> <span className="capitalize font-semibold text-slate-800">{preferredContact}</span>
                  </div>
                </div>
              </div>

              {/* Transaction Card */}
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">ভুল লেনদেনের তথ্য</h4>
                  <button
                    type="button"
                    onClick={() => setCurrentStep(2)}
                    className="text-xs font-bold text-emerald-700 hover:underline"
                  >
                    সংশোধন
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-slate-500">সার্ভিস প্রোভাইডার:</span> <strong className="text-slate-900">{serviceProvider}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500">লেনদেনের ধরন:</span> <strong className="text-slate-900">{transactionType}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500">ভুল টাকার পরিমাণ:</span> <strong className="text-emerald-700 text-sm font-bold font-mono">{formatTaka(parseFloat(amountSent) || 0)}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500">TrxID:</span> <span className="font-mono font-bold text-slate-900">{transactionId || 'প্রযোজ্য নয়'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">প্রেরক নম্বর:</span> <span className="font-mono text-slate-900">{senderPhone}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">প্রাপক নম্বর:</span> <span className="font-mono text-slate-900 text-rose-600 font-bold">{recipientPhone}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">তারিখ ও সময়:</span> <span className="text-slate-800">{transactionDate} ({transactionTime})</span>
                  </div>
                  <div>
                    <span className="text-slate-500">প্রমাণপত্র সংযুক্ত:</span> <span className="text-slate-800">{evidenceFiles.length} টি ফাইল</span>
                  </div>
                </div>
                <div className="mt-3 pt-2 border-t border-slate-200 text-xs">
                  <span className="text-slate-500">বিবরণ:</span> <p className="text-slate-700 italic mt-0.5">{mistakeExplanation}</p>
                </div>
              </div>

              {/* Service Fee Reminder */}
              <div className="bg-emerald-50 rounded-2xl p-4 border border-emerald-200 text-xs text-emerald-900">
                <div className="flex items-center justify-between">
                  <span className="font-bold">আবেদন প্রক্রিয়াকরণ সার্ভিস ফি:</span>
                  <span className="text-base font-extrabold font-mono text-emerald-800">৳১০৯ টাকা</span>
                </div>
                <p className="mt-1 text-[11px] text-emerald-700">
                  আবেদন সফলভাবে সাবমিট হলে আপনি একটি রেফারেন্স নম্বর পাবেন এবং নগদ সেন্ড মানির মাধ্যমে ১০৯ টাকা সার্ভিস ফি পরিশোধ করতে পারবেন।
                </p>
              </div>
            </div>

            {/* Consent & Accuracy Checkbox */}
            <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasAgreedConsent}
                  onChange={(e) => setHasAgreedConsent(e.target.checked)}
                  className="mt-1 rounded text-emerald-600 focus:ring-emerald-500 h-4 w-4"
                />
                <span className="text-xs text-slate-800 leading-relaxed font-medium">
                  আমি নিশ্চিত করছি যে উপরে প্রদত্ত যাবতীয় তথ্য সত্য ও নির্ভুল। আমি জেনে-বুঝে সম্মতি দিচ্ছি যে ফেরত চাই একটি স্বাধীন অভিযোগ-সহায়তা প্ল্যাটফর্ম এবং ১০৯ টাকা প্রসেসিং ফি লেনদেন নিশ্চিতভাবে ফেরতের গ্যারান্টি দেয় না।
                </span>
              </label>
              {formErrors.consent && <p className="text-xs text-rose-600 font-bold mt-2 ml-7">{formErrors.consent}</p>}
            </div>

            {/* Stepper Navigation & Submit */}
            <div className="pt-4 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setCurrentStep(2)}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-slate-600 hover:text-slate-900 font-bold text-sm"
              >
                <ArrowLeft className="w-4 h-4" />
                পূর্ববর্তী ধাপ
              </button>

              <button
                type="button"
                disabled={isSubmitting}
                onClick={handleFinalSubmit}
                className="inline-flex items-center gap-2 px-8 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-400 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <RotateCcw className="w-4 h-4 animate-spin" />
                    দাখিল হচ্ছে...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-5 h-5" />
                    অভিযোগ চূড়ান্ত দাখিল করুন
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
