import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { StatusBadge } from '../components/StatusBadge';
import { Claim, ClaimStatus, PaymentStatus, PaymentSubmission } from '../types';
import {
  Shield,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RotateCcw,
  CreditCard,
  Settings,
  FileSpreadsheet,
  Download,
  Eye,
  Check,
  Send,
  Lock,
  Building2,
  Calendar,
  DollarSign,
  User,
  X,
  FileText,
} from 'lucide-react';
import {
  formatBanglaDate,
  formatTaka,
  maskPhoneNumber,
} from '../services/storageAdapter';

interface Props {
  setActiveTab: (tab: string) => void;
}

export const AdminPage: React.FC<Props> = ({ setActiveTab }) => {
  const { currentUser, isAdmin } = useAuth();
  const {
    claims,
    payments,
    settings,
    auditLogs,
    updateClaimStatus,
    verifyPaymentSubmission,
    requestAdditionalInfo,
    recordProviderComplaintRef,
    recordRefundEvidence,
    updateAppSettings,
  } = useData();

  const [activeSubTab, setActiveSubTab] = useState<'claims' | 'payments' | 'settings' | 'audit'>('claims');

  // Search & Filter state for claims
  const [searchTerm, setSearchTerm] = useState('');
  const [filterProvider, setFilterProvider] = useState('all');
  const [filterClaimStatus, setFilterClaimStatus] = useState('all');
  const [filterPaymentStatus, setFilterPaymentStatus] = useState('all');

  // Claim modal
  const [inspectClaim, setInspectClaim] = useState<Claim | null>(null);
  const [newClaimStatus, setNewClaimStatus] = useState<ClaimStatus>('Under Review');
  const [statusExplanation, setStatusExplanation] = useState('');
  const [nextAction, setNextAction] = useState('');
  const [adminNotes, setAdminNotes] = useState('');
  const [providerTicketInput, setProviderTicketInput] = useState('');
  const [refundEvidenceInput, setRefundEvidenceInput] = useState('');
  const [moreInfoPrompt, setMoreInfoPrompt] = useState('');

  // Payment review modal
  const [inspectPayment, setInspectPayment] = useState<PaymentSubmission | null>(null);
  const [paymentReviewerNotes, setPaymentReviewerNotes] = useState('');

  // Settings state
  const [settingsReceivingNumber, setSettingsReceivingNumber] = useState(settings.receivingNumber);
  const [settingsFee, setSettingsFee] = useState(settings.serviceFee);
  const [settingsNotice, setSettingsNotice] = useState(settings.serviceNotice);
  const [settingsSaved, setSettingsSaved] = useState(false);

  // Access Control check
  if (!isAdmin) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
          <Lock className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900">অননুমোদিত প্রবেশাধিকার (Restricted)</h2>
        <p className="text-sm text-slate-600">
          এই বিভাগটি শুধুমাত্র প্ল্যাটফর্ম অ্যাডমিনিস্ট্রেটরদের জন্য সংরক্ষিত। অনুগ্রহ করে অনুমোদিত অ্যাডমিন অ্যাকাউন্টে লগইন করুন।
        </p>
        <button
          type="button"
          onClick={() => setActiveTab('home')}
          className="px-6 py-2.5 rounded-xl bg-slate-900 text-white font-bold text-xs"
        >
          হোমে ফিরে যান
        </button>
      </div>
    );
  }

  // Filtered Claims
  const filteredClaims = claims.filter((c) => {
    const term = searchTerm.trim().toUpperCase();
    const matchTerm =
      !term ||
      c.referenceNumber.toUpperCase().includes(term) ||
      c.applicantName.toUpperCase().includes(term) ||
      c.senderPhone.includes(term) ||
      (c.transactionId && c.transactionId.toUpperCase().includes(term));

    const matchProvider = filterProvider === 'all' || c.serviceProvider === filterProvider;
    const matchClaimStatus = filterClaimStatus === 'all' || c.claimStatus === filterClaimStatus;
    const matchPaymentStatus = filterPaymentStatus === 'all' || c.paymentStatus === filterPaymentStatus;

    return matchTerm && matchProvider && matchClaimStatus && matchPaymentStatus;
  });

  const handleOpenClaimInspect = (c: Claim) => {
    setInspectClaim(c);
    setNewClaimStatus(c.claimStatus);
    setStatusExplanation(c.statusExplanation);
    setNextAction(c.nextRecommendedAction);
    setAdminNotes(c.adminInternalNotes || '');
    setProviderTicketInput(c.providerComplaintRef || '');
    setRefundEvidenceInput(c.confirmedRefundEvidence || '');
    setMoreInfoPrompt('');
  };

  const handleSaveClaimChanges = () => {
    if (!inspectClaim) return;
    updateClaimStatus(inspectClaim.id, newClaimStatus, statusExplanation, nextAction, adminNotes);
    if (providerTicketInput.trim() && providerTicketInput !== inspectClaim.providerComplaintRef) {
      recordProviderComplaintRef(inspectClaim.id, providerTicketInput.trim());
    }
    if (refundEvidenceInput.trim() && refundEvidenceInput !== inspectClaim.confirmedRefundEvidence) {
      recordRefundEvidence(inspectClaim.id, refundEvidenceInput.trim());
    }
    setInspectClaim(null);
  };

  const handleSendMoreInfoRequest = () => {
    if (!inspectClaim || !moreInfoPrompt.trim()) return;
    requestAdditionalInfo(inspectClaim.id, moreInfoPrompt.trim());
    setInspectClaim(null);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateAppSettings({
      receivingNumber: settingsReceivingNumber.trim(),
      serviceFee: Number(settingsFee),
      serviceNotice: settingsNotice.trim(),
    });
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 2500);
  };

  // CSV Export
  const handleExportCSV = () => {
    const headers = [
      'Reference',
      'Date',
      'Provider',
      'Type',
      'AmountBDT',
      'ClaimStatus',
      'PaymentStatus',
      'ProviderComplaintRef',
      'ConfirmedRefund',
    ];

    const rows = claims.map((c) => [
      c.referenceNumber,
      c.transactionDate,
      c.serviceProvider,
      c.transactionType,
      c.amountSent,
      c.claimStatus,
      c.paymentStatus,
      c.providerComplaintRef || '',
      c.confirmedRefundEvidence ? 'Yes' : 'No',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `ferot_chai_claims_audit_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      {/* Admin Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-xs uppercase font-bold text-emerald-400 tracking-wider">
              এডমিন নিরাপত্তা কনসোল (Reviewer: {currentUser?.email})
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black mt-1">
            ফেরত চাই কেন্দ্রীয় ম্যানেজমেন্ট প্যানেল
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            আবেদন যাচাই, ম্যানুয়াল পেমেন্ট নিরীক্ষা, প্রোভাইডার টিকেট নথিভুক্তকরণ ও অডিট ট্রেইল।
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handleExportCSV}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition-colors shadow-xs"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            অডিট রিপোর্ট (CSV)
          </button>
        </div>
      </div>

      {/* Sub Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-3 overflow-x-auto text-xs sm:text-sm font-bold">
        <button
          type="button"
          onClick={() => setActiveSubTab('claims')}
          className={`px-4 py-2 rounded-xl transition-all whitespace-nowrap ${
            activeSubTab === 'claims'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          অভিযোগ ব্যবস্থাপনা ({claims.length})
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('payments')}
          className={`px-4 py-2 rounded-xl transition-all whitespace-nowrap flex items-center gap-1.5 ${
            activeSubTab === 'payments'
              ? 'bg-amber-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          পেমেন্ট ভেরিফিকেশন ({payments.filter((p) => p.status === 'Payment Submitted' || p.status === 'Under Verification').length} নতুন)
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('settings')}
          className={`px-4 py-2 rounded-xl transition-all whitespace-nowrap flex items-center gap-1.5 ${
            activeSubTab === 'settings'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Settings className="w-4 h-4" />
          পেমেন্ট ও সার্ভিস সেটিংস
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('audit')}
          className={`px-4 py-2 rounded-xl transition-all whitespace-nowrap flex items-center gap-1.5 ${
            activeSubTab === 'audit'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Shield className="w-4 h-4" />
          সিকিউরিটি অডিট লগ ({auditLogs.length})
        </button>
      </div>

      {/* SUBTAB 1: CLAIMS MANAGEMENT */}
      {activeSubTab === 'claims' && (
        <div className="space-y-6">
          {/* Filter Bar */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">রেফারেন্স বা ফোন দিয়ে খুঁজুন</label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="রেফারেন্স, নাম বা নম্বর..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-300 text-slate-800 focus:outline-hidden"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">প্রোভাইডার</label>
              <select
                value={filterProvider}
                onChange={(e) => setFilterProvider(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-800 focus:outline-hidden"
              >
                <option value="all">সকল প্রোভাইডার</option>
                <option value="bKash">bKash (বিকাশ)</option>
                <option value="Nagad">Nagad (নগদ)</option>
                <option value="Rocket">Rocket (রকেট)</option>
                <option value="Upay">Upay (উপায়)</option>
                <option value="Mobile Recharge">Mobile Recharge</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">ক্লেম স্ট্যাটাস</label>
              <select
                value={filterClaimStatus}
                onChange={(e) => setFilterClaimStatus(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-800 focus:outline-hidden"
              >
                <option value="all">সকল অবস্থা</option>
                <option value="Submitted">Submitted (দাখিল)</option>
                <option value="Under Review">Under Review (পর্যালোচনা)</option>
                <option value="More Information Required">More Information Required</option>
                <option value="Referred to Provider">Referred to Provider</option>
                <option value="Resolved">Resolved (নিষ্পত্তি)</option>
                <option value="Rejected">Rejected (বাতিল)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">পেমেন্ট স্ট্যাটাস</label>
              <select
                value={filterPaymentStatus}
                onChange={(e) => setFilterPaymentStatus(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-800 focus:outline-hidden"
              >
                <option value="all">সকল পেমেন্ট অবস্থা</option>
                <option value="Awaiting Payment">Awaiting Payment</option>
                <option value="Payment Submitted">Payment Submitted</option>
                <option value="Verified">Verified (সফল)</option>
                <option value="Rejected">Rejected</option>
              </select>
            </div>
          </div>

          {/* Claims Table */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                  <tr>
                    <th className="px-5 py-3">রেফারেন্স নং</th>
                    <th className="px-5 py-3">আবেদনকারী</th>
                    <th className="px-5 py-3">প্রোভাইডার ও ধরন</th>
                    <th className="px-5 py-3">টাকার অঙ্ক</th>
                    <th className="px-5 py-3">ক্লেম অবস্থা</th>
                    <th className="px-5 py-3">পেমেন্ট</th>
                    <th className="px-5 py-3 text-right">একশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredClaims.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-5 py-10 text-center text-slate-400">
                        কোনো আবেদন মেলেনি
                      </td>
                    </tr>
                  ) : (
                    filteredClaims.map((claim) => (
                      <tr key={claim.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="px-5 py-3.5 font-mono font-bold text-slate-900">
                          {claim.referenceNumber}
                        </td>
                        <td className="px-5 py-3.5">
                          <p className="font-bold text-slate-900">{claim.applicantName}</p>
                          <p className="font-mono text-[11px] text-slate-500">{claim.applicantPhone}</p>
                        </td>
                        <td className="px-5 py-3.5">
                          <span className="font-semibold text-slate-800">{claim.serviceProvider}</span>
                          <span className="block text-[11px] text-slate-500">{claim.transactionType}</span>
                        </td>
                        <td className="px-5 py-3.5 font-mono font-bold text-emerald-700">
                          {formatTaka(claim.amountSent)}
                        </td>
                        <td className="px-5 py-3.5">
                          <StatusBadge type="claim" status={claim.claimStatus} size="sm" />
                        </td>
                        <td className="px-5 py-3.5">
                          <StatusBadge type="payment" status={claim.paymentStatus} size="sm" />
                        </td>
                        <td className="px-5 py-3.5 text-right">
                          <button
                            type="button"
                            onClick={() => handleOpenClaimInspect(claim)}
                            className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-xs"
                          >
                            রিভিউ / আপডেট
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: PAYMENT VERIFICATION */}
      {activeSubTab === 'payments' && (
        <div className="space-y-6">
          <div className="bg-amber-50 rounded-2xl border border-amber-300 p-4 text-xs text-amber-900 flex items-start gap-3">
            <CreditCard className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">ম্যানুয়াল পেমেন্ট নিরীক্ষা নির্দেশিকা:</p>
              <p>
                প্রাপক নম্বর ({settings.receivingNumber}) এর নগদ স্টেটমেন্টে প্রাপ্ত Transaction ID এবং টাকার অঙ্ক (নির্ধারিত ১০৯ টাকা) মিলিয়ে নিশ্চিত হওয়ার পরই কেবল ‘Verified’ নির্বাচন করুন। কোনো অনুমানের ভিত্তিতে পেমেন্ট অ্যাপ্রুভ করবেন না।
              </p>
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                  <tr>
                    <th className="px-5 py-3">আবেদন রেফারেন্স</th>
                    <th className="px-5 py-3">নগদ TrxID</th>
                    <th className="px-5 py-3">টাকার অঙ্ক</th>
                    <th className="px-5 py-3">জমার সময়</th>
                    <th className="px-5 py-3">বর্তমান অবস্থা</th>
                    <th className="px-5 py-3">নিরীক্ষক</th>
                    <th className="px-5 py-3 text-right">পদক্ষেপ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {payments.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-5 py-10 text-center text-slate-400">
                        কোনো পেমেন্ট সাবমিশন নেই
                      </td>
                    </tr>
                  ) : (
                    payments.map((p) => {
                      const isFeeMismatch = p.reportedAmount !== settings.serviceFee;
                      return (
                        <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                          <td className="px-5 py-3.5 font-mono font-bold text-slate-900">
                            {p.claimReference}
                          </td>
                          <td className="px-5 py-3.5 font-mono font-black text-amber-800 text-sm">
                            {p.reportedTransactionId}
                          </td>
                          <td className="px-5 py-3.5">
                            <span className="font-mono font-bold text-slate-900">{formatTaka(p.reportedAmount)}</span>
                            {isFeeMismatch && (
                              <span className="block text-[10px] text-rose-600 font-bold">
                                ⚠️ ফি গরমিল (প্রত্যাশিত: ৳১০৯)
                              </span>
                            )}
                          </td>
                          <td className="px-5 py-3.5 text-slate-500">
                            {formatBanglaDate(p.submittedAt)}
                          </td>
                          <td className="px-5 py-3.5">
                            <StatusBadge type="payment" status={p.status} size="sm" />
                          </td>
                          <td className="px-5 py-3.5 text-slate-500">
                            {p.reviewerName || '—'}
                          </td>
                          <td className="px-5 py-3.5 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {p.status !== 'Verified' && (
                                <button
                                  type="button"
                                  onClick={() => verifyPaymentSubmission(p.id, 'Verified', 'নগদ স্টেটমেন্ট চেক করে ১০৯ টাকা প্রাপ্তি নিশ্চিত করা হয়েছে।')}
                                  className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs"
                                >
                                  অনুমোদন (Verify)
                                </button>
                              )}
                              {p.status !== 'Rejected' && (
                                <button
                                  type="button"
                                  onClick={() => verifyPaymentSubmission(p.id, 'Rejected', 'ভুল ট্রানজ্যাকশন আইডি অথবা টাকা একাউন্টে জমা হয়নি।')}
                                  className="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs border border-rose-200"
                                >
                                  বাতিল
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 3: SETTINGS EDITOR */}
      {activeSubTab === 'settings' && (
        <div className="max-w-2xl bg-white rounded-3xl border border-slate-200 shadow-md p-6 sm:p-8 space-y-6">
          <div className="border-b border-slate-100 pb-3">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Settings className="w-5 h-5 text-emerald-600" />
              প্ল্যাটফর্ম সেটিংস ও পেমেন্ট কনফিগারেশন
            </h2>
            <p className="text-xs text-slate-500">
              নগদ প্রাপক নম্বর ও নির্ধারিত সার্ভিস ফি আপডেট করুন।
            </p>
          </div>

          {settingsSaved && (
            <div className="p-3 rounded-xl bg-emerald-100 text-emerald-900 text-xs font-bold flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600" />
              সেটিংস সফলভাবে সংরক্ষিত হয়েছে এবং অডিট লগে নথিভুক্ত করা হয়েছে!
            </div>
          )}

          <form onSubmit={handleSaveSettings} className="space-y-4 text-xs sm:text-sm">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                নগদ প্রাপক নম্বর (Send Money Destination Number) <span className="text-rose-500">*</span>
              </label>
              <input
                type="tel"
                value={settingsReceivingNumber}
                onChange={(e) => setSettingsReceivingNumber(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-mono text-base font-black text-slate-900 focus:outline-hidden"
                required
              />
              <p className="text-[11px] text-slate-400 mt-0.5">
                শুধুমাত্র মালিকানা ও ব্যবসায়িক যাচাই সম্পন্ন নম্বর ব্যবহার করুন (ডিফল্ট: 01831027877)।
              </p>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                সার্ভিস ফি (Service Fee in BDT) <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400">৳</span>
                <input
                  type="number"
                  value={settingsFee}
                  onChange={(e) => setSettingsFee(Number(e.target.value))}
                  className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-300 font-mono font-bold text-slate-900 focus:outline-hidden"
                  required
                />
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                প্ল্যাটফর্ম প্রমিত ফি ১০৯ টাকা।
              </p>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                পেমেন্ট পেজ সাধারণ নোটিশ (Broadcast Announcement)
              </label>
              <textarea
                rows={2}
                value={settingsNotice}
                onChange={(e) => setSettingsNotice(e.target.value)}
                className="w-full px-4 py-2 rounded-xl border border-slate-300 text-slate-800 focus:outline-hidden"
              ></textarea>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer"
              >
                সেটিংস সংরক্ষণ করুন
              </button>
            </div>
          </form>
        </div>
      )}

      {/* SUBTAB 4: AUDIT LOGS */}
      {activeSubTab === 'audit' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden space-y-4 p-5 sm:p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                নিরাপত্তা অডিট ট্রেইল (Immutable Security Audit Logs)
              </h2>
              <p className="text-xs text-slate-500">
                সকল সংবেদনশীল ও প্রশাসনিক পদক্ষেপের অপরিবর্তনযোগ্য লগ রেকর্ড।
              </p>
            </div>
          </div>

          <div className="divide-y divide-slate-100 font-mono text-xs">
            {auditLogs.map((log) => (
              <div key={log.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                      {log.action}
                    </span>
                    <span className="text-[11px] text-slate-500">by {log.actorEmail}</span>
                  </div>
                  <p className="text-slate-700 mt-1">{log.details}</p>
                </div>
                <div className="text-[11px] text-slate-400 shrink-0">
                  {formatBanglaDate(log.timestamp)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* INSPECT & UPDATE CLAIM MODAL */}
      {inspectClaim && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 shadow-2xl relative space-y-6">
            <button
              type="button"
              onClick={() => setInspectClaim(null)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-slate-900 hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-400 uppercase">অ্যাডমিন রিভিউ</span>
                <span className="font-mono font-black text-slate-900 text-base bg-slate-100 px-2 py-0.5 rounded">
                  {inspectClaim.referenceNumber}
                </span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mt-1">
                {inspectClaim.serviceProvider} - ৳{inspectClaim.amountSent} ({inspectClaim.transactionType})
              </h3>
            </div>

            {/* Applicant & Details Table */}
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-xs grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <span className="text-slate-400">আবেদনকারীর নাম:</span>
                <p className="font-bold text-slate-900">{inspectClaim.applicantName}</p>
              </div>
              <div>
                <span className="text-slate-400">যোগাযোগের নম্বর:</span>
                <p className="font-mono font-bold text-slate-900">{inspectClaim.applicantPhone}</p>
              </div>
              <div>
                <span className="text-slate-400">প্রেরক নম্বর:</span>
                <p className="font-mono text-slate-800">{inspectClaim.senderPhone}</p>
              </div>
              <div>
                <span className="text-slate-400">ভুল প্রাপক নম্বর:</span>
                <p className="font-mono font-bold text-rose-600">{inspectClaim.recipientPhone}</p>
              </div>
              <div>
                <span className="text-slate-400">লেনদেনের তারিখ:</span>
                <p className="text-slate-800">{inspectClaim.transactionDate} ({inspectClaim.transactionTime})</p>
              </div>
              <div>
                <span className="text-slate-400">TrxID:</span>
                <p className="font-mono font-bold text-slate-900">{inspectClaim.transactionId || 'নেই'}</p>
              </div>
            </div>

            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-xs">
              <span className="text-slate-400 font-bold">ভুলের কারণ ও বিবরণ:</span>
              <p className="text-slate-800 mt-1 leading-relaxed">{inspectClaim.mistakeExplanation}</p>
            </div>

            {/* Status Update Form */}
            <div className="space-y-4 pt-2 border-t border-slate-200">
              <h4 className="font-bold text-slate-900 text-sm">স্ট্যাটাস ও অগ্রগতি আপডেট</h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">ক্লেম স্ট্যাটাস নির্বাচন করুন</label>
                  <select
                    value={newClaimStatus}
                    onChange={(e) => setNewClaimStatus(e.target.value as ClaimStatus)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900 font-bold"
                  >
                    <option value="Submitted">Submitted (আবেদন দাখিল)</option>
                    <option value="Under Review">Under Review (পর্যালোচনা চলছে)</option>
                    <option value="More Information Required">More Information Required (অতিরিক্ত তথ্য প্রয়োজন)</option>
                    <option value="Referred to Provider">Referred to Provider (অপারেটরে প্রেরিত)</option>
                    <option value="Resolved">Resolved (নিষ্পত্তি হয়েছে)</option>
                    <option value="Rejected">Rejected (বাতিল করা হয়েছে)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    অফিসিয়াল প্রোভাইডার অভিযোগ রেফারেন্স নং (টিকেট #)
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: BK-2026-9041 বা NG-12345"
                    value={providerTicketInput}
                    onChange={(e) => setProviderTicketInput(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-slate-900 uppercase font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1 text-xs">
                  ব্যবহারকারীর জন্য বাংলা ব্যাখ্যা (Status Explanation)
                </label>
                <textarea
                  rows={2}
                  value={statusExplanation}
                  onChange={(e) => setStatusExplanation(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-800"
                ></textarea>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1 text-xs">
                  পরবর্তী করণীয় নির্দেশনা (Next Recommended Action)
                </label>
                <input
                  type="text"
                  value={nextAction}
                  onChange={(e) => setNextAction(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-800"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1 text-xs">
                  রিফান্ড নিশ্চিতকরণ প্রমাণ (Resolved হলে বাধ্যতামূলক / Confirmed Refund Evidence)
                </label>
                <input
                  type="text"
                  placeholder="যেমন: নগদ রিফান্ড ট্রানজ্যাকশন আইডি: NG-REF-88412 (টাকা ফেরত নিশ্চিত)"
                  value={refundEvidenceInput}
                  onChange={(e) => setRefundEvidenceInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono text-slate-800"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1 text-xs">
                  অভ্যন্তরীণ অ্যাডমিন নোট (Internal Reviewer Notes - শুধুমাত্র এডমিনের জন্য)
                </label>
                <input
                  type="text"
                  placeholder="অভ্যন্তরীণ পর্যালোচনা মন্তব্য..."
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-800"
                />
              </div>

              {/* Request More Information Trigger */}
              <div className="p-3 rounded-xl bg-orange-50 border border-orange-200 text-xs space-y-2">
                <p className="font-bold text-orange-900">ব্যবহারকারীর কাছে অতিরিক্ত তথ্য চাইতে চান?</p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="কী তথ্য বা প্রমাণ লাগবে লিখুন..."
                    value={moreInfoPrompt}
                    onChange={(e) => setMoreInfoPrompt(e.target.value)}
                    className="flex-1 px-3 py-1.5 rounded-lg border border-orange-300 bg-white text-xs"
                  />
                  <button
                    type="button"
                    onClick={handleSendMoreInfoRequest}
                    className="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 text-white rounded-lg font-bold text-xs shrink-0"
                  >
                    রিকোয়েস্ট পাঠান
                  </button>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setInspectClaim(null)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs"
                >
                  বাতিল
                </button>
                <button
                  type="button"
                  onClick={handleSaveClaimChanges}
                  className="px-6 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md"
                >
                  আপডেট সংরক্ষণ করুন
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
