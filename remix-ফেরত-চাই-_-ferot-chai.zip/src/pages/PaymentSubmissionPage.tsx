import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { NagadPaymentCard } from '../components/NagadPaymentCard';
import {
  CreditCard,
  CheckCircle2,
  AlertTriangle,
  Upload,
  RotateCcw,
  Clock,
  ShieldCheck,
  ArrowRight,
  FileText,
  Info,
} from 'lucide-react';
import { formatTaka } from '../services/storageAdapter';

interface Props {
  initialReference?: string;
  setActiveTab: (tab: string) => void;
}

export const PaymentSubmissionPage: React.FC<Props> = ({ initialReference = '', setActiveTab }) => {
  const { settings, submitPaymentProof, getClaimByRef } = useData();
  const { currentUser } = useAuth();

  const [claimReference, setClaimReference] = useState(initialReference);
  const [transactionId, setTransactionId] = useState('');
  const [paymentAmount, setPaymentAmount] = useState<number>(settings.serviceFee);
  const [paymentDateTime, setPaymentDateTime] = useState(() => new Date().toISOString().slice(0, 16));
  const [screenshotUrl, setScreenshotUrl] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successSubmitted, setSuccessSubmitted] = useState(false);

  useEffect(() => {
    if (initialReference) {
      setClaimReference(initialReference);
    }
  }, [initialReference]);

  const handleScreenshotUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    if (file.size > 5 * 1024 * 1024) {
      setErrorMsg('স্ক্রিনশটের সাইজ সর্বোচ্চ ৫ মেগাবাইট (5 MB) হতে পারবে');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setScreenshotUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!claimReference.trim()) {
      setErrorMsg('আবেদন রেফারেন্স নম্বর প্রদান করুন');
      return;
    }

    if (!transactionId.trim()) {
      setErrorMsg('নগদের Transaction ID প্রদান করুন (উদা: 9G7K2L89X1)');
      return;
    }

    if (transactionId.trim().length < 6) {
      setErrorMsg('সঠিক ও পূর্ণাঙ্গ ট্রানজ্যাকশন আইডি প্রদান করুন');
      return;
    }

    setIsSubmitting(true);
    const result = await submitPaymentProof(
      claimReference.trim(),
      transactionId.trim(),
      paymentAmount,
      paymentDateTime,
      screenshotUrl || undefined
    );
    setIsSubmitting(false);

    if (result.success) {
      setSuccessSubmitted(true);
    } else {
      setErrorMsg(result.error || 'পেমেন্ট তথ্য সাবমিট করতে ব্যর্থ হয়েছে');
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 sm:py-12 space-y-8">
      {/* Page Title */}
      <div className="text-center">
        <span className="text-xs font-bold text-amber-800 bg-amber-100 px-3 py-1 rounded-full border border-amber-300">
          ম্যানুয়াল পেমেন্ট ভেরিফিকেশন
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">
          নগদ সেন্ড মানি পেমেন্ট সাবমিশন ফরম
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-1">
          সার্ভিস ফি ১০৯ টাকা প্রদান করে নিচের ফর্মে আপনার ট্রানজ্যাকশন আইডি জমা দিন।
        </p>
      </div>

      {/* Official Nagad Instruction Card with Copy Button */}
      <NagadPaymentCard claimReference={claimReference} />

      {/* Success View */}
      {successSubmitted ? (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl p-6 sm:p-10 text-center space-y-5 animate-in fade-in-50">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <h2 className="text-2xl font-black text-slate-900">
            পেমেন্টের তথ্য সফলভাবে জমা হয়েছে
          </h2>

          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-950 font-medium text-sm max-w-lg mx-auto">
            “আপনার পেমেন্টের তথ্য জমা হয়েছে। যাচাই সম্পন্ন হলে পেমেন্টের অবস্থা আপডেট করা হবে।”
          </div>

          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 max-w-md mx-auto text-xs text-left space-y-1.5 font-mono">
            <div>
              <span className="text-slate-500">রেফারেন্স নম্বর:</span>{' '}
              <strong className="text-slate-900">{claimReference}</strong>
            </div>
            <div>
              <span className="text-slate-500">নগদ TrxID:</span>{' '}
              <strong className="text-emerald-700">{transactionId.toUpperCase()}</strong>
            </div>
            <div>
              <span className="text-slate-500">জমার পরিমাণ:</span>{' '}
              <strong className="text-slate-900">{formatTaka(paymentAmount)}</strong>
            </div>
            <div>
              <span className="text-slate-500">স্ট্যাটাস:</span>{' '}
              <span className="text-amber-700 font-bold">পেমেন্ট জমা হয়েছে (Under Verification)</span>
            </div>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => setActiveTab('track')}
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm transition-all"
            >
              আবেদন ট্র্যাক করুন
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('dashboard')}
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold text-xs sm:text-sm transition-all"
            >
              ড্যাশবোর্ডে ফিরুন
            </button>
          </div>
        </div>
      ) : (
        /* Payment Submission Form */
        <div className="bg-white rounded-3xl border border-slate-200 shadow-md p-6 sm:p-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="border-b border-slate-100 pb-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-amber-600" />
                পেমেন্ট তথ্য প্রদান করুন (Payment Submission)
              </h2>
              <p className="text-xs text-slate-500">
                নগদ অ্যাপ থেকে সফল লেনদেনের পর প্রাপ্ত Transaction ID লিখুন।
              </p>
            </div>

            {errorMsg && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
                {errorMsg}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  আবেদন রেফারেন্স নম্বর (Application Reference) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="যেমন: FC-2026-89412"
                  value={claimReference}
                  onChange={(e) => setClaimReference(e.target.value.toUpperCase())}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm font-mono uppercase font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-amber-500/20"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  পেমেন্ট প্রোভাইডার
                </label>
                <input
                  type="text"
                  disabled
                  value="নগদ (Nagad - Send Money Only)"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-100 text-sm text-slate-600 font-semibold"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  নগদ Transaction ID (TrxID) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="যেমন: 9G7K2L89X1"
                  value={transactionId}
                  onChange={(e) => setTransactionId(e.target.value.toUpperCase())}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm font-mono uppercase font-extrabold text-slate-900 tracking-wider focus:outline-hidden focus:ring-2 focus:ring-amber-500/20"
                  required
                />
                <p className="text-[11px] text-slate-400 mt-0.5">
                  নগদ ট্রানজ্যাকশন এসএমএস বা অ্যাপ স্টেটমেন্ট থেকে ৮-১০ ডিজিটের কোডটি লিখুন
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  পেমেন্টকৃত পরিমাণ (Amount Sent) <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400">৳</span>
                  <input
                    type="number"
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(parseFloat(e.target.value) || 0)}
                    className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm font-mono font-bold text-slate-900 focus:outline-hidden"
                    required
                  />
                </div>
                {paymentAmount !== settings.serviceFee && (
                  <p className="text-[11px] text-amber-700 font-medium mt-1">
                    ⚠️ নির্ধারিত ফি ৳১০৯ টাকা। ভিন্ন অঙ্ক লিখলে পেমেন্ট ম্যানুয়াল পর্যালোচনায় পাঠানো হবে।
                  </p>
                )}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                পেমেন্টের তারিখ ও সময় (Date & Time)
              </label>
              <input
                type="datetime-local"
                value={paymentDateTime}
                onChange={(e) => setPaymentDateTime(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-800 focus:outline-hidden"
              />
            </div>

            {/* Optional Screenshot */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                পেমেন্ট রসিদ বা এসএমএস স্ক্রিনশট (ঐচ্ছিক)
              </label>
              <div className="border border-slate-300 rounded-xl p-3 flex items-center justify-between bg-slate-50">
                <input
                  type="file"
                  id="pay-screenshot"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={handleScreenshotUpload}
                  className="hidden"
                />
                <label
                  htmlFor="pay-screenshot"
                  className="cursor-pointer inline-flex items-center gap-2 text-xs font-bold text-slate-700 hover:text-slate-900"
                >
                  <Upload className="w-4 h-4 text-slate-500" />
                  স্ক্রিনশট নির্বাচন করুন (Max 5MB)
                </label>
                {screenshotUrl && (
                  <span className="text-xs font-bold text-emerald-600">✓ সংযুক্ত হয়েছে</span>
                )}
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-3">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:bg-slate-400 text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <RotateCcw className="w-4 h-4 animate-spin" />
                    জমা দেওয়া হচ্ছে...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    পেমেন্ট তথ্য সাবমিট করুন
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
