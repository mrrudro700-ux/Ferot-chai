export type Provider = 'bKash' | 'Nagad' | 'Rocket' | 'Upay' | 'Mobile Recharge' | 'Other';

export type TransactionType = 'ভুল রিচার্জ' | 'Send Money' | 'Cash Out' | 'Other';

export type ClaimStatus =
  | 'Submitted'
  | 'Under Review'
  | 'More Information Required'
  | 'Referred to Provider'
  | 'Resolved'
  | 'Rejected';

export type PaymentStatus =
  | 'Awaiting Payment'
  | 'Payment Submitted'
  | 'Under Verification'
  | 'Verified'
  | 'Rejected'
  | 'Refunded';

export type UserRole = 'user' | 'admin';

export interface UserProfile {
  uid: string;
  email: string;
  fullName: string;
  phone: string;
  role: UserRole;
  emailVerified: boolean;
  createdAt: string;
}

export interface EvidenceFile {
  name: string;
  url: string;
  size: number;
  type: string;
  uploadedAt: string;
}

export interface Claim {
  id: string;
  referenceNumber: string; // e.g. FC-2026-94812
  ownerUid: string;
  applicantName: string;
  applicantPhone: string;
  applicantEmail?: string;
  preferredContact: 'phone' | 'email' | 'whatsapp';
  
  // Transaction Information
  transactionType: TransactionType;
  serviceProvider: Provider;
  transactionId?: string;
  transactionDate: string;
  transactionTime: string;
  amountSent: number;
  senderPhone: string;
  recipientPhone: string;
  mistakeExplanation: string;
  evidenceFiles: EvidenceFile[];
  
  // Status & Workflow
  claimStatus: ClaimStatus;
  paymentStatus: PaymentStatus;
  statusExplanation: string;
  nextRecommendedAction: string;
  
  // Admin & Resolution records
  providerComplaintRef?: string;
  confirmedRefundEvidence?: string;
  adminInternalNotes?: string;
  moreInfoRequestedPrompt?: string;
  additionalInfoProvided?: string;
  
  createdAt: string;
  updatedAt: string;
}

export interface PaymentSubmission {
  id: string;
  claimId: string;
  claimReference: string;
  ownerUid: string;
  paymentProvider: 'Nagad';
  expectedFee: number; // 109
  reportedAmount: number;
  reportedTransactionId: string;
  paymentDateTime: string;
  evidenceUrl?: string;
  status: PaymentStatus;
  reviewerUid?: string;
  reviewerName?: string;
  reviewerNotes?: string;
  verifiedAt?: string;
  submittedAt: string;
}

export interface AppSettings {
  receivingNumber: string; // default "01831027877"
  serviceFee: number; // default 109
  paymentProvider: 'Nagad';
  isAcceptingPayments: boolean;
  serviceNotice: string;
}

export interface InAppNotification {
  id: string;
  recipientUid: string;
  title: string;
  message: string;
  type: 'claim_update' | 'payment_update' | 'info_requested' | 'system';
  read: boolean;
  claimReference?: string;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  actorUid: string;
  actorEmail: string;
  actorRole: UserRole;
  action: string;
  targetType: 'claim' | 'payment' | 'settings' | 'auth';
  targetId: string;
  details: string;
  timestamp: string;
}
