# Ferot Chai - Security Specification & Access Control Model

## 1. Data Invariants

1. **Identity & Ownership Integrity**:
   - A user can only submit claims where `ownerUid == request.auth.uid`.
   - Users cannot forge or modify another user's claim or payment submission.
   - PII (phone number, email, full name) in user profiles is readable only by the owner or an authenticated admin.

2. **Privilege Separation**:
   - `claimStatus` and `paymentStatus` are strictly administrative fields. A non-admin user can NEVER set `paymentStatus = 'Verified'` or `claimStatus = 'Resolved'`.
   - Admin roles cannot be self-assigned in the `/users/{userId}` collection. Only users verified in the admin registry or pre-authorized admin lists hold admin powers.

3. **State Transition Guarantees**:
   - Initial claim creation must set `claimStatus == 'Submitted'` and `paymentStatus == 'Awaiting Payment'`.
   - Payment submission requires an existing, valid claim reference.
   - Verified payments require an authorized `reviewerUid` and timestamp.

4. **Public Privacy Protection**:
   - No public query or unauthenticated client can dump all user claims.
   - Public reference tracking requires both reference number and sender phone validation.
   - Public view masks all phone numbers (e.g. `01831***877`).

5. **Financial Integrity**:
   - Service fee is strictly defined as ৳109. If a payment submission differs from expected fee, it must be flagged for manual scrutiny.
   - No payment is ever automatically marked as received; human review or official gateway verification is mandatory.

## 2. The "Dirty Dozen" Threat Payloads (Must be Denied by Rules)

1. **Payload 1 (Self-Verified Payment Attempt)**:
   A standard user submits `paymentStatus: "Verified"` directly via client SDK.
   *Expected Result*: `PERMISSION_DENIED`

2. **Payload 2 (Ghost Field Injection)**:
   A claim create payload containing `{ isSuperAdmin: true, bypassPayment: true }`.
   *Expected Result*: `PERMISSION_DENIED` (rejected by `hasOnly` strict schema).

3. **Payload 3 (Claim Ownership Spoof)**:
   User A submits a claim with `ownerUid: "victim_user_b"`.
   *Expected Result*: `PERMISSION_DENIED` (`incoming().ownerUid != request.auth.uid`).

4. **Payload 4 (Unauthenticated Claim Listing)**:
   Anonymous user attempts `getDocs(collection(db, "claims"))` to harvest victims' phone numbers.
   *Expected Result*: `PERMISSION_DENIED` (`allow list: if isSignedIn() && resource.data.ownerUid == request.auth.uid`).

5. **Payload 5 (Audit Log Tampering)**:
   User attempts `deleteDoc(doc(db, "auditLogs", "log-1"))`.
   *Expected Result*: `PERMISSION_DENIED` (Audit logs are strictly immutable).

6. **Payload 6 (Admin Escalation in User Document)**:
   User sends `updateDoc(doc(db, "users", myUid), { role: "admin" })`.
   *Expected Result*: `PERMISSION_DENIED` (`affectedKeys().hasOnly(['fullName', 'phone'])`).

7. **Payload 7 (Oversized Payload / Denial of Wallet)**:
   Attacker sends a 10MB string inside `mistakeExplanation`.
   *Expected Result*: `PERMISSION_DENIED` (`size() <= 2000`).

8. **Payload 8 (Terminal State Tampering)**:
   Standard user attempts to modify a claim that is already in status `Resolved`.
   *Expected Result*: `PERMISSION_DENIED`.

9. **Payload 9 (Unauthenticated Settings Mutation)**:
   Attacker tries to change the Nagad receiving number to their own personal number.
   *Expected Result*: `PERMISSION_DENIED` (Write restricted to `isAdmin()`).

10. **Payload 10 (Payment Submission Fee Tampering)**:
    Attacker submits payment with `expectedFee: 0`.
    *Expected Result*: `PERMISSION_DENIED` (`incoming().expectedFee == 109`).

11. **Payload 11 (Non-Owner Payment Submission Access)**:
    User A queries `paymentSubmissions` belonging to User B.
    *Expected Result*: `PERMISSION_DENIED`.

12. **Payload 12 (Direct Evidence Overwrite in Storage)**:
    User A tries to delete or overwrite evidence files in User B's folder.
    *Expected Result*: `PERMISSION_DENIED`.
